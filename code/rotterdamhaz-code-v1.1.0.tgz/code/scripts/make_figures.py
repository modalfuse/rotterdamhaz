"""Figures for the RotterdamHaz paper, all from generated files (vector PDF).
  python scripts/make_figures.py <build_dir> <cv_dir> <sens_dir> <out_dir>
fig1_study_area.pdf  network by acc_class, tunnels (ADR category) and toll arcs, generation points, gateways, VGS sections
fig2_vgs_scatter.pdf model vs observed VGS counts before / after calibration, class 3 and class 2 (log), Z65 / Z152 marked
fig3_cv.pdf          held-out (leave-one-section-out and leave-one-road-out) vs observed, class 3 and class 2
fig4_route.pdf       baseline routes B1 / B1' / B3 / B4 for one instance OD row (largest ARR among rows where B1 != B3)
fig5_sensitivity.pdf demand / VoT sensitivity: median model/observed before calibration and median GEH after, by variant
Writes <out_dir>/figures_trace.csv (which file and selection each figure uses)."""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd, geopandas as gpd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
plt.rcParams.update({"font.size": 8, "pdf.fonttype": 42, "axes.linewidth": 0.6, "font.family": "DejaVu Sans"})
B, CV, SENS, OUT = map(Path, sys.argv[1:5]); OUT.mkdir(parents=True, exist_ok=True); TR = []
arcs = pd.read_csv(B / "arcs.csv", low_memory=False); g = gpd.read_file(B / "arcs.geojson")
g = g.merge(arcs[["u", "v", "acc_class", "tunnel_cat", "toll_min", "hazmat_status", "road_class"]], on=["u", "v"], how="left")
nodes = pd.read_csv(B / "nodes.csv").set_index("node"); gen = pd.read_csv(B / "gen_points.csv"); gw = pd.read_csv(B / "gateways.csv")
cal = pd.read_csv(B / "calibration_sites.csv"); obs = pd.read_csv(B / "calibration_sites.csv")
cal_ll = None
def site_xy():# section position = midpoint of its first matched arc
    gi = g.set_index(["u", "v"]).geometry; xy = {}
    for s, a in zip(cal.site, cal.arcs):
        if isinstance(a, str):
            u, v = map(int, a.split(";")[0].split("-")); c = gi.loc[(u, v)].interpolate(0.5, normalized=True); xy[s] = (c.x, c.y)
    return xy
XY = site_xy()
COL = {"expressway": "#d7301f", "national": "#fc8d59", "provincial": "#4575b4", "urban": "#c8c8c8"}; LW = {"expressway": 1.1, "national": 0.9, "provincial": 0.45, "urban": 0.15}
def basemap(ax, alpha=1.0):
    for c in ("urban", "provincial", "national", "expressway"): g[g.acc_class == c].plot(ax=ax, color=COL[c], lw=LW[c], alpha=alpha, zorder=1 if c == "urban" else 2)
    ax.set_aspect(1 / np.cos(np.radians(51.9))); ax.tick_params(labelsize=6); ax.set_xlabel("Longitude (°E)", fontsize=7); ax.set_ylabel("Latitude (°N)", fontsize=7)

# ---- fig 1 study area
fig, ax = plt.subplots(figsize=(7.0, 4.4)); basemap(ax)
tun = g[g.tunnel_cat.fillna("").astype(str) != ""]; tun.plot(ax=ax, color="k", lw=1.8, zorder=4)
toll = g[g.toll_min.fillna(0) > 0]; toll.plot(ax=ax, color="#ffd400", lw=2.6, zorder=5)
for _, r in tun.drop_duplicates("tunnel_cat").iterrows(): pass
ax.scatter(nodes.loc[gen.node, "lon"], nodes.loc[gen.node, "lat"], s=[8 + 10 * (t == "refinery") for t in gen.type], c=[{"port": "#1b9e77", "chemical": "#7570b3", "refinery": "#e7298a"}[t] for t in gen.type], marker="o", edgecolor="k", lw=0.3, zorder=6)
ax.scatter(gw.lon, gw.lat, s=55, marker="D", c="w", edgecolor="k", lw=0.8, zorder=7)
sx = np.array([XY[s] for s in cal.site if s in XY]); ax.scatter(sx[:, 0], sx[:, 1], s=22, marker="^", c="#00bcd4", edgecolor="k", lw=0.4, zorder=8)
for s in ("Z65", "Z152"):
    if s in XY: ax.annotate(s, XY[s], xytext=(4, 4), textcoords="offset points", fontsize=6.5, zorder=9)
h = [Line2D([], [], color=COL[c], lw=1.5, label=f"{c} road") for c in ("expressway", "national", "provincial", "urban")]
h += [Line2D([], [], color="k", lw=2.2, label="ADR tunnel (cat. C/D)"), Line2D([], [], color="#ffd400", lw=2.6, label="A24 toll arcs"),
      Line2D([], [], ls="", marker="o", mfc="#1b9e77", mec="k", label="generation: port"), Line2D([], [], ls="", marker="o", mfc="#7570b3", mec="k", label="generation: chemical"),
      Line2D([], [], ls="", marker="o", mfc="#e7298a", mec="k", label="generation: refinery"), Line2D([], [], ls="", marker="D", mfc="w", mec="k", label="gateway"),
      Line2D([], [], ls="", marker="^", mfc="#00bcd4", mec="k", label="VGS count section")]
fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.legend(handles=h, fontsize=6.5, loc="lower center", ncol=4, frameon=False); fig.savefig(OUT / "fig1_study_area.pdf"); plt.close(fig)
TR.append(dict(figure="fig1_study_area.pdf", files="arcs.csv, arcs.geojson, gen_points.csv, gateways.csv, nodes.csv, calibration_sites.csv", selection=f"{len(arcs)} arcs, {len(tun)} tunnel arcs, {len(toll)} toll arcs, {len(gen)} generation points, {len(gw)} gateways, {len(sx)} matched VGS sections"))

# ---- fig 2 VGS scatter
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.2))
for ax, hc, lab in zip(axs, ("class3", "class2"), ("Class 3 (flammable liquids, LF)", "Class 2 (gases, GF+GT)")):
    m = cal[cal.arcs.notna() & (cal[f"obs_{hc}"] > 0)]; o = m[f"obs_{hc}"]; lo = 30
    b_ = m[f"model_before_{hc}"].clip(lower=lo); a_ = m[f"model_after_{hc}"].clip(lower=lo)
    ax.scatter(o, b_, s=14, facecolor="none", edgecolor="#d95f02", lw=0.8, label="before calibration")
    ax.scatter(o, a_, s=12, c="#1b9e77", label="after calibration")
    for x0, y0, y1 in zip(o, b_, a_): ax.plot([x0, x0], [y0, y1], color="0.7", lw=0.4, zorder=0)
    lim = [lo, max(o.max(), b_.max()) * 2]; xx = np.array(lim); ax.plot(xx, xx, "k-", lw=0.6); ax.plot(xx, xx * 2, "k:", lw=0.5); ax.plot(xx, xx / 2, "k:", lw=0.5)
    for s in ("Z65", "Z152"):
        r = m[m.site == s]
        if len(r): ax.annotate(s, (r[f"obs_{hc}"].iloc[0], max(r[f"model_before_{hc}"].iloc[0], lo)), xytext=(3, 3), textcoords="offset points", fontsize=6.5)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lim); ax.set_ylim(lim); ax.set_xlabel("Observed loaded tank trucks / year (VGS)"); ax.set_ylabel("Modelled"); ax.set_title(lab, fontsize=8)
    ax.text(0.03, 0.97, f"n = {len(m)}; model = 0 shown at {lo}", transform=ax.transAxes, va="top", fontsize=6)
axs[0].legend(fontsize=6, loc="lower right"); fig.tight_layout(); fig.savefig(OUT / "fig2_vgs_scatter.pdf"); plt.close(fig)
TR.append(dict(figure="fig2_vgs_scatter.pdf", files="calibration_sites.csv", selection="matched sections with obs > 0, per class; dotted lines factor 2"))

# ---- fig 3 cross-validation
loo, rd = pd.read_csv(CV / "cv_loo.csv"), pd.read_csv(CV / "cv_road.csv")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.2))
for ax, hc, lab in zip(axs, ("class3", "class2"), ("Class 3", "Class 2")):
    l = loo[(loo.cls == hc) & (loo.obs > 0)]; r = rd[(rd.cls == hc) & (rd.obs > 0)]; lo = 30
    ax.scatter(l.obs, l.model_insample.clip(lower=lo), s=10, c="0.6", label="in-sample (all sections)")
    ax.scatter(l.obs, l.model_heldout.clip(lower=lo), s=14, c="#1b9e77", label="held out: leave one section out")
    ax.scatter(r.obs, r.model_heldout.clip(lower=lo), s=18, marker="x", c="#d95f02", lw=0.8, label="held out: leave one road out")
    lim = [lo, max(l.obs.max(), l.model_heldout.max(), r.model_heldout.max()) * 2]; xx = np.array(lim); ax.plot(xx, xx, "k-", lw=0.6); ax.plot(xx, 2 * xx, "k:", lw=0.5); ax.plot(xx, xx / 2, "k:", lw=0.5)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lim); ax.set_ylim(lim); ax.set_xlabel("Observed loaded tank trucks / year (VGS)"); ax.set_ylabel("Modelled after calibration"); ax.set_title(lab, fontsize=8)
axs[0].legend(fontsize=6, loc="lower right"); fig.tight_layout(); fig.savefig(OUT / "fig3_cv.pdf"); plt.close(fig)
TR.append(dict(figure="fig3_cv.pdf", files="cv_loo.csv, cv_road.csv", selection="sections with obs > 0"))

# ---- fig 4 route example
from hazbench.metrics import Bench
br = pd.read_csv(B / "_baselines/baseline_results.csv")
b3 = br[(br.method == "B3_min_TR_sum") & (~br.same_path_as_B1)].copy()
b1 = br[br.method == "B1_min_time"].set_index(["instance", "od_id"])
b3["redu"] = 1 - b3.TR_sum.values / b1.loc[list(zip(b3.instance, b3.od_id)), "TR_sum"].values
b3 = b3[(b3.dT < 0.5)]; pick = b3.sort_values("redu", ascending=False).iloc[0]
od = pd.read_csv(B / f"instances/{pick.instance}/od.csv").set_index("od_id").loc[pick.od_id]
bn = Bench(B); meth = {"B1_min_time": ("t", "#d95f02", "B1 min. generalised time"), "B1p_min_pure_time": ("t0", "#e6ab02", "B1′ min. pure time"), "B3_min_TR_sum": ("TR", "#1b9e77", "B3 min. risk"), "B4_min_PE_sum": ("PE", "#7570b3", "B4 min. exposure")}
fig, ax = plt.subplots(figsize=(5.0, 4.2)); P = {}
for k, (w, c, lab) in meth.items():
    if k not in set(br.method): continue
    p = bn.shortest(od.origin, od.destination, w, od.substance); P[k] = p
    xs, ys = nodes.loc[p, "lon"].values, nodes.loc[p, "lat"].values; ax.plot(xs, ys, color=c, lw={"B1_min_time": 3.2, "B1p_min_pure_time": 2.2, "B3_min_TR_sum": 2.6, "B4_min_PE_sum": 1.2}[k], label=lab, zorder=5, alpha=0.9)
allx = np.concatenate([nodes.loc[p, "lon"].values for p in P.values()]); ally = np.concatenate([nodes.loc[p, "lat"].values for p in P.values()])
pad = 0.02; ax.set_xlim(allx.min() - pad, allx.max() + pad); ax.set_ylim(ally.min() - pad, ally.max() + pad)
basemap(ax, alpha=0.5); ax.set_xlim(allx.min() - pad, allx.max() + pad); ax.set_ylim(ally.min() - pad, ally.max() + pad)
ax.scatter(*nodes.loc[od.origin, ["lon", "lat"]], s=40, c="k", zorder=7); ax.scatter(*nodes.loc[od.destination, ["lon", "lat"]], s=40, marker="s", c="k", zorder=7)
ax.annotate("O", nodes.loc[od.origin, ["lon", "lat"]].values, xytext=(4, 4), textcoords="offset points"); ax.annotate("D", nodes.loc[od.destination, ["lon", "lat"]].values, xytext=(4, 4), textcoords="offset points")
ax.legend(fontsize=6.5, loc="best"); fig.tight_layout(); fig.savefig(OUT / "fig4_route.pdf"); plt.close(fig)
r1 = br[(br.instance == pick.instance) & (br.od_id == pick.od_id)].set_index("method")
TR.append(dict(figure="fig4_route.pdf", files="_baselines/baseline_results.csv, instances", selection=f"{pick.instance} {pick.od_id} ({od.substance}); largest TR reduction B3 vs B1 among rows with B3 != B1 and dT < 0.5: " +
               "; ".join(f"{m}: T {r1.loc[m,'T_min']:.1f} min, L {r1.loc[m,'L_km']:.1f} km, TR {r1.loc[m,'TR_sum']:.3g}" for m in r1.index)))
json.dump(dict(instance=pick.instance, od_id=pick.od_id, substance=od.substance, rows={m: {c: float(r1.loc[m, c]) for c in ("T_min", "L_km", "TR_sum", "PE_sum")} for m in r1.index}), open(OUT / "fig4_route.json", "w"), indent=1)

# ---- fig 5 sensitivity
S = pd.read_csv(SENS / "sens_od_summary.csv")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8), sharey=True); y = np.arange(len(S))[::-1]
for hc, c, dy in (("class3", "#d95f02", 0.12), ("class2", "#1b9e77", -0.12)):
    axs[0].scatter(S[f"{hc}_ratio_before_median"], y + dy, c=c, s=18, label=hc.replace("class", "class "))
    axs[1].scatter(S[f"{hc}_GEH_after_median"], y + dy, c=c, s=18)
axs[0].axvspan(0.5, 2.0, color="0.92", zorder=0); axs[0].axvline(1, color="k", lw=0.5)
axs[0].set_yticks(y); axs[0].set_yticklabels(S.variant.str.replace("_", " ")); axs[0].set_xlabel("Median model/observed, before calibration"); axs[1].set_xlabel("Median GEH after calibration")
axs[0].legend(fontsize=6.5); fig.tight_layout(); fig.savefig(OUT / "fig5_sensitivity.pdf"); plt.close(fig)
TR.append(dict(figure="fig5_sensitivity.pdf", files="sens_od_summary.csv", selection=f"{len(S)} variants; grey band = P2 range 0.5-2"))
pd.DataFrame(TR).to_csv(OUT / "figures_trace.csv", index=False); print(pd.DataFrame(TR).to_string())
