"""Absolute-risk worked example with HART / RBM II 1%-lethality distances (review M2, decision Q. Liu 2026-10-21 23:21).

  python scripts/lethal_example.py <dataset_dir> <out_dir> <instance>[,<instance>...]

Sources (all public, RIVM): Handleiding Risicoberekeningen Bevt (HART) versie 1.2, 11 januari 2017 (rivm.nl, retrieved via web.archive.org
2026-10-21, sha256 c57f7148e4c9...): Tabel 4-2 (road 1%-lethality distances: LF2 45 m, GF3 355 m, GT3 560 m, GT4/GT5 > 4000 m),
Tabel 10-7 (P(release > 100 kg | injury accident): motorway 0.052 pressure / 0.101 atmospheric, etc.; the benchmark's lambda already uses
the atmospheric value, pressure tanks are scaled by 0.043/0.093 as in params Pi_substance), Tabel 10-8 (fraction of releases relevant for
external risk: gases 0.3, liquids 0.75), Tabel 10-9 (ignition: LF2 direct 0.065 + delayed 0.065; GF1-3 direct 0.8, delayed 0.2).
Chlorine (GT4/GT5): HART gives only "> 4000 m"; 4000 m is used as a LOWER bound of the distance (flagged).
No lethality-versus-distance profile is tabulated in HART; inside the 1% contour the probability of death is between 0.01 and 1, so the
expected fatalities per trip are bounded by  0.01 * F  <=  E[fatalities]  <=  F,   F = sum_arcs p_rel * x_press * f_rel * P_eff * Pop_d(arc),
where Pop_d is the day population whose 100 m cell centre lies within the 1%-lethality distance d of the arc (cells.npz).
Writes lethal_rows.csv (per OD row and method) and lethal_summary.csv."""
import sys, json, math
from pathlib import Path
import numpy as np, pandas as pd, shapely
from pyproj import Transformer
from scipy.spatial import cKDTree
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hazbench.metrics import Bench

D1 = {"benzene": 45.0, "lpg": 355.0, "ammonia": 560.0, "chlorine": 4000.0}# HART v1.2 Tabel 4-2, weg (chlorine: "> 4000", lower bound)
CAT = {"benzene": "LF2", "lpg": "GF3", "ammonia": "GT3", "chlorine": "GT4/GT5"}
F_REL = {"benzene": 0.75, "lpg": 0.3, "ammonia": 0.3, "chlorine": 0.3}# HART Tabel 10-8
P_EFF = {"benzene": 0.065 + 0.065, "lpg": 0.8 + 0.2, "ammonia": 1.0, "chlorine": 1.0}# HART Tabel 10-9 (fire / explosion effects); toxic: no ignition needed
X_PRESS = {"benzene": 1.0, "lpg": 0.043 / 0.093, "ammonia": 0.043 / 0.093, "chlorine": 0.043 / 0.093}# HART Tabel 10-7 / RBM II Tabel 4.22, generic road

def main(D, OUT, insts):
    D, OUT = Path(D), Path(OUT); OUT.mkdir(parents=True, exist_ok=True)
    b = Bench(D); c = np.load(D / "cells.npz"); P = b.P
    tree = cKDTree(np.c_[c["x_rd"], c["y_rd"]]); cpts = shapely.points(c["x_rd"], c["y_rd"]); pday = c["pop_day"].astype(float)
    gj = json.load(open(D / "arcs.geojson")); T = Transformer.from_crs(4326, 28992, always_xy=True)
    geom = {}
    for ft in gj["features"]:
        xy = np.array(ft["geometry"]["coordinates"]); x, y = T.transform(xy[:, 0], xy[:, 1])
        geom[(ft["properties"]["u"], ft["properties"]["v"])] = shapely.linestrings(np.c_[x, y])
    G = [geom[(u, v)] for u, v in zip(b.arcs.u, b.arcs.v)]
    cache = {}
    def pop_d(k, sub):
        key = (k, sub)
        if key not in cache:
            g = G[k]; r = D1[sub]; pts = shapely.get_coordinates(shapely.segmentize(g, 25.0))
            cand = np.unique(np.concatenate([np.asarray(z, dtype=np.int64) for z in tree.query_ball_point(pts, r + 75.0)]))
            ok = cand[shapely.dwithin(cpts[cand], g, r)] if len(cand) else cand
            cache[key] = (float(pday[ok].sum()), ok)
        return cache[key]
    meths = {"B1_min_time": ("t", False), "B3_min_TR_sum": ("TR", True), "B4_min_PE_sum": ("PE", True)}
    rows = []
    for inst in insts:
        od = pd.read_csv(D / f"instances/{inst}/od.csv")
        for q in od.itertuples():
            s = q.substance
            if s not in D1: continue
            for mname, (w, sub) in meths.items():
                path = b.shortest(q.origin, q.destination, w, s)
                ks = b.arc_ids(path); m = b.path_metrics(path, s)
                pe = np.array([b.p_rel[k] * X_PRESS[s] * F_REL[s] * P_EFF[s] for k in ks])
                pops = [pop_d(k, s) for k in ks]
                F = float(sum(p_ * pp[0] for p_, pp in zip(pe, pops)))
                cov = np.unique(np.concatenate([pp[1] for pp in pops])) if pops else np.array([], int)
                rows.append(dict(instance=inst, od_id=q.od_id, substance=s, category=CAT[s], d1_m=D1[s], method=mname, trips_per_year=q.trips_loaded_per_year,
                                 F_per_trip=F, Ef_upper_per_year=F * q.trips_loaded_per_year, Ef_lower_per_year=0.01 * F * q.trips_loaded_per_year,
                                 PE_d_union=float(pday[cov].sum()), lethal_event_per_trip=float(pe.sum()), TR_sum_erg=m["TR_sum"], PE_union_erg=m["PE_union"]))
    df = pd.DataFrame(rows); df.to_csv(OUT / "lethal_rows.csv", index=False)
    from scipy.stats import spearmanr
    out = []
    for s, g in df.groupby("substance"):
        b1 = g[g.method == "B1_min_time"].set_index(["instance", "od_id"]); b3 = g[g.method == "B3_min_TR_sum"].set_index(["instance", "od_id"])
        rho = spearmanr(b1.F_per_trip, b1.TR_sum_erg).statistic if len(b1) > 2 else float("nan")
        red = 1 - b3.F_per_trip / b1.F_per_trip.replace(0, np.nan)
        out.append(dict(substance=s, category=CAT[s], d1_m=D1[s], n_rows=len(b1), F_median_B1=b1.F_per_trip.median(),
                        Ef_upper_sum_B1=b1.Ef_upper_per_year.sum(), Ef_upper_sum_B3=b3.Ef_upper_per_year.sum(),
                        rho_F_vs_TRerg_B1=rho, F_reduction_B3_vs_B1_median=float(red.median()), share_B3_not_worse=float((red >= -1e-12).mean()),
                        lethal_event_per_trip_median_B1=b1.lethal_event_per_trip.median()))
    sm = pd.DataFrame(out); sm.to_csv(OUT / "lethal_summary.csv", index=False); print(sm.to_string())

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3].split(","))
