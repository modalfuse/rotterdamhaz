"""Data dictionary for a RotterdamHaz build: one row per (file, column) with dtype, non-null count, min/max (numeric) or number of
distinct values (text), and a description. Descriptions are written here by hand; every column found in the build must have one
(the script fails otherwise), so the dictionary cannot silently fall behind the data.
  python scripts/make_dictionary_rotterdam.py <build_dir>   -> <build_dir>/DATA_DICTIONARY.md and data_dictionary.csv"""
import sys, re
from pathlib import Path
import numpy as np, pandas as pd

S = ["chlorine", "ammonia", "lpg", "benzene"]
D = {
# nodes
 "node": "OSM node id", "lon": "longitude, EPSG:4326 (deg)", "lat": "latitude, EPSG:4326 (deg)", "x_rd": "RD New x, EPSG:28992 (m)", "y_rd": "RD New y, EPSG:28992 (m)",
 "node_type": "junction / gen / attr / gateway (point snapped to the node)",
 "toll_min": "per-trip toll as generalized time (min) = toll EUR / value of time EUR/h x 60; added to time_min for routing only (: A24 Maasdeltatunnel arcs)",
# arcs
 "u": "tail node id", "v": "head node id", "name": "OSM road name (list if several ways)", "road_class": "OSM highway value",
 "speed_kmh": "assumed heavy-goods-vehicle free-flow speed (km/h)", "speed_src": "source of speed_kmh",
 "urban": "1 if population density within 1 km >= 1500 persons/km2 (urban context), else 0", "pop_density_1km": "population density within 1 km (persons/km2)",
 "osm_way_id": "primary OSM way id", "osm_way_ids": "all matched OSM way ids", "osm_match_frac": "fraction of arc length matched to OSM ways",
 "osm_names": "names of the matched OSM ways", "lanes": "lane count", "lanes_src": "osm or class default (assumed)", "maxspeed_osm": "OSM maxspeed (km/h) where tagged",
 "oneway": "OSM oneway", "bridge_frac": "fraction of length on bridges", "tunnel_frac": "fraction of length in tunnels",
 "A1": "correction factor A1 (1: Dutch method has no such factor)", "A2": "correction factor A2 (1)", "A3": "correction factor A3 (1)", "A4": "correction factor A4 (1)",
 "A5": "correction factor A5 (1)", "A6": "correction factor A6 (1)", "A7": "correction factor A7 (1)", "A_s": "product A1..A7",
 "length_km_v0": "segment length before geometry recomputation (km)", "length_km": "length from RD New geometry (km, used)", "time_min": "free-flow travel time (min)",
 "acc_class": "RBM II road type used for the multiplier: expressway / national / provincial (outside built-up area) / urban (built-up area)",
 "wkd_maxspeed": "WKD legal speed limit matched to the arc (km/h; empty if < half the length matched)", "acc_class_src": "wkd (built-up rule from WKD speed <= 50 km/h) or osm (class rule)",
 "hazmat_status": "allowed_corridor (on a Basisnet road section) or unknown (no Basisnet section; treated as allowed)", "corridor": "corridor name (unused, empty)",
 "restrict_time": "time-window restriction (empty)", "restrict_src": "source of hazmat_status (Basisnet section)", "tunnel_cat": "ADR tunnel category of the arc under VLG art. 3 (B-E; empty = no restriction)",
 "m_class_RBMII": "RBM II road-type multiplier, atmospheric tanks (base)", "lambda_arc_RBMII": "release frequency per loaded truck-km with the RBMII multiplier",
 "m_class_RBMII_pressure": "RBM II multiplier, pressure tanks (sensitivity)", "lambda_arc_RBMII_pressure": "frequency with the pressure-tank multiplier",
 "m_class_uniform": "multiplier 1 everywhere (sensitivity)", "lambda_arc_uniform": "frequency with multiplier 1",
 "m_class": "multiplier used (= m_class_RBMII)", "lambda_base": "network-mean release frequency per loaded truck-km (7.761e-9)", "lambda_arc": "release frequency used (per loaded truck-km)",
 "p_release_trip": "per-trip release probability on the arc: (1 + a) * lambda_arc * A_s * length_km, a = 0", "accident_prob_harwood": "Harwood (1990) basis, comparison only",
 "flow_loaded_base": "loaded trips/year on the arc, all-or-nothing assignment of od_base (time-shortest, per-class tunnel restrictions)",
 "flow_loaded_calibrated": "same for od_base_calibrated",
# points
 "id": "pseudonymous point id (Gnn generation, Ann attraction, W_<node> gateway)", "type": "point type (refinery / port / chemical; fuel_station / chemical_firm; gateway)",
 "area_ha": "site area (ha) of the terminal / register site polygon", "snap_dist_m": "distance from the point to its network node (m)", "weight_src": "how the weight / area was obtained",
 "capacity_m3": "port terminals: public tank storage capacity (m3) used as port weight", "capacity_kbd": "refineries: public crude capacity (kb/d) used as refinery weight",
 "needs_manual_check": "True if snap distance exceeds the check threshold", "Q_base_10kt": "base generation (10^4 t/year; scenario value)", "weight": "attraction / gateway weight",
# od
 "od_id": "{scenario}_b{beta}_{index}", "origin": "origin node id", "origin_id": "origin point id", "origin_type": "origin point type", "destination": "destination node id",
 "dest_id": "destination point id", "dest_type": "destination point type", "hazmat_class": "class3 (flammable liquids), class2 (gases), other",
 "substance": "representative substance: benzene, lpg, ammonia, chlorine, other (other is not risk-modelled)", "tons_per_year": "demand (t/year)",
 "trips_loaded_per_year": "loaded truck trips/year (tons / 23 t)", "shortest_time_min": "shortest travel time on the allowed network for this class (min)",
 "provenance": "short provenance note", "calib_factor": "multiplicative calibration factor applied to the row", "seed": "sampling seed (instances)",
# misc
 "item": "parameter / data item", "value": "value", "unit": "unit", "label": "official / real / estimated / assumed", "source_ref": "source", "url": "URL(s)", "derivation": "derivation and notes",
 "area": "Harwood area type", "roadway": "Harwood roadway type", "truck_accidents_per_million_veh_mi": "Harwood (1990) truck accident rate", "p_release_given_accident": "Harwood release probability",
 "releases_per_million_veh_mi": "Harwood release rate", "harwood_class": "Harwood class", "accident_rate_per_vehkm": "accident rate per veh-km", "releasing_accident_rate_per_vehkm": "releasing accident rate per veh-km",
 "site": "RWS VGS count section id (Basisnet Znn)", "arcs": "matched arcs u-v (cross-section)", "obs_class3": "observed loaded tank trucks/year LF1+LF2 (VGS 2025)",
 "model_before_class3": "modelled class3 trips/year before calibration", "model_after_class3": "after calibration", "GEH_before_class3": "GEH before", "GEH_after_class3": "GEH after",
 "obs_class2": "observed GF1-3 + GT3-5 trips/year", "model_before_class2": "modelled class2 before calibration", "model_after_class2": "after calibration",
 "GEH_before_class2": "GEH before", "GEH_after_class2": "GEH after",
 "substance_": "", "un_number": "UN number", "erg_guide": "ERG guide", "isolation_m": "ERG initial isolation distance (m)", "primary_radius_km": "ERG protective-action distance used as impact radius (km)", "source": "source",
 "scenario": "OD scenario", "beta": "gravity exponent", "hc": "hazmat class", "iters": "Furness iterations", "rel_err": "max relative error at convergence",
 "n_sites": "number of sites", "ratio_before_q1": "model/obs Q1 before calibration", "ratio_before_median": "median before", "ratio_before_q3": "Q3 before",
 "ratio_after_q1": "Q1 after", "ratio_after_median": "median after", "ratio_after_q3": "Q3 after", "GEH_before_median": "median GEH before", "GEH_after_median": "median GEH after",
 "share_GEH_after_lt5": "share of sites with GEH < 5 after calibration", "group": "road group", "osm_km": "OSM length (km)", "nwb_km": "NWB length (km)",
 "basisnet_section": "Basisnet section id", "F": "model release frequency per km per year on the section", "km": "matched length (km)", "pr6_m": "Basisnet PR 10^-6 contour distance (m)",
}
F = {("gen_points.csv", "name"): "pseudonymous label 'Facility Gnn (type)'", ("attr_points.csv", "name"): "pseudonymous label 'Attractor Ann (type)'",
     ("gateways.csv", "name"): "motorway exit of the study area", ("gateways.csv", "type"): "gateway", ("gateways.csv", "id"): "W_<node>",
     ("erg2024_radii.csv", "substance"): "representative substance", ("gravity_convergence.csv", "hc"): "hazmat class",
     ("attr_points.csv", "weight"): "attraction weight (fuel station 1; chemical firm = site area, ha)", ("gateways.csv", "weight"): "observed loaded DG tank trucks/year on the boundary Basisnet section (VGS 2025)"}
for s in S:
    D[f"pop_{s}"] = f"day population within the {s} primary radius of the arc (persons; cells shared by neighbouring arcs counted for each)"
    D[f"pop_{s}_night"] = f"night population within the {s} primary radius"; D[f"pop_{s}_iso"] = f"day population within the {s} ERG isolation distance"
    D[f"pop_{s}_iso_night"] = f"night population within the {s} isolation distance"

def main(b):
    b = Path(b); rows = []
    files = sorted(p for p in b.rglob("*.csv") if "_baselines" not in p.parts and not p.name.startswith("plausibility_") or p.name.startswith("plausibility_"))
    seen_inst = False
    for p in files:
        rel = p.relative_to(b).as_posix
        if rel.startswith("instances/"):
            if seen_inst: continue
            seen_inst = True; rel = "instances/*/od.csv"
        if rel.startswith("_baselines/"): continue
        df = pd.read_csv(p, low_memory=False)
        for c in df.columns:
            s = df[c]; num = pd.api.types.is_numeric_dtype(s)
            desc = F.get((p.name, c), D.get(c))
            if desc is None: raise SystemExit(f"no description for {rel}:{c}")
            rows.append(dict(file=rel, column=c, dtype=str(s.dtype), non_null=int(s.notna.sum), rows=len(s),
                             min=(f"{s.min:.6g}" if num and s.notna.any else ""), max=(f"{s.max:.6g}" if num and s.notna.any else ""),
                             distinct=("" if num else int(s.nunique)), description=desc))
    dd = pd.DataFrame(rows); dd.to_csv(b / "data_dictionary.csv", index=False)
    with open(b / "DATA_DICTIONARY.md", "w") as f:
        f.write("# RotterdamHaz data dictionary\n\nProduced by `scripts/make_dictionary_rotterdam.py` from the files of this build. "
                "Non-CSV files: `cells.npz` (populated 100 m cells: flat index, row, col, x/y RD New, pop_day, pop_night, raster shape), "
                "`arc_cells_{substance}.npz` (SciPy CSR, arcs x cells, 1 if the cell centre lies within the primary radius of the arc; row order = arcs.csv, column order = cells.npz), "
                "`pop_day.tif` / `pop_night.tif` (100 m population rasters on the CBS grid, EPSG:28992), `arcs.geojson` (arc geometries, EPSG:4326; u, v join to arcs.csv), "
                "`params.yaml` (parameters of the build), `build_log.txt`.\n\n")
        for fn, g in dd.groupby("file", sort=False):
            f.write(f"## `{fn}` ({g.rows.iloc[0]} rows)\n\n| column | dtype | non-null | min | max | distinct | description |\n|---|---|---|---|---|---|---|\n")
            for r in g.itertuples: f.write(f"| `{r.column}` | {r.dtype} | {r.non_null} | {r.min} | {r.max} | {r.distinct} | {r.description} |\n")
            f.write("\n")
    print(f"{len(dd)} columns in {dd.file.nunique} files -> {b/'DATA_DICTIONARY.md'}")

if __name__ == "__main__":
    main(sys.argv[1])
