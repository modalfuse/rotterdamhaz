#!/usr/bin/env bash
# Full pipeline for one region:  scripts/run_region.sh regions/<region>.yaml <out_dir>
# Steps whose inputs are not configured for the region are skipped.
set -euo pipefail
cd "$(dirname "$0")/.."
PY=.venv/bin/python; CFG=$1; OUT=$2
SRC=$($PY -c "import yaml,sys;print(yaml.safe_load(open('$CFG'))['network']['source'])")
$PY -m hazbench.osm_extract "$CFG"                                   # 01 OSM tags + POIs (+ highway refs)
if [ "$SRC" = osm ]; then
  if $PY -c "import yaml;import sys;sys.exit(0 if (yaml.safe_load(open('$CFG')).get('population') or {}).get('cbs') else 1)"; then $PY -m hazbench.prep.cbs_grid "$CFG"; fi
  if $PY -c "import yaml;import sys;sys.exit(0 if (yaml.safe_load(open('$CFG')).get('facilities') or {}).get('eprtr') else 1)"; then $PY -m hazbench.prep.eprtr_points "$CFG"; fi
  if $PY -c "import yaml;import sys;sys.exit(0 if ((yaml.safe_load(open('$CFG')).get('od') or {}).get('calibration') or {}).get('vgs') else 1)"; then $PY -m hazbench.prep.vgs_counts "$CFG"; fi
  $PY -m hazbench.osm_graph "$CFG"                                   # OSM -> directed graph snapshot
  if $PY -c "import yaml;import sys;sys.exit(0 if yaml.safe_load(open('$CFG')).get('hazmat_status') else 1)"; then $PY -m hazbench.prep.hazmat_status "$CFG"; fi
  if $PY -c "import yaml;import sys;sys.exit(0 if yaml.safe_load(open('$CFG')).get('wkd_speed') else 1)"; then $PY -m hazbench.prep.wkd_speed "$CFG"; fi
  if $PY -c "import yaml;import sys;sys.exit(0 if (yaml.safe_load(open('$CFG')).get('facilities') or {}).get('port_terminals') else 1)"; then $PY -m hazbench.prep.port_terminals "$CFG"; fi
fi
$PY -m hazbench.build "$CFG" "$OUT"                                  # 02 network attributes, exposure, facilities, OD, instances
$PY -m hazbench.baselines "$CFG" "$OUT" "$OUT/_baselines"            # B1-B4 on K=10 instances
$PY -m hazbench.stats "$OUT/_baselines/baseline_results.csv" "$OUT/_baselines"
$PY -m hazbench.qa "$CFG" "$OUT" "$OUT/_baselines/baseline_results.csv"
