"""Write paper/numbers.tex (LaTeX macros) and paper/numbers_trace.csv from the generated RotterdamHaz files.

usage: make_paper_numbers.py <build_dir> <sens_dir> <release_dir|-> <out_dir>
Every number printed in rotterdamhaz.tex comes from a macro defined here; numbers_trace.csv names the file and the
expression each macro was computed from.
"""
import sys, json, re, csv
from pathlib import Path
import numpy as np, pandas as pd, yaml

B, SENS, REL, OUT = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4])
OUT.mkdir(parents=True, exist_ok=True)
M, T = {}, []


def put(name, value, src, expr):
    assert re.fullmatch(r"[A-Za-z]+", name), name
    assert name not in M, name
    M[name] = value
    T.append(dict(macro="\\" + name, value=value, file=str(src), expression=expr))


def i(x):# thousands separator
    return f"{int(round(x)):,}"


def f(x, d=2):
    return f"{x:.{d}f}"


def sci(x, d=2):
    m, e = f"{x:.{d}e}".split("e")
    return f"{m}\\times10^{{{int(e)}}}"


P = yaml.safe_load(open(B / "params.yaml"))
put("Version", str(P.get("version")), "params.yaml", "version")

# parameters (params.yaml) and provenance table (DATA_SOURCES.csv)
cl = P["class_split"]["port"]
put("ShareThree", f"{cl['class3']:.3f}", "params.yaml", "class_split.port.class3")
put("ShareTwo", f"{cl['class2']:.3f}", "params.yaml", "class_split.port.class2")
put("ShareOther", f"{cl['other']:.3f}", "params.yaml", "class_split.port.other")
put("ShareTwoSens", f"{P['class_split_sens']['class2']:g}", "params.yaml", "class_split_sens.class2")
c2 = P["substance_split"]["class2"]
put("SplitLpg", f"{c2['lpg']:g}", "params.yaml", "substance_split.class2.lpg")
put("SplitAmmonia", f"{c2['ammonia']:g}", "params.yaml", "substance_split.class2.ammonia")
put("SplitChlorine", f"{c2['chlorine']:g}", "params.yaml", "substance_split.class2.chlorine")
for k, nm in (("benzene", "Benzene"), ("lpg", "Lpg"), ("ammonia", "Ammonia")):
    put("Pi" + nm, f"{P['Pi_substance'][k]:g}", "params.yaml", f"Pi_substance.{k}")
rm = P["road_mult"]["RBMII"]
put("MultOutside", f"{rm['provincial']:g}", "params.yaml", "road_mult.RBMII.provincial")
put("MultInside", f"{rm['urban']:g}", "params.yaml", "road_mult.RBMII.urban")
put("PRelAtm", f"{P['p_release']['base']:g}", "params.yaml", "p_release.base")
put("PRelPress", f"{P['p_release']['low']:g}", "params.yaml", "p_release.low")
put("Beta", f"{P['beta']:g}", "params.yaml", "beta")
put("BetaLow", f"{min(P['beta_sens']):g}", "params.yaml", "min(beta_sens)")
put("BetaHigh", f"{max(P['beta_sens']):g}", "params.yaml", "max(beta_sens)")
put("Seed", str(P["seed"]), "params.yaml", "seed")
put("ParkDensity", f"{P['park_density_per_ha']['logistics']:g}", "params.yaml", "park_density_per_ha.logistics")
put("Underreport", ", ".join(str(x) for x in P["underreport"]), "params.yaml", "underreport")
put("LoadSens", f"{P['load_t']['sens']:g}", "params.yaml", "load_t.sens")
er = pd.read_csv(B / "erg2024_radii.csv").set_index("substance")
for k, nm in (("chlorine", "Chlorine"), ("ammonia", "Ammonia"), ("lpg", "Lpg"), ("benzene", "Benzene")):
    put("Erg" + nm, f"{er.loc[k, 'primary_radius_km']:g}", "erg2024_radii.csv", f"{k}.primary_radius_km")
ds = pd.read_csv(B / "DATA_SOURCES.csv").set_index("item")
put("BronInjury", i(float(ds.loc["truck_accidents_injury_2018_2024", "value"])), "DATA_SOURCES.csv", "truck_accidents_injury_2018_2024")
put("BronAll", i(float(ds.loc["truck_accidents_all_2018_2024", "value"])), "DATA_SOURCES.csv", "truck_accidents_all_2018_2024")
put("TruckVkm", f"{float(ds.loc['truck_vehicle_km_NL_2018_2024', 'value']):,.1f}", "DATA_SOURCES.csv", "truck_vehicle_km_NL_2018_2024 (million)")
put("InjRate", sci(float(ds.loc["truck_injury_accident_rate", "value"]), 3), "DATA_SOURCES.csv", "truck_injury_accident_rate")

# network
a = pd.read_csv(B / "arcs.csv", low_memory=False, dtype={"tunnel_cat": str})
n = pd.read_csv(B / "nodes.csv")
put("NNodes", i(len(n)), "nodes.csv", "rows")
put("NArcs", i(len(a)), "arcs.csv", "rows")
put("NetKm", i(a.length_km.sum()), "arcs.csv", "sum(length_km)")
put("NBridgeArcs", i((a.bridge_frac > 0).sum()), "arcs.csv", "count(bridge_frac>0)")
tc = a.tunnel_cat.fillna("").value_counts()
put("NTunnelC", i(tc.get("C", 0)), "arcs.csv", "count(tunnel_cat=='C')")
put("NTunnelD", i(tc.get("D", 0)), "arcs.csv", "count(tunnel_cat=='D')")
cor = a[a.hazmat_status == "allowed_corridor"]
put("NCorridorArcs", i(len(cor)), "arcs.csv", "count(hazmat_status=='allowed_corridor')")
put("CorridorKm", f(cor.length_km.sum(), 1), "arcs.csv", "sum(length_km | allowed_corridor)")
rc = a.road_class.value_counts()
links = sum(v for k, v in rc.items() if k.endswith("_link"))
put("ArcsByClass", "; ".join(f"{k} {i(v)}" for k, v in rc.items() if not k.endswith("_link")) + f"; links {i(links)}", "arcs.csv", "value_counts(road_class)")
ac = a.groupby("acc_class").length_km.sum()
for k, nm in (("expressway", "Motorway"), ("provincial", "Outside"), ("urban", "Inside"), ("national", "Trunk")):
    put(f"Km{nm}", i(ac.get(k, 0)), "arcs.csv", f"sum(length_km | acc_class=='{k}')")
lam = (a.lambda_arc * a.length_km).sum() / a.length_km.sum()
put("LambdaWeighted", sci(lam, 3), "arcs.csv", "sum(lambda_arc*length_km)/sum(length_km)")
put("LambdaBase", sci(P["lambda_base"]["base"], 3), "params.yaml", "lambda_base.base")
put("LambdaLow", sci(P["lambda_base"]["low"], 3), "params.yaml", "lambda_base.low")
put("LambdaHigh", sci(P["lambda_base"]["high"], 3), "params.yaml", "lambda_base.high")
put("PRelMax", sci(a.p_release_trip.max(), 1), "arcs.csv", "max(p_release_trip)")
lon, lat = n.lon, n.lat
put("LonMin", f(lon.min(), 2), "nodes.csv", "min(lon)"); put("LonMax", f(lon.max(), 2), "nodes.csv", "max(lon)")
put("LatMin", f(lat.min(), 2), "nodes.csv", "min(lat)"); put("LatMax", f(lat.max(), 2), "nodes.csv", "max(lat)")

# build log
bl = open(B / "build_log.txt").read()
m = re.search(r"calibration class3: (\d+) matched sites of (\d+)", bl)
put("VgsMatched", m.group(1), "build_log.txt", "calibration class3 matched"); put("VgsSites", m.group(2), "build_log.txt", "calibration class3 of")
ex = re.findall(r"OSM polygon w\d+ \(([^,]+), ([\d.]+) ha\) excluded by name", bl)
put("NExclPoly", str(len(ex)), "build_log.txt", "count('excluded by name')")
put("ExclPolyHa", f"{sum(float(h) for _, h in ex):.0f}", "build_log.txt", "sum(ha | excluded by name)")
hn = a[a.tunnel_cat.fillna("").ne("") & a.name.fillna("").str.contains("Heinenoord")]
put("NHeinenoord", str(len(hn)), "arcs.csv", "count(tunnel_cat!='' & name~Heinenoord)")

# population
c = np.load(B / "cells.npz")
keys = list(c.keys())
popn = [k for k in keys if "night" in k][0]; popd = [k for k in keys if "day" in k][0]
put("NCells", i(len(c[popn])), "cells.npz", "len(" + popn + ")")
put("PopNight", i(c[popn].sum()), "cells.npz", "sum(" + popn + ")")
put("PopDay", i(c[popd].sum()), "cells.npz", "sum(" + popd + ")")
put("ParkEmp", i(c[popd].sum() - c[popn].sum()), "cells.npz", f"sum({popd})-sum({popn})")

# points
g = pd.read_csv(B / "gen_points.csv"); t = pd.read_csv(B / "attr_points.csv"); gw = pd.read_csv(B / "gateways.csv")
gt = g.type.value_counts(); tt = t.type.value_counts()
put("NGen", i(len(g)), "gen_points.csv", "rows")
for k, nm in (("refinery", "Ref"), ("port", "Port"), ("chemical", "Chem")):
    put(f"NGen{nm}", i(gt.get(k, 0)), "gen_points.csv", f"count(type=='{k}')")
put("NAttr", i(len(t)), "attr_points.csv", "rows")
put("NAttrFuel", i(tt.get("fuel_station", 0)), "attr_points.csv", "count(type=='fuel_station')")
put("NAttrChem", i(tt.get("chemical_firm", 0)), "attr_points.csv", "count(type=='chemical_firm')")
put("NGateways", i(len(gw)), "gateways.csv", "rows")
put("NGenFlag", i(g.needs_manual_check.sum()), "gen_points.csv", "sum(needs_manual_check)")
put("NAttrFlag", i(t.needs_manual_check.sum()), "attr_points.csv", "sum(needs_manual_check)")
put("PortCapMm", f(g.capacity_m3.sum() / 1e6, 2), "gen_points.csv", "sum(capacity_m3)/1e6")
put("RefCapKbd", i(g.capacity_kbd.sum()), "gen_points.csv", "sum(capacity_kbd)")

# OD
load = P["load_t"]["base"]
for sc, nm in (("low", "Low"), ("base", "Base"), ("high", "High"), ("base_calibrated", "Cal")):
    od = pd.read_csv(B / f"od_{sc}.csv")
    put(f"OdRows{nm}", i(len(od)), f"od_{sc}.csv", "rows")
    put(f"OdTons{nm}", f(od.tons_per_year.sum() / 1e4, 1), f"od_{sc}.csv", "sum(tons_per_year)/1e4 (10^4 t)")
    put(f"OdMt{nm}", f(od.tons_per_year.sum() / 1e6, 2), f"od_{sc}.csv", "sum(tons_per_year)/1e6 (Mt)")
    put(f"TripsDay{nm}", i(od.trips_loaded_per_year.sum() / 365), f"od_{sc}.csv", "sum(trips_loaded_per_year)/365")
od = P["od_totals_10kt"]
put("TotBase", str(od["total"]["base"]), "params.yaml", "od_totals_10kt.total.base")
put("TotLow", str(od["total"]["low"]), "params.yaml", "od_totals_10kt.total.low")
put("TotHigh", str(od["total"]["high"]), "params.yaml", "od_totals_10kt.total.high")
put("TotRef", str(od["refinery"]["base"]), "params.yaml", "od_totals_10kt.refinery.base")
put("TotPort", str(od["port"]["base"]), "params.yaml", "od_totals_10kt.port.base")
put("TotChem", str(od["total"]["base"] - od["refinery"]["base"] - od["port"]["base"]), "params.yaml", "total-refinery-port (base)")
put("GatewayShare", str(P["gateway_share"]), "params.yaml", "gateway_share")
put("LoadT", f"{load:g}", "params.yaml", "load_t.base")
gc = pd.read_csv(B / "gravity_convergence.csv")
put("FurnessErr", sci(gc.rel_err.max(), 1), "gravity_convergence.csv", "max(rel_err)")
inst = sorted(p.name for p in (B / "instances").iterdir() if p.is_dir())
put("NInstances", i(len(inst)), "instances/", "count(dirs)")

# calibration
pf = pd.read_csv(B / "plausibility_flows.csv").set_index("hazmat_class")
for hc, nm in (("class3", "Three"), ("class2", "Two")):
    r = pf.loc[hc]
    put(f"Cal{nm}Sites", i(r.n_sites), "plausibility_flows.csv", f"{hc}.n_sites")
    for col, mn in (("ratio_before_median", "RatioBefore"), ("ratio_after_median", "RatioAfter"), ("ratio_before_q1", "QOneBefore"),
                    ("ratio_before_q3", "QThreeBefore"), ("ratio_after_q1", "QOneAfter"), ("ratio_after_q3", "QThreeAfter")):
        put(f"Cal{nm}{mn}", f(r[col]), "plausibility_flows.csv", f"{hc}.{col}")
    put(f"Cal{nm}GehBefore", f(r.GEH_before_median, 1), "plausibility_flows.csv", f"{hc}.GEH_before_median")
    put(f"Cal{nm}GehAfter", f(r.GEH_after_median, 1), "plausibility_flows.csv", f"{hc}.GEH_after_median")
cs = pd.read_csv(B / "calibration_sites.csv").set_index("site")
for z, zn in (("Z65", "ZSixtyFive"), ("Z66", "ZSixtySix"), ("Z151", "ZOneFiftyOne"), ("Z152", "ZOneFiftyTwo")):
    if z in cs.index and cs.loc[z, "obs_class3"] > 0:
        put(f"Site{zn}Ratio", f(cs.loc[z, "model_before_class3"] / cs.loc[z, "obs_class3"]), "calibration_sites.csv", f"{z} model_before_class3/obs_class3")

# QA
qa = {str(q["id"]): q for q in json.load(open(B / "qa_results.json"))}
put("QAAllPass", "yes" if all(q["passed"] for q in qa.values()) else "no", "qa_results.json", "all(passed)")
put("QANChecks", i(len(qa)), "qa_results.json", "count")
d = qa["M"]["detail"]; m = re.search(r"(\d+) Basisnet sections.*?rho\(F, PR10-6 distance\) = ([\d.]+) \(p = ([\d.e-]+)", d)
put("MSections", m.group(1), "qa_results.json", "M.detail sections"); put("MRho", m.group(2), "qa_results.json", "M.detail rho"); put("MP", m.group(3), "qa_results.json", "M.detail p")
m = re.search(r"IR\(30 m\) on the busiest arc ([\d.e+-]+) .*? to ([\d.e+-]+) ", d)
put("IRLow", sci(float(m.group(1)), 2), "qa_results.json", "M.detail legacy IR low"); put("IRHigh", sci(float(m.group(2)), 2), "qa_results.json", "M.detail legacy IR high")
d = qa["P1"]["detail"]; m = re.search(r"OSM motorway\+trunk incl. links (\d+) km vs NWB Rijk \(R\) (\d+) km, ratio ([\d.]+)", d)
put("PoneOsm", m.group(1), "qa_results.json", "P1"); put("PoneNwb", m.group(2), "qa_results.json", "P1"); put("PoneRatio", m.group(3), "qa_results.json", "P1")
d = qa["8"]["detail"]; m = re.search(r"(\d+) rows; labels (\{.*\})", d); lab = eval(m.group(2))
put("SrcRows", m.group(1), "qa_results.json", "8.detail rows")
for k in ("official", "real", "estimated", "assumed"):
    put("Src" + k.capitalize(), str(lab.get(k, 0)), "qa_results.json", f"8.detail labels[{k}]")
put("SrcEstAss", str(lab.get("estimated", 0) + lab.get("assumed", 0)), "qa_results.json", "estimated+assumed")
if "9" in qa:
    m = re.search(r"(\d+)", qa["9"]["detail"]); put("RerunFiles", m.group(1), "qa_results.json", "9.detail first integer"); put("RerunPass", "yes" if qa["9"]["passed"] else "no", "qa_results.json", "9.passed")
d = qa["2"]["detail"]; m = re.search(r"back-projection error ([\d.e+-]+)", d); put("ProjErr", sci(float(m.group(1)), 1), "qa_results.json", "2.detail")
d = qa["3"]["detail"]; m = re.search(r"minimum ratio ([\d.]+)", d); put("MinLenRatio", m.group(1), "qa_results.json", "3.detail")
d = qa["6"]["detail"]; m = re.search(r"weighted mean ([\d.e+-]+)", d); put("QASixLambda", sci(float(m.group(1)), 3), "qa_results.json", "6.detail")
d = qa["10"]["detail"]; m = re.search(r"difference ([\d.e+-]+)", d); put("HarwoodDiff", sci(float(m.group(1)), 1), "qa_results.json", "10.detail")
d = qa["7"]["detail"]; m = re.search(r"distinct destinations (\d+)", d); put("DistinctDest", m.group(1), "qa_results.json", "7.detail")

# baselines
bs = pd.read_csv(B / "_baselines/baseline_summary.csv").set_index("method")
ss = pd.read_csv(B / "_baselines/stats_summary.csv").set_index(["method", "metric"])
meth = {"B1_min_time": "BOne", "B2_min_length": "BTwo", "B3_min_TR_sum": "BThree", "B4_min_PE_sum": "BFour"}
if "B1p_min_pure_time" in bs.index: meth["B1p_min_pure_time"] = "BOneP"
for mt, nm in meth.items():
    put(nm + "T", f(ss.loc[(mt, "T_min"), "median"]), "_baselines/stats_summary.csv", f"{mt} T_min median")
    put(nm + "L", f(ss.loc[(mt, "L_km"), "median"]), "_baselines/stats_summary.csv", f"{mt} L_km median")
    put(nm + "TR", sci(ss.loc[(mt, "TR_sum"), "median"]), "_baselines/stats_summary.csv", f"{mt} TR_sum median")
    put(nm + "PEsum", i(ss.loc[(mt, "PE_sum"), "median"]), "_baselines/stats_summary.csv", f"{mt} PE_sum median")
    put(nm + "PEunion", i(ss.loc[(mt, "PE_union"), "median"]), "_baselines/stats_summary.csv", f"{mt} PE_union median")
    put(nm + "DCR", f(ss.loc[(mt, "DCR_PE"), "median"]), "_baselines/stats_summary.csv", f"{mt} DCR_PE median")
    put(nm + "dT", f(ss.loc[(mt, "dT"), "median"], 3), "_baselines/stats_summary.csv", f"{mt} dT median")
br = pd.read_csv(B / "_baselines/baseline_results.csv")
put("NBaseRows", i(br.groupby("method").size().iloc[0]), "_baselines/baseline_results.csv", "rows per method")
put("NBasePaths", i(len(br)), "_baselines/baseline_results.csv", "rows")
put("NBaseOD", i(br[["instance", "od_id"]].drop_duplicates().shape[0]), "_baselines/baseline_results.csv", "distinct (instance, od_id)")
put("DcrMedian", f(br.DCR_PE.median()), "_baselines/baseline_results.csv", "median(DCR_PE)")
put("DcrMean", f(br.DCR_PE.mean()), "_baselines/baseline_results.csv", "mean(DCR_PE)")
put("DcrQOne", f(br.DCR_PE.quantile(.25)), "_baselines/baseline_results.csv", "q25(DCR_PE)")
put("DcrQThree", f(br.DCR_PE.quantile(.75)), "_baselines/baseline_results.csv", "q75(DCR_PE)")
put("DcrMax", f(br.DCR_PE.max()), "_baselines/baseline_results.csv", "max(DCR_PE)")
for s_, nm in (("benzene", "Benzene"), ("lpg", "Lpg"), ("ammonia", "Ammonia"), ("chlorine", "Chlorine")):
    sub = br[br.substance == s_]
    put("NPaths" + nm, i(len(sub)), "_baselines/baseline_results.csv", f"count(substance=='{s_}')")
    if len(sub):
        put("Dcr" + nm, f(sub.DCR_PE.median()), "_baselines/baseline_results.csv", f"median(DCR_PE | {s_})")
tr = br.TR_sum / br.R_union
put("TrRminRatio", f(tr.min(), 6), "_baselines/baseline_results.csv", "min(TR_sum/R_union)")
put("TrRmaxRatio", f(tr.max(), 6), "_baselines/baseline_results.csv", "max(TR_sum/R_union)")
put("TrRMaxDev", sci((tr - 1).abs().max(), 1), "_baselines/baseline_results.csv", "max|TR_sum/R_union - 1|")
st = pd.read_csv(B / "_baselines/stats_tests.csv")
r = st[(st.metric == "TR_sum") & (st.method_a == "B1_min_time") & (st.method_b == "B3_min_TR_sum")].iloc[0]
put("PHolmTRBOneBThree", sci(r.p_holm, 1), "_baselines/stats_tests.csv", "TR_sum B1 vs B3 p_holm")
r = st[(st.metric == "PE_union") & (st.method_a == "B3_min_TR_sum") & (st.method_b == "B4_min_PE_sum")].iloc[0]
put("PHolmPEuBThreeBFour", f"{r.p_holm:.3g}", "_baselines/stats_tests.csv", "PE_union B3 vs B4 p_holm")
b4 = br[br.method == "B4_min_PE_sum"]
put("SameBThreeBFour", f(b4.same_path_as_B3.mean()), "_baselines/baseline_results.csv", "mean(same_path_as_B3 | B4)")
b3, b1 = ss.loc[("B3_min_TR_sum", "TR_sum"), "median"], ss.loc[("B1_min_time", "TR_sum"), "median"]
put("TRReduction", i(100 * (1 - b3 / b1)), "_baselines/stats_summary.csv", "100*(1 - median TR B3 / median TR B1)")
put("BThreedTpct", i(100 * ss.loc[("B3_min_TR_sum", "dT"), "median"]), "_baselines/stats_summary.csv", "100*median dT B3")

put("ArrBFour", f(ss.loc[("B4_min_PE_sum", "ARR_TR"), "median"]), "_baselines/stats_summary.csv", "B4 ARR_TR median")
put("ArrBTwo", f(ss.loc[("B2_min_length", "ARR_TR"), "median"]), "_baselines/stats_summary.csv", "B2 ARR_TR median")
# sensitivity
sv = pd.read_csv(SENS / "sens_od_summary.csv").set_index("variant")
base = sv.loc["base", "total_cal_10kt"]
dev = 100 * (sv.total_cal_10kt / base - 1)
put("SensCalBase", f(base, 1), SENS / "sens_od_summary.csv", "base total_cal_10kt")
put("SensDevMin", f(dev.min(), 1), SENS / "sens_od_summary.csv", "min 100*(total_cal/base-1)")
put("SensDevMax", f(dev.max(), 1), SENS / "sens_od_summary.csv", "max 100*(total_cal/base-1)")
put("SensGehMax", f(sv.class3_GEH_after_median.max(), 1), SENS / "sens_od_summary.csv", "max class3_GEH_after_median")
put("SensGehMin", f(sv.class3_GEH_after_median.min(), 1), SENS / "sens_od_summary.csv", "min class3_GEH_after_median")

# : toll as generalized time
if P.get("tolls"):
    t0 = P["tolls"][0]
    put("TollEur", f"{t0['toll_eur']:.2f}", "params.yaml", "tolls[0].toll_eur")
    put("VotEurH", f"{P['vot_truck_eur_h']:g}", "params.yaml", "vot_truck_eur_h")
    put("TollMin", f(60 * t0["toll_eur"] / P["vot_truck_eur_h"]), "params.yaml", "60*toll_eur/vot_truck_eur_h")
    put("NTollArcs", str(int((a.get("toll_min", pd.Series(0, index=a.index)) > 0).sum())), "arcs.csv", "count(toll_min>0)")
put("ZOneFiftyTwoObs", i(cs.loc["Z152", "obs_class3"]), "calibration_sites.csv", "Z152 obs_class3")
put("ZSixtyFiveObs", i(cs.loc["Z65", "obs_class3"]), "calibration_sites.csv", "Z65 obs_class3")
# instances table
for K in P["instance_K"]:
    ds = [p_ for p_ in inst if f"_K{K}_" in p_]
    nm = {10: "Ten", 30: "Thirty", 100: "Hundred"}[K]
    put(f"NInst{nm}", str(len(ds)), "instances/", f"count(K={K})")
    dd_ = [pd.read_csv(B / "instances" / x / "od.csv") for x in ds]
    put(f"InstDest{nm}", f(np.mean([x.destination.nunique() for x in dd_]), 1), "instances/*/od.csv", f"mean distinct destinations, K={K}")
    put(f"InstTons{nm}", f(np.mean([x.tons_per_year.sum() for x in dd_]) / 1e4, 1), "instances/*/od.csv", f"mean sum(tons)/1e4, K={K}")
allod = pd.concat([pd.read_csv(B / "instances" / x / "od.csv") for x in inst])
put("InstRowsAll", i(len(allod)), "instances/*/od.csv", "rows")
for s_, nm in (("ammonia", "Ammonia"), ("chlorine", "Chlorine")):
    put("InstRows" + nm, i((allod.substance == s_).sum()), "instances/*/od.csv", f"count(substance=='{s_}')")
put("NInstFiles", str(len(list((B / "instances" / inst[0]).iterdir()))), "instances/" + inst[0], "files per instance")
# data records
put("NDictCols", i(len(pd.read_csv(B / "data_dictionary.csv"))) if (B / "data_dictionary.csv").exists() else "--", "data_dictionary.csv", "rows")
put("NArcCols", i(len(a.columns)), "arcs.csv", "columns")
put("NOdCols", i(len(pd.read_csv(B / "od_base.csv", nrows=1).columns)), "od_base.csv", "columns")
put("NCalSites", i(len(cs)), "calibration_sites.csv", "rows")
put("GehLtFiveThree", i(100 * pf.loc["class3", "share_GEH_after_lt5"]), "plausibility_flows.csv", "100*class3.share_GEH_after_lt5")
put("GehLtFiveTwo", i(100 * pf.loc["class2", "share_GEH_after_lt5"]), "plausibility_flows.csv", "100*class2.share_GEH_after_lt5")
put("ClassTwoSensRatio", f(sv.loc["class2_0.09", "class2_ratio_before_median"]), SENS / "sens_od_summary.csv", "class2_0.09 class2_ratio_before_median")
put("SensCalMin", f(sv.total_cal_10kt.min(), 1), SENS / "sens_od_summary.csv", "min total_cal_10kt")
put("SensCalMax", f(sv.total_cal_10kt.max(), 1), SENS / "sens_od_summary.csv", "max total_cal_10kt")


# ---------------- additions (review 2026-10-20, decision Q. Liu 08:19) ----------------
W_ = B.parents[1]
if "vot_cpi_factor" in P:
    put("VotBaseTwentyTwo", f"{P['vot_base_2022_eur_h']:g}", "params.yaml", "vot_base_2022_eur_h")
    put("VotCpi", f"{P['vot_cpi_factor']:.4f}", "params.yaml", "vot_cpi_factor")
    put("TollMinOld", f(60 * P["tolls"][0]["toll_eur"] / P["vot_base_2022_eur_h"]), "params.yaml", "60*toll_eur/vot_base_2022_eur_h")
    put("VotSens", f"{P['vot_sens_factor'][0]:g}", "params.yaml", "vot_sens_factor[0]")
# before/after toll per-site table ( no toll vs this build), class 3
# B1' and stratified instance
if "B1p_min_pure_time" in bs.index:
    b1p = br[br.method == "B1p_min_pure_time"]
    put("SameBOnePBOne", f(b1p.same_path_as_B1.mean()), "_baselines/baseline_results.csv", "mean(same_path_as_B1 | B1p)")
# review M3 (2026-10-21): DCR_PE on the K=30 and K=100 instances (all methods), by substance, median and IQR; IQR for the stratified instance
for K, kn in ((10, "Ten"), (30, "Thirty"), (100, "Hundred")):
    if K != 10:
        continue
    KB = B / "_baselines/baseline_results.csv"
    if not KB.exists(): continue
    kb = pd.read_csv(KB)
    put("DcrK" + kn + "N", i(len(kb)), KB, "rows (all methods)")
    put("DcrK" + kn, f(kb.DCR_PE.median()), KB, "median DCR_PE"); put("DcrK" + kn + "QOne", f(kb.DCR_PE.quantile(.25)), KB, "q25 DCR_PE"); put("DcrK" + kn + "QThree", f(kb.DCR_PE.quantile(.75)), KB, "q75 DCR_PE")
    for s_, nm in (("benzene", "Benzene"), ("lpg", "Lpg"), ("ammonia", "Ammonia"), ("chlorine", "Chlorine")):
        x = kb[kb.substance == s_]
        put("DcrK" + kn + nm + "N", i(len(x)), KB, f"rows | {s_}")
        put("DcrK" + kn + nm, f(x.DCR_PE.median()) if len(x) else "--", KB, f"median DCR_PE | {s_}")
        put("DcrK" + kn + nm + "Iqr", (f(x.DCR_PE.quantile(.25)) + "--" + f(x.DCR_PE.quantile(.75))) if len(x) else "--", KB, f"IQR DCR_PE | {s_}")
# VoT sensitivity
if "vot_x1.5" in sv.index:
    for col, nm in (("total_cal_10kt", "VotSensCal"), ("class3_ratio_before_median", "VotSensRatioThree"), ("class2_ratio_before_median", "VotSensRatioTwo"), ("class3_GEH_after_median", "VotSensGehThree")):
        put(nm, f(sv.loc["vot_x1.5", col], 1 if "cal" in col or "GEH" in col else 2), SENS / "sens_od_summary.csv", f"vot_x1.5 {col}")
    put("SensBaseRatioThree", f(sv.loc["base", "class3_ratio_before_median"]), SENS / "sens_od_summary.csv", "base class3_ratio_before_median")
    put("NSensVariants", str(len(sv)), SENS / "sens_od_summary.csv", "rows")
# context figures (DATA_SOURCES.csv)
ds = pd.read_csv(B / "DATA_SOURCES.csv").set_index("item")
if "hazmat road transport Netherlands (context)" in ds.index:
    put("CbsRoadDgMt", re.match(r"([\d.]+)", str(ds.loc["hazmat road transport Netherlands (context)", "value"])).group(1), "DATA_SOURCES.csv", "hazmat road transport Netherlands (context) value")
tr_ = str(ds.loc["toll A24 Blankenburgverbinding (trucks)", "derivation"]) if "toll A24 Blankenburgverbinding (trucks)" in ds.index else ""
m_ = re.search(r"EUR ([\d.]+)/km Euro VI", tr_); m2 = re.search(r"difference over ([\d.]+) km < EUR ([\d.]+)", tr_)
if m_ and m2:
    put("TruckChargeKm", m_.group(1), "DATA_SOURCES.csv", "toll A24 derivation: EUR x/km Euro VI"); put("TollAltKm", m2.group(1), "DATA_SOURCES.csv", "toll A24 derivation: difference over x km"); put("TruckChargeDiff", f"{float(m2.group(2)):.2f}", "DATA_SOURCES.csv", "toll A24 derivation: < EUR x")
put("VgsLFSum", i(cs.obs_class3.sum()), "calibration_sites.csv", "sum(obs_class3) over all VGS sections")
put("VgsSecs", i(len(cs)), "calibration_sites.csv", "rows")
FR = OUT / "figures/fig4_route.json"
if FR.exists():
    fr = json.load(open(FR)); rr = fr["rows"]
    put("FigRouteSub", fr["substance"], FR, "substance"); put("FigRouteInst", fr["instance"].replace("_", "\\_"), FR, "instance")
    for mt, nm in (("B1_min_time", "BOne"), ("B3_min_TR_sum", "BThree"), ("B1p_min_pure_time", "BOneP")):
        if mt in rr:
            put("FigRoute" + nm + "T", f(rr[mt]["T_min"], 1), FR, f"{mt} T_min"); put("FigRoute" + nm + "L", f(rr[mt]["L_km"], 1), FR, f"{mt} L_km")
    put("FigRouteTRRed", i(100 * (1 - rr["B3_min_TR_sum"]["TR_sum"] / rr["B1_min_time"]["TR_sum"])), FR, "100*(1-TR B3/TR B1)")

# release manifest
if REL != "-":
    R_ = Path(REL); lines = [l for l in open(R_ / "SHA256SUMS") if l.strip()]
    put("RelFiles", i(len(lines)), R_ / "SHA256SUMS", "lines")
    size = sum((R_ / l.split(None, 1)[1].strip().lstrip("*")).stat().st_size for l in lines)
    put("RelMB", i(size / 1e6), R_ / "SHA256SUMS", "sum(file sizes)/1e6")


# value-of-time sweep (work/vot_sens, approved Q. Liu 2026-10-20 15:49)
VS = Path(__file__).resolve().parents[2] / "work/vot_sens/run/sens_od_summary.csv"
if VS.exists():
    KIM = "KiM (Knoope 2023) Tables S2/5.1, kimnet.nl"
    put("KimVotCont", "63.6", KIM, "road freight VTT container, EUR/h per vehicle, price level 2022 incl. VAT")
    put("KimVotNonCont", "63.1", KIM, "road freight VTT non-container")
    put("KimVotSensPct", "5", KIM, "advised +-% sensitivity (Table S2 note 1)")
    vs = pd.read_csv(VS).set_index("variant"); fac = [v for v in vs.index if v.startswith("vot_x")]
    fl = lambda v: float(v[5:])
    put("VotSweepMin", f"{min(map(fl, fac)):g}", VS, "min factor"); put("VotSweepMax", f"{max(map(fl, fac)):g}", VS, "max factor")
    put("VotSweepN", str(len(vs)), VS, "rows")
    put("VotSwCalMin", f(vs.total_cal_10kt.min(), 1), VS, "min total_cal_10kt"); put("VotSwCalMax", f(vs.total_cal_10kt.max(), 1), VS, "max total_cal_10kt")
    put("VotSwRatioMin", f(vs.class3_ratio_before_median.min()), VS, "min class3_ratio_before_median"); put("VotSwRatioMax", f(vs.class3_ratio_before_median.max()), VS, "max class3_ratio_before_median")
    put("VotSwGehMin", f(vs.class3_GEH_after_median.min(), 1), VS, "min class3_GEH_after_median"); put("VotSwGehMax", f(vs.class3_GEH_after_median.max(), 1), VS, "max class3_GEH_after_median")
    W = {"0.5": "Half", "0.75": "ThreeQ", "0.95": "LowFive", "1": "One", "1.05": "HighFive", "1.25": "OneQ", "1.5": "OneHalf", "2": "Two", "3": "Three"}
    for v in fac:
        put("VotZ" + W[v[5:]], f(vs.loc[v, "Z152_class3_ratio_before"]), VS, f"{v} Z152_class3_ratio_before")
    put("VotZNoToll", f(vs.loc["no_toll", "Z152_class3_ratio_before"]), VS, "no_toll Z152_class3_ratio_before")
    put("VotZHalfGeh", f(vs.loc["vot_x0.5", "Z152_class3_GEH_after"], 1), VS, "vot_x0.5 Z152_class3_GEH_after")
    rows_ = []
    for v, r in vs.iterrows():
        lab = "no toll" if v == "no_toll" else "$\\times$" + v[5:]
        rows_.append(f"{lab} & {'--' if v == 'no_toll' else f(r.vot_eur_h, 1)} & {f(r.toll_min)} & {f(r.Z152_class3_ratio_before)} & {f(r.Z152_class3_ratio_after)} & {f(r.class3_ratio_before_median)} & {f(r.class3_GEH_after_median, 1)} & {f(r.total_cal_10kt, 1)} \\\\")
    put("VotSweepRows", "\n".join(rows_), VS, "table rows: vot_eur_h, toll_min, Z152_class3_ratio_before/after, class3_ratio_before_median, class3_GEH_after_median, total_cal_10kt")

with open(OUT / "numbers.tex", "w") as fh:
    fh.write("% produced by code/scripts/make_paper_numbers.py; do not edit\n")
    for k, v in M.items():
        fh.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
with open(OUT / "numbers_trace.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["macro", "value", "file", "expression"]); w.writeheader(); w.writerows(T)
print(f"{len(M)} macros -> {OUT}")
