"""Review minor items 10, 11, 13 (review_expert_20261021.md, section 4):
  python scripts/minor_sens.py <dataset_dir> <out_dir> <instance>[,<instance>...]
 (10) B5: heuristic for the non-additive PE_union. Pool = {B1, B3, B4} plus up to 5 discount iterations: arc weight
      w_e = sum_{c in C(e)} P_c / m_c, m_c = number of arcs of the current best path covering cell c (1 if none); keep the path with the
      smallest PE_union. Restricted routing as in the baselines. Never worse than B4 by construction.
 (11) ERG radius x0.5 / x1.0 / x1.5: PE_sum, PE_union, DCR_PE recomputed on the fixed B1 and B4 paths (cells within r of the path arcs,
      same rule as build.cellsets: cell centre within r of the arc polyline, EPSG:28992). x1.0 must reproduce the dataset values.
 (13) 1 km aggregation of facility endpoints (G*, A* ids): each endpoint moved to the graph node nearest to the centre of its 1 km RD cell
      (first such node from which/to which a restricted path exists); B1 and B3 recomputed; compared with the original rows.
Writes b5_rows.csv, radius_rows.csv, agg1km_rows.csv and minor_summary.csv."""
import sys, time, json
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx, shapely
from pyproj import Transformer
from scipy.spatial import cKDTree
from scipy.stats import spearmanr
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hazbench.metrics import Bench

def sp_w(b, o, d, sub, w):
    fb = b.forbidden(sub) if b.tf else np.zeros(len(w), bool)
    return nx.shortest_path(b.G, o, d, weight=lambda u, v, e: None if fb[e["k"]] else w[e["k"]] + 1e-12)

def b5(b, o, d, sub, base_paths, it=5):
    M = b.cells(sub); best = min(base_paths, key=lambda p: b.path_metrics(p, sub)["PE_union"]); bestv = b.path_metrics(best, sub)["PE_union"]; n_it = 0
    for _ in range(it):
        ks = b.arc_ids(best); m = np.ones(M.shape[1]); np.add.at(m, M[ks].indices, 1.0); m[np.unique(M[ks].indices)] -= 1.0
        w = M @ (b.Pc / m); p = sp_w(b, o, d, sub, np.asarray(w).ravel()); v = b.path_metrics(p, sub)["PE_union"]; n_it += 1
        if v < bestv - 1e-9: best, bestv = p, v
        else: break
    return best, n_it

def main(D, OUT, insts):
    D, OUT = Path(D), Path(OUT); OUT.mkdir(parents=True, exist_ok=True); b = Bench(D)
    radii = pd.read_csv(D / "erg2024_radii.csv").set_index("substance").primary_radius_km * 1000
    c = np.load(D / "cells.npz"); tree = cKDTree(np.c_[c["x_rd"], c["y_rd"]]); cpts = shapely.points(c["x_rd"], c["y_rd"])
    T = Transformer.from_crs(4326, 28992, always_xy=True); geom = {}
    for ft in json.load(open(D / "arcs.geojson"))["features"]:
        xy = np.array(ft["geometry"]["coordinates"]); x, y = T.transform(xy[:, 0], xy[:, 1]); geom[(ft["properties"]["u"], ft["properties"]["v"])] = shapely.linestrings(np.c_[x, y])
    G = [geom[(u, v)] for u, v in zip(b.arcs.u, b.arcs.v)]; cache = {}
    def cellset(k, r):
        if (k, r) not in cache:
            g = G[k]; pts = shapely.get_coordinates(shapely.segmentize(g, 25.0))
            cand = np.unique(np.concatenate([np.asarray(z, dtype=np.int64) for z in tree.query_ball_point(pts, r + 25.0)]))
            cache[(k, r)] = cand[shapely.dwithin(cpts[cand], g, r)] if len(cand) else cand
        return cache[(k, r)]
    nodes = pd.read_csv(D / "nodes.csv"); innodes = nodes[nodes.node.isin(set(b.G.nodes))]; ntree = cKDTree(innodes[["x_rd", "y_rd"]].values); nxy = nodes.set_index("node")[["x_rd", "y_rd"]]
    def agg(node):
        x, y = nxy.loc[node]; cx, cy = (np.floor(x / 1000) + 0.5) * 1000, (np.floor(y / 1000) + 0.5) * 1000
        _, ii = ntree.query([cx, cy], k=20); return [int(innodes.node.values[j]) for j in ii]
    R5, RR, RA = [], [], []
    for inst in insts:
        od = pd.read_csv(D / f"instances/{inst}/od.csv")
        for q in od.itertuples():
            s, o, d = q.substance, q.origin, q.destination
            p1 = b.shortest(o, d, "t", s); p3 = b.shortest(o, d, "TR", s); p4 = b.shortest(o, d, "PE", s)
            t0 = time.time(); p5, n_it = b5(b, o, d, s, [p1, p3, p4]); sec = time.time() - t0
            m = {k: b.path_metrics(p, s) for k, p in (("B1", p1), ("B3", p3), ("B4", p4), ("B5", p5))}
            R5.append(dict(instance=inst, od_id=q.od_id, substance=s, **{f"PEu_{k}": v["PE_union"] for k, v in m.items()}, **{f"T_{k}": v["T"] for k, v in m.items()},
                           TR_B5=m["B5"]["TR_sum"], TR_B4=m["B4"]["TR_sum"], n_iter=n_it, sec=sec, B5_differs_from_B4=p5 != p4))
            for meth, p in (("B1", p1), ("B4", p4)):
                ks = b.arc_ids(p)
                for f in (0.5, 1.0, 1.5):
                    r = float(radii[s]) * f; sets = [cellset(k, r) for k in ks]
                    pe_sum = float(sum(b.Pc[z].sum() for z in sets)); cov = np.unique(np.concatenate(sets)) if sets else np.array([], int); pe_u = float(b.Pc[cov].sum())
                    RR.append(dict(instance=inst, od_id=q.od_id, substance=s, method=meth, radius_factor=f, radius_m=r, PE_sum=pe_sum, PE_union=pe_u,
                                   DCR_PE=pe_sum / pe_u if pe_u > 0 else np.nan, PE_union_dataset=m[meth]["PE_union"], PE_sum_dataset=m[meth]["PE_sum"]))
# 1 km aggregation
            oo = agg(o) if str(q.origin_id)[0] in "GA" else [o]; dd = agg(d) if str(q.dest_id)[0] in "GA" else [d]; got = None
            for o2 in oo:
                for d2 in dd:
                    if o2 == d2: continue
                    try: got = (o2, d2, b.shortest(o2, d2, "t", s), b.shortest(o2, d2, "TR", s)); break
                    except nx.NetworkXNoPath: continue
                if got: break
            if got:
                o2, d2, a1, a3 = got; ma1, ma3 = b.path_metrics(a1, s), b.path_metrics(a3, s)
                RA.append(dict(instance=inst, od_id=q.od_id, substance=s, moved_o_m=float(np.hypot(*(nxy.loc[o2] - nxy.loc[o]))), moved_d_m=float(np.hypot(*(nxy.loc[d2] - nxy.loc[d]))),
                               TR_B1=m["B1"]["TR_sum"], TR_B1_agg=ma1["TR_sum"], TR_B3=m["B3"]["TR_sum"], TR_B3_agg=ma3["TR_sum"], PEu_B1=m["B1"]["PE_union"], PEu_B1_agg=ma1["PE_union"],
                               DCR_B1=m["B1"]["DCR_PE"], DCR_B1_agg=ma1["DCR_PE"], T_B1=m["B1"]["T"], T_B1_agg=ma1["T"]))
            else:
                RA.append(dict(instance=inst, od_id=q.od_id, substance=s, failed=True))
        print(inst, len(R5), flush=True)
    r5, rr, ra = pd.DataFrame(R5), pd.DataFrame(RR), pd.DataFrame(RA)
    r5.to_csv(OUT / "b5_rows.csv", index=False); rr.to_csv(OUT / "radius_rows.csv", index=False); ra.to_csv(OUT / "agg1km_rows.csv", index=False)
    S = []
    red = 1 - r5.PEu_B5 / r5.PEu_B4
    S += [("b5_n", len(r5)), ("b5_share_improved", float((red > 1e-9).mean())), ("b5_red_median_improved", float(red[red > 1e-9].median()) if (red > 1e-9).any() else 0.0),
          ("b5_red_max", float(red.max())), ("b5_sum_PEu_B4", float(r5.PEu_B4.sum())), ("b5_sum_PEu_B5", float(r5.PEu_B5.sum())),
          ("b5_dT_median_vs_B1", float((r5.T_B5 / r5.T_B1 - 1).median())), ("b5_sec_median", float(r5.sec.median())), ("b5_iter_max", int(r5.n_iter.max()))]
    one = rr[rr.radius_factor == 1.0]; S += [("rad_x1_max_abs_dev_PEunion", float((one.PE_union - one.PE_union_dataset).abs().max())), ("rad_x1_max_abs_dev_PEsum", float((one.PE_sum - one.PE_sum_dataset).abs().max()))]
    for meth in ("B1", "B4"):
        for f in (0.5, 1.0, 1.5):
            g = rr[(rr.method == meth) & (rr.radius_factor == f)].DCR_PE.dropna()
            S += [(f"rad_{meth}_x{f}_DCR_median", float(g.median())), (f"rad_{meth}_x{f}_DCR_q1", float(g.quantile(.25))), (f"rad_{meth}_x{f}_DCR_q3", float(g.quantile(.75)))]
        for s_ in sorted(rr.substance.unique()):
            for f in (0.5, 1.0, 1.5):
                S.append((f"rad_{meth}_{s_}_x{f}_DCR_median", float(rr[(rr.method == meth) & (rr.radius_factor == f) & (rr.substance == s_)].DCR_PE.median())))
    ok = ra[ra.get("failed", pd.Series(False, index=ra.index)).fillna(False) == False] if "failed" in ra else ra
    S += [("agg_n", len(ra)), ("agg_ok", len(ok)), ("agg_moved_median_m", float(pd.concat([ok.moved_o_m, ok.moved_d_m]).median())),
          ("agg_rho_TR_B1", float(spearmanr(ok.TR_B1, ok.TR_B1_agg).statistic)), ("agg_rho_TR_B3", float(spearmanr(ok.TR_B3, ok.TR_B3_agg).statistic)),
          ("agg_TR_B1_ratio_median", float((ok.TR_B1_agg / ok.TR_B1).median())), ("agg_DCR_B1_median", float(ok.DCR_B1.median())), ("agg_DCR_B1_agg_median", float(ok.DCR_B1_agg.median())),
          ("agg_B3_red_median", float((1 - ok.TR_B3 / ok.TR_B1).median())), ("agg_B3_red_agg_median", float((1 - ok.TR_B3_agg / ok.TR_B1_agg).median())),
          ("agg_sumPLLratio_B1", float((ok.TR_B1_agg).sum() / ok.TR_B1.sum()))]
    pd.DataFrame(S, columns=["key", "value"]).to_csv(OUT / "minor_summary.csv", index=False); print(pd.DataFrame(S).to_string())

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3].split(","))
