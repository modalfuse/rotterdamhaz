# hazbench

Builder for the RotterdamHaz benchmark. Paths, coordinates and model parameters are in `regions/rotterdam.yaml` and `regions/rotterdam.params.yaml`.

## Layout

- `hazbench/`: configuration, OSM extract and graph, build, calibration, QA, baselines, statistics
- `regions/`: Rotterdam configuration, plus shared ERG radii and Harwood accident rates
- `scripts/run_region.sh`: one-command run
- `requirements.lock.txt`: pinned dependencies

## Setup

```
python3 -m venv .venv && .venv/bin/pip install -r requirements.lock.txt
```

## Run

```
export RIJNMOND_ROOT=<project root>
export RIJNMOND_WORK=<work dir>
scripts/run_region.sh regions/rotterdam.yaml <out_dir>
```

The program refuses to write into a non-empty output directory that it did not create.
