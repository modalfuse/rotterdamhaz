"""Statistics for baseline / method comparisons (evaluation protocol): per method median, Q1, Q3, IQR; paired two-sided Wilcoxon
signed-rank tests on the same OD rows (zero differences dropped, method 'wilcox'), Holm-Bonferroni correction within each metric.
  python -m hazbench.stats <baseline_results.csv> <out_dir> [--metrics T_min,TR_sum,...] [--ref B1_min_time]
Writes stats_summary.csv, stats_tests.csv, stats_report.md. Without --ref all method pairs are tested."""
import argparse, itertools
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import wilcoxon

DEFAULT = ["T_min", "L_km", "TR_sum", "R_union", "PE_sum", "PE_union", "DCR_PE", "dT", "ARR_TR"]

def holm(p):
    p = np.asarray(p, float); m = np.isfinite(p).sum(); out = np.full(len(p), np.nan); order = np.argsort(np.where(np.isfinite(p), p, np.inf)); run = 0.0
    for r, i in enumerate(order[:m]): run = max(run, min(1.0, (m - r) * p[i])); out[i] = run
    return out

def summarise(df, metrics, key=("instance", "od_id")):
    rows = []
    for meth, g in df.groupby("method", sort=True):
        for mt in metrics:
            x = g[mt].astype(float).dropna()
            q1, med, q3 = (np.percentile(x, [25, 50, 75]) if len(x) else [np.nan] * 3)
            rows.append(dict(method=meth, metric=mt, n=len(x), median=med, q1=q1, q3=q3, iqr=q3 - q1, mean=x.mean()))
    return pd.DataFrame(rows)

def tests(df, metrics, ref=None, key=("instance", "od_id")):
    W = {mt: df.pivot_table(index=list(key), columns="method", values=mt, aggfunc="first") for mt in metrics}
    meths = sorted(df.method.unique()); pairs = [(ref, m) for m in meths if m != ref] if ref else list(itertools.combinations(meths, 2))
    rows = []
    for mt in metrics:
        w = W[mt]; part = []
        for a, b in pairs:
            d = (w[b] - w[a]).dropna(); nz = d[np.abs(d) > 1e-12 * np.maximum(1, np.abs(w[a].reindex(d.index)))]
            if len(nz) == 0: stat, p = np.nan, 1.0
            else:
                r = wilcoxon(nz.values, zero_method="wilcox", alternative="two-sided"); stat, p = float(r.statistic), float(r.pvalue)
            part.append(dict(metric=mt, method_a=a, method_b=b, n_pairs=len(d), n_nonzero=len(nz), n_b_lower=int((nz < 0).sum()), n_b_higher=int((nz > 0).sum()),
                             median_diff=float(d.median()) if len(d) else np.nan, W=stat, p=p))
        ph = holm([x["p"] for x in part])
        for x, h in zip(part, ph): x["p_holm"] = h; x["sig_0.05"] = bool(h < 0.05)
        rows += part
    return pd.DataFrame(rows)

def main(a=None):
    ap = argparse.ArgumentParser(); ap.add_argument("results"); ap.add_argument("out"); ap.add_argument("--metrics", default=",".join(DEFAULT)); ap.add_argument("--ref", default=None)
    A = ap.parse_args(a); df = pd.read_csv(A.results); out = Path(A.out); out.mkdir(parents=True, exist_ok=True)
    metrics = [m for m in A.metrics.split(",") if m in df]
    S = summarise(df, metrics); Tt = tests(df, metrics, A.ref)
    S.to_csv(out / "stats_summary.csv", index=False); Tt.to_csv(out / "stats_tests.csv", index=False)
    md = ["# Baseline statistics", "", f"OD rows per method: {df.groupby('method').size().to_dict()}", "", "## Median [Q1, Q3] (IQR)", "",
          "| metric | " + " | ".join(sorted(df.method.unique())) + " |", "|---|" + "---|" * df.method.nunique()]
    for mt in metrics:
        s = S[S.metric == mt].set_index("method"); md.append(f"| {mt} | " + " | ".join(f"{r['median']:.4g} [{r.q1:.4g}, {r.q3:.4g}] ({r.iqr:.3g})" for _, r in s.iterrows()) + " |")
    md += ["", "## Paired Wilcoxon signed-rank (two-sided), Holm-corrected within metric", "", "| metric | a | b | n | non-zero | b<a | b>a | median(b-a) | p | p_Holm |", "|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in Tt.iterrows(): md.append(f"| {r.metric} | {r.method_a} | {r.method_b} | {r.n_pairs} | {r.n_nonzero} | {r.n_b_lower} | {r.n_b_higher} | {r.median_diff:.4g} | {r.p:.3g} | {r.p_holm:.3g} |")
    if "same_path_as_B3" in df:
        sp = df[df.method == "B4_min_PE_sum"].same_path_as_B3.mean(); md += ["", f"Share of OD rows where B4 selects the same path as B3: {sp:.2f}"]
    (out / "stats_report.md").write_text("\n".join(md) + "\n"); print("\n".join(md))

if __name__ == "__main__":
    main()
