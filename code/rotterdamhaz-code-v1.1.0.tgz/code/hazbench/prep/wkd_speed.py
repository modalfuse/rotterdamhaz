"""Legal speed limit per network arc from the Rijkswaterstaat Wegkenmerkendatabase (WKD 'Snelheden', keyed by NWB wegvak id), for the
built-up / non-built-up road type of the Dutch accident frequencies (RBM II: binnen / buiten de bebouwde kom). 
  python -m hazbench.prep.wkd_speed regions/<region>.yaml
Region YAML block `wkd_speed`:
  wkd_gpkg, wkd_layer          WKD Snelheden (WVK_ID, MAXSHD, BEGINTIJD, VAN, NAAR); time-dependent rows (BEGINTIJD set) are ignored
  nwb_gpkg, nwb_layer          NWB wegvakken (wvk_id, geometry, EPSG:28992)
  sample_m: 25                 arc geometry sampled every sample_m (segment midpoints)
  max_dist_m: 20               a sample is matched to the nearest NWB wegvak within max_dist_m ...
  max_angle_deg: 30            ... if both run within max_angle_deg of parallel
  out                          CSV: u, v, wkd_maxspeed (length-weighted median of the matched samples, km/h), wkd_match_frac, wkd_n
Per wegvak the speed is the limit covering the largest part of it (VAN-NAAR); NVT / NOA / missing are left unmatched."""
import sys, json
import numpy as np, pandas as pd, pyogrio, shapely
from pyproj import Transformer
from ..config import load

def run(R):
    C = R["wkd_speed"]; T = Transformer.from_crs(R["crs"]["geographic"], R["crs"]["projected"], always_xy=True)
    arcs = pd.read_csv(R.path("network", "arcs")); gj = json.load(open(R.path("network", "geojson")))
    G = [shapely.LineString(np.c_[T.transform(*np.array(f["geometry"]["coordinates"]).T)]) for f in gj["features"]]
    box = shapely.union_all(G).envelope.buffer(200)
    nwb = pyogrio.read_dataframe(R.resolve(C["nwb_gpkg"]), layer=C.get("nwb_layer", "wegvakken"), columns=["wvk_id"], bbox=tuple(box.bounds))
    w = pyogrio.read_dataframe(R.resolve(C["wkd_gpkg"]), layer=C.get("wkd_layer", "Snelheden"), read_geometry=False, columns=["WVK_ID", "MAXSHD", "BEGINTIJD", "VAN", "NAAR"])
    w = w[w.WVK_ID.isin(set(nwb.wvk_id)) & w.BEGINTIJD.isna()].copy()
    w["kmh"] = pd.to_numeric(w.MAXSHD, errors="coerce"); w["len"] = (w.NAAR - w.VAN).abs()
    w = w[w.kmh.notna()].groupby(["WVK_ID", "kmh"], as_index=False).len.sum().sort_values(["WVK_ID", "len", "kmh"], ascending=[True, False, True]).drop_duplicates("WVK_ID")
    sp = dict(zip(w.WVK_ID, w.kmh)); nwb["kmh"] = nwb.wvk_id.map(sp); nwb = nwb[nwb.kmh.notna()].reset_index(drop=True)
    NG = nwb.geometry.values; tree = shapely.STRtree(NG); step = C.get("sample_m", 25); md = C.get("max_dist_m", 20); ca = np.cos(np.radians(C.get("max_angle_deg", 30)))
# sample points: midpoints of ~step m pieces of every arc, with the local direction
    pts, dirs, owner, wts = [], [], [], []
    for i, g in enumerate(G):
        L = g.length; n = max(1, int(np.ceil(L / step))); t = (np.arange(n) + 0.5) * L / n
        a = shapely.line_interpolate_point(g, np.maximum(t - 5, 0)); b = shapely.line_interpolate_point(g, np.minimum(t + 5, L))
        d = shapely.get_coordinates(b) - shapely.get_coordinates(a); d /= np.maximum(np.linalg.norm(d, axis=1), 1e-9)[:, None]
        pts.append(shapely.line_interpolate_point(g, t)); dirs.append(d); owner.append(np.full(n, i)); wts.append(np.full(n, L / n))
    P_ = np.concatenate(pts); D_ = np.concatenate(dirs); O_ = np.concatenate(owner); W_ = np.concatenate(wts)
    qi, qn = tree.query(P_, predicate="dwithin", distance=md)# all candidates within md
    pc = shapely.get_coordinates(P_)[qi]
    proj = shapely.line_locate_point(NG[qn], P_[qi])
    a = shapely.get_coordinates(shapely.line_interpolate_point(NG[qn], np.maximum(proj - 5, 0))); b = shapely.get_coordinates(shapely.line_interpolate_point(NG[qn], proj + 5))
    dn = b - a; dn /= np.maximum(np.linalg.norm(dn, axis=1), 1e-9)[:, None]
    par = np.abs((dn * D_[qi]).sum(1)) >= ca; dist = shapely.distance(P_[qi], NG[qn])
    cand = pd.DataFrame({"p": qi, "n": qn, "d": dist})[par].sort_values(["p", "d"]).drop_duplicates("p")
    kmh = np.full(len(P_), np.nan); kmh[cand.p.values] = nwb.kmh.values[cand.n.values]
    df = pd.DataFrame({"arc": O_, "kmh": kmh, "w": W_})
    rows = []
    for i, g_ in df.groupby("arc"):
        m = g_[g_.kmh.notna()]; frac = m.w.sum() / g_.w.sum()
        if len(m):
            o = m.sort_values("kmh"); c = o.w.cumsum(); med = float(o.kmh.values[np.searchsorted(c.values, c.values[-1] / 2)])
        else: med = np.nan
        rows.append((i, med, round(frac, 3), len(m)))
    r = pd.DataFrame(rows, columns=["arc", "wkd_maxspeed", "wkd_match_frac", "wkd_n"]).set_index("arc").reindex(range(len(G)))
    out = pd.DataFrame({"u": arcs.u, "v": arcs.v, "wkd_maxspeed": r.wkd_maxspeed.values, "wkd_match_frac": r.wkd_match_frac.fillna(0).values, "wkd_n": r.wkd_n.fillna(0).astype(int).values})
    p = R.resolve(C["out"]); p.parent.mkdir(parents=True, exist_ok=True); out.to_csv(p, index=False)
    cls = arcs.road_class.str.replace("_link", "", regex=False)
    print(f"wkd_speed: NWB wegvakken with a WKD limit {len(nwb)}; arcs with >=50% matched {(out.wkd_match_frac >= 0.5).sum()} / {len(out)} -> {p}")
    print(pd.crosstab(cls, out.wkd_maxspeed.where(out.wkd_match_frac >= 0.5).fillna(-1)).to_string())

if __name__ == "__main__":
    run(load(sys.argv[1], sys.argv[2:]))
