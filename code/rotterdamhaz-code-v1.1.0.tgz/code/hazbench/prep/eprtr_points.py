"""EEA Industrial Reporting (E-PRTR / IED) site map -> facility points CSV for the builder (facilities.points).
  python -m hazbench.prep.eprtr_points regions/<region>.yaml
Region YAML facilities.eprtr: {gpkg, country, min_year, type_rules: [[regex on eprtr_AnnexIActivity, type], ...], drop_unmatched}
Keeps each site's latest reporting year (>= min_year) inside params.petro_zone_bbox. Output columns: lon, lat, type, source_id, name
(name is kept only in this input file for manual checking; the builder writes pseudonymous ids)."""
import re, sys
import pandas as pd, pyogrio
from ..config import load

def run(R):
    c = R["facilities"]["eprtr"]; W, S, E, N = R["P"]["petro_zone_bbox"]
    df = pyogrio.read_dataframe(R.resolve(c["gpkg"]), read_geometry=False,
                                where=f"countryCode='{c['country']}' AND x_4258 BETWEEN {W} AND {E} AND y_4258 BETWEEN {S} AND {N}")
    df = df.sort_values("Site_reporting_year").drop_duplicates("InspireSiteId", keep="last")
    df = df[df.Site_reporting_year >= c.get("min_year", 2020)]
    act = df.eprtr_AnnexIActivity.fillna("")
    typ = pd.Series([next((t for rx, t in c["type_rules"] if re.search(rx, a)), None) for a in act], index=df.index)
    out = pd.DataFrame({"lon": df.x_4258, "lat": df.y_4258, "type": typ, "source_id": df.InspireSiteId, "name": df.siteName, "activity": act, "year": df.Site_reporting_year})
    if c.get("drop_unmatched", True): out = out[out.type.notna()]
    out = out.sort_values(["type", "source_id"]).reset_index(drop=True)
    p = R.resolve(c.get("out") or R["facilities"]["points"]); p.parent.mkdir(parents=True, exist_ok=True); out.to_csv(p, index=False)
    print(f"eprtr_points: {len(out)} sites {out.type.value_counts().to_dict()} -> {p}")

if __name__ == "__main__":
    run(load(sys.argv[1], sys.argv[2:]))
