"""Per-arc hazmat status table for the builder (region network.hazmat_status_csv): Basisnet road sections + ADR tunnel categories.
  python -m hazbench.prep.hazmat_status regions/<region>.yaml
Region YAML block `hazmat_status`:
  basisnet_csv: Regeling basisnet Bijlage I, parsed rows (wegvak nr, name, PR 10-6, PR 10-7, BVG, bijzonderheden)
  sections_kmz: Rijkswaterstaat 'Wegvakken Nederland.kmz' (one hand-digitised polyline per Basisnet section; zip!inner allowed)
  match: {classes: [...], buffer_m: 75, min_along_frac: 0.7}   arc main classes only; an arc is matched to a section if it lies inside
         the buffer of the section polyline and its projection onto the polyline covers >= min_along_frac of its length (parallel test)
  tunnels: [{name, cat, ref|osm_name, bbox: [W,S,E,N]}]   OSM ways with tunnel=yes and the given ref / OSM name inside bbox; an arc is a tunnel
         arc if it has the OSM class of one of those ways and >= min_overlap_m (default 50 m) of it lies within 10 m of them
Output columns: u, v, hazmat_status (allowed_corridor | unknown), restrict_time, restrict_src, tunnel_cat (A-E or empty), basisnet_section.
Approximate by construction (hand-drawn section lines, OSM tunnel tags); review before release."""
import re, sys, io, json, csv, zipfile, pickle
import numpy as np, pandas as pd, shapely
from pyproj import Transformer
from ..config import load

def kmz_lines(path):
    path = str(path)
    if "!" in path: outer, inner = path.split("!", 1); z = zipfile.ZipFile(io.BytesIO(zipfile.ZipFile(outer).read(inner)))
    else: z = zipfile.ZipFile(path)
    kml = z.read([n for n in z.namelist() if n.endswith(".kml")][0]).decode("utf-8", "replace"); out = {}
    for pm in re.findall(r"<Placemark[^>]*>.*?</Placemark>", kml, re.S):
        nm = re.search(r"<name>(.*?)</name>", pm, re.S); co = re.findall(r"<LineString>.*?<coordinates>(.*?)</coordinates>", pm, re.S)
        if nm and co: out.setdefault(nm.group(1).strip(), []).extend([[tuple(map(float, p.split(",")[:2])) for p in c.split()] for c in co])
    return out

def run(R):
    C = R["hazmat_status"]; T = Transformer.from_crs(R["crs"]["geographic"], R["crs"]["projected"], always_xy=True)
    arcs = pd.read_csv(R.path("network", "arcs")); gj = json.load(open(R.path("network", "geojson")))
    G = [shapely.LineString(np.c_[T.transform(*np.array(f["geometry"]["coordinates"]).T)]) for f in gj["features"]]
    L = np.array([g.length for g in G])
# Basisnet sections
    rows = [r for r in csv.reader(open(R.resolve(C["basisnet_csv"]), encoding="utf-8")) if r and re.match(r"^[A-Z][a-z]?\d+[a-z]?$", r[0])]
    bn = {r[0]: dict(name=r[1], tc=(re.search(r"Tc\s*([A-E])", r[5]).group(1) if len(r) > 5 and re.search(r"Tc\s*([A-E])", r[5]) else "")) for r in rows}
    lines = kmz_lines(R.resolve(C["sections_kmz"])); M = C.get("match", {}); buf = M.get("buffer_m", 75); fr = M.get("min_along_frac", 0.7)
    cls = arcs.road_class.isin(M.get("classes", ["motorway", "trunk", "primary", "secondary"])).values
    tree = shapely.STRtree(G); sec = [""] * len(arcs); W, S, E, N = R["network"]["osm_graph"]["bbox"]; nsec = 0
    for sid, parts in lines.items():
        if sid not in bn: continue
        for pl in parts:
            xy = np.array(pl)
            if not ((xy[:, 0] >= W) & (xy[:, 0] <= E) & (xy[:, 1] >= S) & (xy[:, 1] <= N)).any(): continue
            ln = shapely.LineString(np.c_[T.transform(xy[:, 0], xy[:, 1])]); nsec += 1
            for k in tree.query(ln, predicate="dwithin", distance=buf):
                if not cls[k] or sec[k]: continue
                g = G[k]
                if shapely.length(shapely.intersection(g, ln.buffer(buf))) < 0.9 * L[k]: continue
                c = shapely.get_coordinates(g); a0, a1 = ln.project(shapely.Point(c[0])), ln.project(shapely.Point(c[-1]))
                if abs(a1 - a0) >= fr * L[k]: sec[k] = sid
# tunnels from OSM ways
    hw = pickle.load(open(R.path("paths", "osm_dir") / "osm_highways.pkl", "rb")); tcat = [""] * len(arcs); tname = [""] * len(arcs)
    for t in C.get("tunnels", []):
        tw, hwc, Wt, St, Et, Nt = [], set(), *t["bbox"]
        for w in hw.values():
            g = w["tags"]
            if g.get("tunnel") != "yes" or g["highway"] in ("footway", "cycleway", "path", "steps", "pedestrian", "service"): continue
            if ("ref" in t and g.get("ref") != t["ref"]) or ("osm_name" in t and g.get("name") != t["osm_name"]): continue
            ll = np.array(w["lonlat"])
            if not ((ll[:, 0] >= Wt) & (ll[:, 0] <= Et) & (ll[:, 1] >= St) & (ll[:, 1] <= Nt)).all(): continue
            tw.append(shapely.LineString(np.c_[T.transform(ll[:, 0], ll[:, 1])])); hwc.add(g["highway"])
        if not tw: print(f"WARNING tunnel {t['name']}: no OSM tunnel way found"); continue
        U = shapely.union_all([x.buffer(10) for x in tw]); hit = 0
        for k in tree.query(U, predicate="intersects"):
            if arcs.road_class.values[k] in hwc and shapely.length(shapely.intersection(G[k], U)) >= t.get("min_overlap_m", 50):# same OSM class as the tunnel ways
                tcat[k] = max(tcat[k], t["cat"]); tname[k] = (tname[k] + ";" if tname[k] else "") + t["name"]; hit += 1
        print(f"tunnel {t['name']} (cat {t['cat']}): {len(tw)} OSM ways, {sum(x.length for x in tw)/1000:.2f} km, {hit} arcs")
    out = pd.DataFrame(dict(u=arcs.u, v=arcs.v, hazmat_status=np.where(np.array(sec) != "", "allowed_corridor", "unknown"), restrict_time="",
                            restrict_src=[(f"Basisnet weg {s} ({bn[s]['name']})" if s else "") + ("; " if s and n else "") + (f"ADR tunnel category {c} ({n}; VLG art. 3)" if n else "") for s, c, n in zip(sec, tcat, tname)],
                            tunnel_cat=tcat, basisnet_section=sec))
    p = R.path("network", "hazmat_status_csv"); out.to_csv(p, index=False)
    m = out.hazmat_status == "allowed_corridor"
    print(f"hazmat_status: {nsec} Basisnet section lines in bbox; arcs on Basisnet {m.sum()} ({L[m.values].sum()/1000:.1f} km), sections matched {out.basisnet_section[m].nunique()}: "
          f"{sorted(out.basisnet_section[m].unique())}; tunnel arcs {dict(pd.Series(tcat)[pd.Series(tcat) != ''].value_counts())} -> {p}")
    return out

if __name__ == "__main__":
    run(load(sys.argv[1], sys.argv[2:]))
