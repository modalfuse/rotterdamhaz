"""Port generators from a list of liquid-bulk / tank-storage terminals (replaces area-based OSM port land).
  python -m hazbench.prep.port_terminals regions/<region>.yaml
Region YAML block facilities.port_terminals:
  list_src: text naming the public list(s) the terminals were taken from (e.g. [operator] branch lists, accessed 2026-10-19)
  rev_gml: Register Externe Veiligheid production facilities (INSPIRE PF GML, EPSG:4258; official name + site polygon)
  bbox: [W, S, E, N]   only polygons whose centroid lies inside
  terminals: [{name, rev: regex on REV act-core:name | osm: regex on OSM polygon name}]   REV is tried first, then OSM (largest polygon;
             all polygons with the same name are added up). Entries without a location are reported and skipped.
  merge_points: CSV of other register points (E-PRTR); a terminal's optional drop_register regex removes its own register point (counted once)
  out: merged CSV for facilities.points (terminals first, type=port, with area_ha from the polygon)
  (decision Q. Liu 2026-10-19 19:35): per terminal optional capacity_m3 + capacity_src (public tank storage capacity, m3);
  capacity_group: <list name of another entry> pools this entry's points with that entry (same site listed twice; the group capacity is
  split over all its points by area); exclude: <reason> drops a listed terminal (reported, e.g. crude only / no truck access / not built)
Output columns: lon, lat, type, source_id, name, area_ha, area_src, list_name. Names stay in this input file only (the builder writes
pseudonymous ids)."""
import re, sys, json
import xml.etree.ElementTree as ET
import numpy as np, pandas as pd, shapely
from shapely.geometry import Polygon, Point
from pyproj import Transformer
from ..config import load

NS = {"gml": "http://www.opengis.net/gml/3.2", "act-core": "http://inspire.ec.europa.eu/schemas/act-core/4.0", "pf": "http://inspire.ec.europa.eu/schemas/pf/4.0"}

def rev_facilities(path, bbox):
    W, S, E, N = bbox; out = []
    for f in ET.parse(path).iterfind(".//pf:ProductionFacility", NS):
        pl = f.findall(".//act-core:geometry//gml:posList", NS)
        if not pl: continue
        polys = []
        for x in pl:
            c = list(map(float, x.text.split())); polys.append(Polygon(list(zip(c[::2], c[1::2]))).buffer(0))
        g = shapely.union_all(polys); ce = g.centroid
        if W <= ce.x <= E and S <= ce.y <= N:
            out.append(dict(id=f.findtext("gml:identifier", namespaces=NS), name=f.findtext("act-core:name", namespaces=NS) or "", geom=g))
    return out

def run(R):
    C = R["facilities"]["port_terminals"]; T = Transformer.from_crs(R["crs"]["geographic"], R["crs"]["projected"], always_xy=True)
    area_ha = lambda g: shapely.transform(g, lambda c: np.c_[T.transform(c[:, 0], c[:, 1])]).area / 1e4
    rev = rev_facilities(R.resolve(C["rev_gml"]), C["bbox"])
    pois = json.load(open(R.path("paths", "osm_dir") / "osm_pois.json"))
    osm = [dict(id=f"osm:{p['osm']}", name=p["name"] or "", geom=Polygon(p["poly"]).buffer(0)) for p in pois
           if p.get("poly") and p["landuse"] in ("industrial", "port") and p["name"]]
    W, S, E, N = C["bbox"]; osm = [q for q in osm if W <= q["geom"].centroid.x <= E and S <= q["geom"].centroid.y <= N]
    rows, polys, missing, excluded = [], [], [], []
    for t in C["terminals"]:
        if t.get("exclude"): excluded.append(f"{t['name']} ({t['exclude']})"); continue
        hit, src = [], None
        if t.get("rev"): hit = [q for q in rev if re.search(t["rev"], q["name"])]; src = "REV site polygon (official)"
        if not hit and t.get("osm"): hit = [q for q in osm if re.search(t["osm"], q["name"])]; src = "OSM industrial polygon with the terminal name (ODbL)"
        if not hit: missing.append(t["name"]); continue
        for q in (hit if t.get("each") else [max(hit, key=lambda q: q["geom"].area)]):
            a = sum(area_ha(h["geom"]) for h in hit) if not t.get("each") else area_ha(q["geom"])
            pt = q["geom"].representative_point(); polys.append(q["geom"])
            rows.append(dict(lon=round(pt.x, 6), lat=round(pt.y, 6), type="port", source_id=";".join(h["id"] for h in (hit if not t.get("each") else [q])),
                             name=q["name"], area_ha=round(a, 2), area_src=src, list_name=t["name"]))
            if "capacity_m3" in t or t.get("capacity_group"): rows[-1]["cap_group"] = t.get("capacity_group") or t["name"]
    term = pd.DataFrame(rows)
    if excluded: print("listed terminals excluded:", excluded)
    caps = {t["name"]: t for t in C["terminals"] if "capacity_m3" in t}
    if caps:
        if "cap_group" not in term or term.cap_group.isna().any():
            raise SystemExit(f"port_terminals: no capacity_m3 for {term.loc[term.get('cap_group', pd.Series(index=term.index)).isna(), 'list_name'].tolist()}")
        bad = set(term.cap_group) - set(caps)
        if bad: raise SystemExit(f"port_terminals: capacity_group without capacity_m3: {bad}")
        share = term.area_ha / term.groupby("cap_group").area_ha.transform("sum")
        term["capacity_m3"] = (term.cap_group.map(lambda k: float(caps[k]["capacity_m3"])) * share).round(0)
        term["capacity_src"] = [caps[k]["capacity_src"] + ("" if s == 1 else f" (group {k}, split by site area {s:.3f})") for k, s in zip(term.cap_group, share)]
        print(f"port_terminals: capacity {term.capacity_m3.sum():,.0f} m3 over {len(term)} points")
        term = term.drop(columns="cap_group")
    print(f"port_terminals: {len(term)} generator points from {len(C['terminals'])} listed terminals; total area {term.area_ha.sum():.1f} ha; "
          f"no location for {len(missing)}: {missing}")
    out = term
    if C.get("merge_points"):
        mp = pd.read_csv(R.resolve(C["merge_points"])); drop = [t["drop_register"] for t in C["terminals"] if t.get("drop_register")]
        inside = np.array([any(re.search(rx, n) for rx in drop) for n in mp.name.fillna("")]) if drop else np.zeros(len(mp), bool)
        if inside.any(): print("register points dropped (listed terminals):", mp.loc[inside, "name"].tolist())
        mp = mp[~inside].copy(); mp["area_src"] = ""; mp["list_name"] = ""
# refinery capacities ( decision Q. Liu 2026-10-19 17:58): [{name: regex, kbd, src}] sets type=refinery and capacity_kbd;
# register points typed refinery that match no entry are retyped to `refinery_unlisted_type` (default chemical)
        rc = C.get("refinery_capacity") or []
        if rc:
            mp["capacity_kbd"] = np.nan; mp["capacity_src"] = ""
            for e in rc:
                m = mp.name.fillna("").str.contains(e["name"], regex=True)
                if m.sum() != 1: raise SystemExit(f"refinery_capacity {e['name']!r} matches {int(m.sum())} register points")
                mp.loc[m, "type"] = "refinery"; mp.loc[m, "capacity_kbd"] = float(e["kbd"]); mp.loc[m, "capacity_src"] = e["src"]
            un = (mp.type == "refinery") & mp.capacity_kbd.isna()
            if un.any(): print("refinery points without a listed capacity, retyped:", mp.loc[un, "name"].tolist()); mp.loc[un, "type"] = C.get("refinery_unlisted_type", "chemical")
        out = pd.concat([term, mp[[c for c in mp.columns if c in ("lon", "lat", "type", "source_id", "name", "area_src", "list_name", "capacity_kbd", "capacity_src", "capacity_m3")]]], ignore_index=True)
    p = R.resolve(C["out"]); p.parent.mkdir(parents=True, exist_ok=True); out.to_csv(p, index=False)
    print(f"-> {p}: {len(out)} points {out.type.value_counts().to_dict()}")

if __name__ == "__main__":
    run(load(sys.argv[1], sys.argv[2:]))
