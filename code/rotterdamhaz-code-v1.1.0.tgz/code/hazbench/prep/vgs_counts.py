"""Rijkswaterstaat 'Vervoer gevaarlijke stoffen' road counts (xlsx, one row per Basisnet road section 'wegvak') + the section label
points of 'Wegvaknummers Nederland.kmz' -> observed-flow CSV for od.calibration (site_id, lon, lat, category columns, ...).
  python -m hazbench.prep.vgs_counts regions/<region>.yaml
Region YAML od.calibration.vgs: {xlsx, sheet, kmz, header_row, first_col}. Categories (LF1, LF2, LT1.., GF.., GT..) are annual counts
of loaded tank trucks per Basisnet substance category; the class mapping is set in od.calibration.class_columns."""
import re, sys, zipfile
import numpy as np, pandas as pd
from ..config import load

def kmz_points(path):
    path = str(path)
    if "!" in path:# outer.zip!inner.kmz
        outer, inner = path.split("!", 1); import io; z = zipfile.ZipFile(io.BytesIO(zipfile.ZipFile(outer).read(inner)))
    else: z = zipfile.ZipFile(path)
    kml = z.read([n for n in z.namelist() if n.endswith(".kml")][0]).decode("utf-8", "replace")
    pts = {}
    for pm in re.findall(r"<Placemark>.*?</Placemark>", kml, re.S):
        nm = re.search(r"<name>(.*?)</name>", pm, re.S); co = re.search(r"<Point>\s*<coordinates>\s*([-0-9.]+),([-0-9.]+)", pm, re.S)
        if nm and co: pts.setdefault(nm.group(1).strip(), (float(co.group(1)), float(co.group(2))))
    return pts

def run(R):
    cal = R["od"]["calibration"]; c = cal["vgs"]
    raw = pd.read_excel(R.resolve(c["xlsx"]), sheet_name=c.get("sheet", 0), header=None)
    hr, fc = c.get("header_row", 2), c.get("first_col", 15)
    hdr = [str(h).strip().replace("\n", " ") for h in raw.iloc[hr, fc:]]
    df = raw.iloc[hr + 1:, fc:].copy(); df.columns = hdr
    df = df.rename(columns={hdr[0]: "site_id", hdr[1]: "road", hdr[2]: "description"})
    df = df[df.site_id.notna() & df.site_id.astype(str).str.match(r"^[A-Za-z]+\d+")]
    pts = kmz_points(R.resolve(c["kmz"]))
    df["lon"] = [pts.get(str(s).strip(), (np.nan, np.nan))[0] for s in df.site_id]; df["lat"] = [pts.get(str(s).strip(), (np.nan, np.nan))[1] for s in df.site_id]
    W, S, E, N = R["network"]["osm_graph"]["bbox"]
    df = df[df.lon.between(W, E) & df.lat.between(S, N)]
    cats = [h for h in df.columns if re.match(r"^(LF|LT|GF|GT)\d$", str(h))]
    for k in cats: df[k] = pd.to_numeric(df[k], errors="coerce")
    p = R.resolve(cal["observed"]); p.parent.mkdir(parents=True, exist_ok=True)
    keep = ["site_id", "road", "description", "lon", "lat"] + cats + [h for h in df.columns if h.startswith("telperiode") or h.startswith("totaal")]
    df[keep].to_csv(p, index=False); print(f"vgs_counts: {len(df)} sections inside the network bbox, categories {cats} -> {p}")

if __name__ == "__main__":
    run(load(sys.argv[1], sys.argv[2:]))
