"""CBS Vierkantstatistieken 100 m (GeoPackage, EPSG:28992) -> population GeoTIFF on the 100 m CBS grid, clipped to a bbox.
  python -m hazbench.prep.cbs_grid regions/<region>.yaml
Region YAML: population.cbs {gpkg, layer, field (aantal_inwoners), suppressed_fill, bbox_buffer_m}; writes population.raster.
CBS codes negative values (e.g. -99997 'geheim', 1-4 inhabitants) -> `suppressed_fill` (assumed)."""
import sys
import numpy as np, pyogrio, rasterio
from rasterio.transform import from_origin
from pyproj import Transformer
from ..config import load

def run(R):
    c = R["population"]["cbs"]; W, S, E, N = R["network"]["osm_graph"]["bbox"]; buf = c.get("bbox_buffer_m", 5000)
    T = Transformer.from_crs(4326, 28992, always_xy=True); xs, ys = T.transform([W, E, E, W], [S, S, N, N])
    x0, x1 = np.floor((min(xs) - buf) / 100) * 100, np.ceil((max(xs) + buf) / 100) * 100
    y0, y1 = np.floor((min(ys) - buf) / 100) * 100, np.ceil((max(ys) + buf) / 100) * 100
    df = pyogrio.read_dataframe(R.resolve(c["gpkg"]), layer=c.get("layer"), columns=[c.get("field", "aantal_inwoners")], bbox=(x0, y0, x1, y1))
    v = df[c.get("field", "aantal_inwoners")].astype(float).to_numpy(copy=True)
    neg = v < 0; v[neg] = c.get("suppressed_fill", 0)
    cen = df.geometry.centroid; col = ((cen.x.values - x0) // 100).astype(int); row = ((y1 - cen.y.values) // 100).astype(int)
    H, Wd = int((y1 - y0) / 100), int((x1 - x0) / 100); A = np.zeros((H, Wd), "float32")
    ok = (row >= 0) & (row < H) & (col >= 0) & (col < Wd); np.add.at(A, (row[ok], col[ok]), v[ok])
    out = R.path("population", "raster"); out.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(out, "w", driver="GTiff", height=H, width=Wd, count=1, dtype="float32", crs="EPSG:28992", transform=from_origin(x0, y1, 100, 100), nodata=0, compress="deflate") as d:
        d.write(A, 1)
    print(f"cbs_grid: {ok.sum()} cells, {neg.sum()} suppressed -> {c.get('suppressed_fill', 0)}, population {A.sum():.0f}, grid {H}x{Wd} -> {out}")

if __name__ == "__main__":
    run(load(sys.argv[1], sys.argv[2:]))
