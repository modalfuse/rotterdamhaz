"""Reference implementation of the v1 evaluation protocol (EVALUATION_PROTOCOL.md).

Usage: from metrics import Bench; b = Bench(dataset_dir)
  Bench.path_metrics(path, substance) -> T, L, TR_sum, PE_sum, PE_union, R_union, DCR_PE, DCR_TR
  Bench.shortest(o, d, w)              -> shortest path by time ("t"), length ("L"), TR_sum ("TR") or PE_sum ("PE")
  Bench.candidates / unavoidable / split -> candidate set, unavoidable cell set U, avoidable/unavoidable exposure split
  ARR(R_ref, R_p, R_min), AS(R_ref, R_min) -> avoidable risk reduction ratio and avoidable share
"""
import json, math
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
from scipy import sparse

class Bench:
    """Loads a dataset directory; pop = "day" | "night"; lam = lambda column (e.g. lambda_arc, lambda_arc_MengHou)."""
    def __init__(s, d, pop="day", lam="lambda_arc"):
        d = Path(d); s.d = d; s.P = json.load(open(d / "params.json")) if (d / "params.json").exists() else __import__("yaml").safe_load(open(d / "params.yaml"))
        s.arcs = pd.read_csv(d / "arcs.csv"); c = np.load(d / "cells.npz"); s.Pc = c[f"pop_{pop}"].astype(float)
        s.idx = {(u, v): k for k, (u, v) in enumerate(zip(s.arcs.u, s.arcs.v))}
        s.M = {}; s.G = nx.DiGraph()
        for k, r in enumerate(s.arcs.itertuples()): s.G.add_edge(r.u, r.v, k=k, t=r.time_min + getattr(r, "toll_min", 0.0), t0=r.time_min, L=r.length_km)# t0: pure travel time (B1prime, ); toll_min: optional generalized time (RotterdamHaz )
# per-trip release-event probability per arc, rescaled if an alternative lambda column is selected
        s.p_rel = s.arcs.p_release_trip.values * (s.arcs[lam].values / s.arcs.lambda_arc.values)
# optional (RotterdamHaz): per-substance forbidden arcs = ADR tunnel categories in params `tunnel_forbidden` + hazmat_status prohibited
        s.tf = s.P.get("tunnel_forbidden") if "tunnel_cat" in s.arcs else None; s._fb = {}
    def forbidden(s, sub):
        if sub not in s._fb:
            cats = list(s.tf.get(sub, s.tf.get("default", [])))
            s._fb[sub] = (s.arcs.hazmat_status.values == "prohibited") | s.arcs.tunnel_cat.fillna("").isin(cats).values
        return s._fb[sub]
    def cells(s, sub):
# sparse boolean matrix (arcs x cells): cell centre within the impact radius of substance `sub`
        if sub not in s.M: s.M[sub] = sparse.load_npz(s.d / f"arc_cells_{sub}.npz").tocsr().astype(bool)
        return s.M[sub]
# probability that a release becomes a high-consequence event (params Pi, by substance type)
# optional params Pi_substance {substance: value} overrides the substance-type value (RotterdamHaz: pressure vs atmospheric tank, ignition)
    def Pi(s, sub):
        ps = s.P.get("Pi_substance") or {}
        return ps[sub] if sub in ps else s.P["Pi"][s.P["substance_type"][sub]]["base"]
    def arc_ids(s, path): return [s.idx[(a, b)] for a, b in zip(path[:-1], path[1:])]
    def path_metrics(s, path, sub, ref=None):
        ks = s.arc_ids(path); M = s.cells(sub); p = s.p_rel[ks] * s.Pi(sub)
        pop = s.arcs[f"pop_{sub}"].values[ks]
        sub_M = M[ks]; cov = np.unique(sub_M.indices)
# R_union: each cell counted once with prob of >=1 event among arcs covering it
        logq = np.zeros(M.shape[1]); 
        for j, k in enumerate(ks):
            cc = M.indices[M.indptr[k]:M.indptr[k + 1]]; logq[cc] += math.log1p(-p[j])
        R_union = float((s.Pc[cov] * -np.expm1(logq[cov])).sum())
        out = dict(T=float(s.arcs.time_min.values[ks].sum()), L=float(s.arcs.length_km.values[ks].sum()), TR_sum=float((p * pop).sum()),
                   PE_sum=float(pop.sum()), PE_union=float(s.Pc[cov].sum()), R_union=R_union, n_arcs=len(ks), cover=cov)
        out["DCR_PE"] = out["PE_sum"] / out["PE_union"] if out["PE_union"] > 0 else float("nan")
        out["DCR_TR"] = out["TR_sum"] / R_union if R_union > 0 else float("nan")
        return out
    def shortest(s, o, d, w="t", sub=None):
        if s.tf and sub is not None:# restricted routing: forbidden arcs are hidden (weight None)
            fb = s.forbidden(sub)
            if w in ("t", "t0", "L"): return nx.shortest_path(s.G, o, d, weight=lambda u, v, e: None if fb[e["k"]] else e[w])
            col = {"TR": lambda r: s.p_rel * s.Pi(sub) * s.arcs[f"pop_{sub}"].values, "PE": lambda r: s.arcs[f"pop_{sub}"].values}[w](None)
            return nx.shortest_path(s.G, o, d, weight=lambda u, v, e: None if fb[e["k"]] else col[e["k"]] + 1e-12)
        if w in ("t", "t0", "L"): return nx.shortest_path(s.G, o, d, weight=w)
        col = {"TR": lambda r: s.p_rel * s.Pi(sub) * s.arcs[f"pop_{sub}"].values, "PE": lambda r: s.arcs[f"pop_{sub}"].values}[w](None)
        return nx.shortest_path(s.G, o, d, weight=lambda u, v, e: col[e["k"]] + 1e-12)
    def candidates(s, o, d, k=20, sub="chlorine"):
        P = []
        for p in nx.shortest_simple_paths(s.G, o, d, weight="t"):
            P.append(p)
            if len(P) >= k: break
        for w in ("TR", "PE", "L"): P.append(s.shortest(o, d, w, sub))
        return P
    def unavoidable(s, cands, sub):
# approximate unavoidable set: intersection of the cover sets of all candidate paths
        sets = [set(s.path_metrics(p, sub)["cover"].tolist()) for p in cands]
        U = set.intersection(*sets) if sets else set(); return np.array(sorted(U), dtype=int)
    def split(s, path, U, sub):
        m = s.path_metrics(path, sub); PE_un = float(s.Pc[U].sum()) if len(U) else 0.0
        return dict(PE_un=PE_un, PE_av=m["PE_union"] - PE_un)
def ARR(R_ref, R_p, R_min):
# avoidable risk reduction ratio; NaN (reported as N/A) when the denominator is ~0
    den = R_ref - R_min
    return float("nan") if den < 1e-12 * max(abs(R_ref), 1) else (R_ref - R_p) / den
def AS(R_ref, R_min): return (R_ref - R_min) / R_ref if R_ref > 0 else float("nan")
