"""Main builder.

  python -m hazbench.build regions/<region>.yaml <out_dir> [key.sub=value ...]

Inputs (all named in the region YAML): network snapshot (nodes/arcs/geojson; a network snapshot or the
output of hazbench.osm_graph), OSM extract (hazbench.osm_extract), population raster, impact radii, optional facility points,
gateways, optional observed link flows. Model parameters: regions/<region>.params.yaml.
Deterministic (fixed seeds). Facilities are written under pseudonymous ids (G01.., A01..); no facility names, OSM element ids or
facility coordinates are written. If the region defines `postprocess` (optional English rendering), the raw build goes to
<out_dir>_internal and the plugin writes the release files into <out_dir>."""
import json, pickle, math, sys, shutil, re, importlib
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx, rasterio, yaml
from rasterio import features
from pyproj import Transformer
from shapely.geometry import LineString, Polygon, Point
import shapely, shapely.ops
from scipy.spatial import cKDTree
from scipy import sparse
from .config import load
from . import calibrate

class Build:
    def __init__(s, R, out):
        s.R, s.P, s.OUT = R, R["P"], Path(out); s.OUT.mkdir(parents=True, exist_ok=True)
        s.T = Transformer.from_crs(R["crs"]["geographic"], R["crs"]["projected"], always_xy=True)
        s.XC, s.YC = R["crs"]["xy_cols"]
        s.rng = np.random.default_rng(s.P["seed"]); s.log = []
    def note(s, m): print(m); s.log.append(m)

# ---------------- 1. network ----------------
    def network(s):
        R, P, T, XC, YC = s.R, s.P, s.T, s.XC, s.YC
        nodes = pd.read_csv(R.path("network", "nodes"))[["node", "lon", "lat"]]
        nodes[XC], nodes[YC] = T.transform(nodes.lon.values, nodes.lat.values)
        nodes["node_type"] = "junction"
        arcs0 = pd.read_csv(R.path("network", "arcs"), keep_default_na=True)
        gj = json.load(open(R.path("network", "geojson")))
        assert len(gj["features"]) == len(arcs0)
        geoms = [f["geometry"]["coordinates"] for f in gj["features"]]
        for f, (u, v) in zip(gj["features"], zip(arcs0.u, arcs0.v)): assert f["properties"]["u"] == u and f["properties"]["v"] == v
        loops = arcs0.index[arcs0.u == arcs0.v].tolist()
        s.note(f"arcs.csv rows {len(arcs0)}; self-loops {len(loops)} (removed: {arcs0.loc[loops[:5], ['u','v','name','length_km']].to_dict('records')}{' ...' if len(loops) > 5 else ''}); duplicates {int(arcs0.duplicated(['u','v']).sum())}")
        keep = [i for i in range(len(arcs0)) if i not in loops]
        arcs0 = arcs0.loc[keep].reset_index(drop=True); geoms = [geoms[i] for i in keep]
        W = pickle.load(open(R.path("paths", "osm_dir") / "osm_ways.pkl", "rb")); ways, seg, coord = W["ways"], W["seg"], W["coord"]
        c2n = {v: k for k, v in coord.items()}
        DEF_LANES = P["default_lanes"]; AC = P["A1_curve"]
        rows = []
        for i, (a, g) in enumerate(zip(arcs0.itertuples(), geoms)):
            lon, lat = np.array([p[0] for p in g]), np.array([p[1] for p in g])
            x, y = T.transform(lon, lat); xy = np.c_[x, y]
            seglen = np.hypot(np.diff(x), np.diff(y)); L = seglen.sum()
            ids = [c2n.get((round(p[0], 7), round(p[1], 7))) for p in g]
            wid = [seg.get((ids[k], ids[k + 1])) if ids[k] and ids[k + 1] else None for k in range(len(g) - 1)]
# A1 per segment: tunnel / bridge / curves by vertex circumradius (factor values in params A1_factors, default T/CAWS Table C.1)
            fa = P.get("A1_factors", {"curve_lt200": 2.2, "curve_200_max": 1.3, "tunnel": 0.8, "bridge": 1.2})
            a1 = np.ones(len(seglen))
            for k in range(1, len(g) - 1):
                p0, p1, p2 = xy[k - 1], xy[k], xy[k + 1]
                v1, v2 = p1 - p0, p2 - p1; n1, n2 = np.linalg.norm(v1), np.linalg.norm(v2)
                if n1 < 1 or n2 < 1: continue
                defl = math.degrees(math.acos(np.clip(v1 @ v2 / n1 / n2, -1, 1)))
                if defl < AC["min_deflection_deg"]: continue
                chord = np.linalg.norm(p2 - p0); Rr = chord / (2 * math.sin(math.radians(defl)))
                if Rr < AC["curve_max_radius_m"]:
                    f = fa["curve_lt200"] if Rr < 200 else fa["curve_200_max"]
                    a1[k - 1] = max(a1[k - 1], f); a1[k] = max(a1[k], f)
            br = np.zeros(len(seglen)); tu = np.zeros(len(seglen))
            for k, w in enumerate(wid):
                if w is None: continue
                t = ways[w]
                if t["tunnel"] and t["tunnel"] != "no": a1[k] = fa["tunnel"]; tu[k] = 1
                elif t["bridge"] and t["bridge"] != "no": a1[k] = fa["bridge"]; br[k] = 1
            wl = {}
            for k, w in enumerate(wid):
                if w is not None: wl[w] = wl.get(w, 0) + seglen[k]
            main = max(wl, key=wl.get) if wl else None; t = ways.get(main, {})
            names = sorted({ways[w]["name"] for w in wl if ways[w]["name"]})
            lanes = t.get("lanes", ""); ms = t.get("maxspeed", "")
            rows.append(dict(osm_way_id=main or "", osm_way_ids=";".join(map(str, wl)), osm_match_frac=round(sum(wl.values()) / L, 4) if L else 0,
                             osm_names=";".join(names), lanes=int(float(lanes.split(";")[0])) if re.match(r"^\d", lanes or "") else DEF_LANES.get(a.road_class.replace("_link", ""), 1),
                             lanes_src="osm" if re.match(r"^\d", lanes or "") else "default", maxspeed_osm=ms, oneway=t.get("oneway", ""),
                             bridge_frac=round(float((br * seglen).sum() / L), 4) if L else 0, tunnel_frac=round(float((tu * seglen).sum() / L), 4) if L else 0,
                             A1=round(float((a1 * seglen).sum() / L), 4) if L else 1.0, length_km_utm=L / 1000, geom_utm=LineString(xy)))
        Rr = pd.DataFrame(rows)
        arcs = pd.concat([arcs0[["u", "v", "name", "road_class", "speed_kmh_assumed", "urban", "pop_density_1km"]].rename(columns={"speed_kmh_assumed": "speed_kmh"}), Rr], axis=1)
        arcs["speed_src"] = R["network"].get("speed_src_label", "default(v0 logic)")
        arcs["length_km_v0"] = arcs0.length_km.values
        arcs["length_km"] = arcs.length_km_utm.round(6)
        arcs["time_min"] = 60 * arcs.length_km / arcs.speed_kmh
        cls = arcs.road_class.str.replace("_link", "", regex=False)
        arcs["acc_class"] = cls.map(P["acc_class_map"]).fillna("urban")
        bu = P.get("builtup_rule"); ws = R.path("network", "wkd_speed_csv")
        if bu and ws and ws.exists():# RotterdamHaz: legal speed limit (WKD) decides inside / outside built-up area for the classes in bu.apply_classes
            w = pd.read_csv(ws).set_index(["u", "v"]); key = list(zip(arcs.u, arcs.v))
            arcs["wkd_maxspeed"] = [w.wkd_maxspeed.get(k, np.nan) for k in key]; frac = np.array([w.wkd_match_frac.get(k, 0.0) for k in key])
            ok = (frac >= bu.get("min_match_frac", 0.5)) & cls.isin(bu["apply_classes"]).values & arcs.wkd_maxspeed.notna().values
            before = arcs.acc_class.copy(); arcs["acc_class_src"] = np.where(ok, "WKD speed limit", "OSM class")
            arcs.loc[ok & (arcs.wkd_maxspeed <= bu["urban_max_kmh"]), "acc_class"] = bu.get("urban_class", "urban")
            arcs.loc[ok & (arcs.wkd_maxspeed > bu["urban_max_kmh"]), "acc_class"] = bu.get("rural_class", "provincial")
            L = arcs.length_km_utm / 1000 if "length_km" not in arcs else arcs.length_km
            s.note(f"built-up rule (WKD <= {bu['urban_max_kmh']} km/h): {int(ok.sum())} arcs decided by WKD, {int((~ok & cls.isin(bu['apply_classes']).values).sum())} by OSM class; "
                   f"changed {int((before != arcs.acc_class).sum())} arcs ({L[before != arcs.acc_class].sum():.0f} km): "
                   f"{pd.crosstab(before, arcs.acc_class).to_dict()}; km by acc_class {arcs.groupby('acc_class').length_km.sum().round(0).to_dict()}")
        s.note(f"OSM way match: mean length fraction {arcs.osm_match_frac.mean():.3f}; arcs fully unmatched {(arcs.osm_match_frac==0).sum()}")
        arcs["A2"] = 1.0; arcs["A3"] = P["A3"]["base"]; arcs["A4"] = cls.map(P["A4_by_class"]).fillna(P["A4_by_class"]["other"]); arcs["A5"] = arcs["A6"] = arcs["A7"] = 1.0
        arcs["A_s"] = arcs[["A1", "A2", "A3", "A4", "A5", "A6", "A7"]].prod(axis=1)
# hazmat status: designated corridors matched by OSM name (params `corridors`); optional per-arc status table (region network.hazmat_status_csv)
        corr = P.get("corridors") or []; nm = arcs.osm_names.fillna("") + ";" + arcs.name.fillna("")
        arcs["hazmat_status"] = np.where(nm.str.contains("|".join(corr)), "allowed_corridor", "unknown") if corr else "unknown"
        arcs["corridor"] = [next((c for c in corr if c in s_), "") for s_ in nm]
        arcs["restrict_time"] = ""; arcs["restrict_src"] = np.where(arcs.hazmat_status == "allowed_corridor", R.get("corridor_restrict_src", "designated hazmat corridor; matched by OSM road name"), "")
        hs = R.path("network", "hazmat_status_csv")
        if hs and hs.exists():# columns u, v, hazmat_status (allowed_corridor | prohibited | tunnel_cat_X...), restrict_time, restrict_src
            st = pd.read_csv(hs, dtype={"restrict_time": str, "restrict_src": str}).set_index(["u", "v"])
            for c in ("hazmat_status", "restrict_time", "restrict_src"):
                if c in st: arcs[c] = [st[c].get((u, v), x) for u, v, x in zip(arcs.u, arcs.v, arcs[c])]
            if "tunnel_cat" in st:# optional ADR tunnel category (A-E) per arc; used with params `tunnel_forbidden`
                arcs["tunnel_cat"] = [st["tunnel_cat"].get((u, v), "") if isinstance(st["tunnel_cat"].get((u, v), ""), str) else "" for u, v in zip(arcs.u, arcs.v)]
                s.note(f"hazmat status table: {arcs.hazmat_status.value_counts().to_dict()}; tunnel arcs by category {arcs.tunnel_cat[arcs.tunnel_cat != ''].value_counts().to_dict()}")
# optional (RotterdamHaz ): per-trip road tolls as generalized time, toll_min = toll (EUR) / value of time (EUR/h) * 60, on the
# arcs whose restrict_src contains `match` and whose road_class is in `road_class` (one arc per direction, so a trip pays once).
# Routing (gravity costs, AON, calibration paths, baseline B1) uses time_min + toll_min; time_min itself is unchanged.
        tl = s.P.get("tolls")
        if tl:
            arcs["toll_min"] = 0.0
            for t_ in tl:
                m = arcs.restrict_src.fillna("").str.contains(t_["match"], regex=False) & arcs.road_class.isin(t_["road_class"])
                arcs.loc[m, "toll_min"] = round(60.0 * t_["toll_eur"] / s.P["vot_truck_eur_h"], 4)
                s.note(f"toll {t_['name']}: {t_['toll_eur']} EUR / {s.P['vot_truck_eur_h']} EUR/h = {60.0 * t_['toll_eur'] / s.P['vot_truck_eur_h']:.2f} min on {int(m.sum())} arcs")
        cen = dict(zip(corr, P.get("corridors_en") or corr))# log in English where params give corridors_en
        for c in corr: s.note(f"corridor {cen[c]}: {arcs.loc[arcs.corridor==c,'length_km'].sum():.2f} km in network")
        lb = P["lambda_base"]["base"]; schemes = list(P["road_mult"])
        for sch in schemes:
            m = arcs.acc_class.map(P["road_mult"][sch]); mbar = (arcs.length_km * m).sum() / arcs.length_km.sum()
            arcs[f"m_class_{sch}"] = m; arcs[f"lambda_arc_{sch}"] = lb * m / mbar
        s0 = schemes[0]
        arcs["m_class"] = arcs[f"m_class_{s0}"]; arcs["lambda_base"] = lb; arcs["lambda_arc"] = arcs[f"lambda_arc_{s0}"]
        a = P["a_nontraffic"]
        arcs["p_release_trip"] = (1 + a) * arcs.lambda_arc * arcs.A_s * arcs.length_km
        arcs["accident_prob_harwood"] = arcs0.accident_prob.values if "accident_prob" in arcs0 else np.nan
        s.nodes, s.arcs, s.arcs0, s.geoms = nodes, arcs, arcs0, geoms

# ---------------- 2. population ----------------
    def population(s):
        R, P, T, XC, YC, OUT, arcs = s.R, s.P, s.T, s.XC, s.YC, s.OUT, s.arcs
        wp = rasterio.open(R.path("population", "raster")); WP = wp.read(1).astype("float64"); WP[~np.isfinite(WP)] = 0; WP[WP < 0] = 0
        H_, W_ = WP.shape; tr = wp.transform
        geographic = wp.crs.is_geographic
        if geographic:
            lat_c = tr.f + tr.e * (np.arange(H_) + 0.5)
            cell_ha = (abs(tr.a) * 111320 * np.cos(np.radians(lat_c)) * abs(tr.e) * 110574) / 1e4# per-row cell area (ha)
        else:
            cell_ha = np.full(H_, abs(tr.a * tr.e) / 1e4)
        pois = json.load(open(R.path("paths", "osm_dir") / "osm_pois.json"))
        tanks = [Point(p["lon"], p["lat"]) for p in pois if p["man_made"] == "storage_tank"]
        tank_tree = shapely.STRtree(tanks)
        CHEM = re.compile(P["chem_name_regex"]); LOGI = re.compile(P["logistics_name_regex"])
        polys = []
        for p in pois:
            if not p.get("poly") or p["landuse"] not in ("industrial", "port"): continue
            try: pg = Polygon(p["poly"]).buffer(0)
            except Exception: continue
            if pg.is_empty: continue
            nt = len(tank_tree.query(pg, predicate="contains"))
            kind = "chemical_storage" if (CHEM.search(p["name"] or "") or p["industrial"] == "oil" or nt >= 3) else ("logistics" if (p["industrial"] in ("warehouse", "depot", "port") or LOGI.search(p["name"] or "")) else "other_industrial")
            polys.append(dict(p, geom=pg, n_tanks=nt, kind=kind))
        dens = P["park_density_per_ha"]
        Tr = None if wp.crs.to_epsg() == 4326 else Transformer.from_crs(4326, wp.crs, always_xy=True)
        E = np.zeros_like(WP)
        for kind in ("other_industrial", "logistics", "chemical_storage"):# later kinds overwrite
            shp = [((q["geom"] if Tr is None else shapely.ops.transform(Tr.transform, q["geom"])), 1) for q in polys if q["kind"] == kind]
            if not shp: continue
            msk = features.rasterize(shp, out_shape=WP.shape, transform=tr, fill=0, all_touched=False).astype(bool)
            E[msk] = (dens[kind] * cell_ha[:, None] * np.ones((1, W_)))[msk]
        s.note(f"{R['population'].get('label', 'Population')} total in raster {WP.sum():.0f}; park employment E total {E.sum():.0f} on {(E>0).sum()} cells; polygons by kind {pd.Series([q['kind'] for q in polys], dtype=object).value_counts().to_dict()}")
        DAY, NIGHT = WP + E, WP.copy()
        prof = wp.profile.copy(); prof.update(dtype="float32", nodata=0, compress="deflate")
        for nm_, A_ in (("pop_day.tif", DAY), ("pop_night.tif", NIGHT)):
            with rasterio.open(OUT / nm_, "w", **prof) as d: d.write(A_.astype("float32"), 1)
        rr, cc = np.nonzero(DAY > 0); cid = rr * W_ + cc
        lon_c = tr.c + tr.a * (cc + 0.5); latc = tr.f + tr.e * (rr + 0.5)
        Tc = T if wp.crs.to_epsg() == R["crs"]["geographic"] else Transformer.from_crs(wp.crs, R["crs"]["projected"], always_xy=True)
        cx, cy = Tc.transform(lon_c, latc); tree = cKDTree(np.c_[cx, cy]); cpts = shapely.points(cx, cy)
        pday, pnight = DAY[rr, cc], NIGHT[rr, cc]
        radii = pd.read_csv(R.path("radii")).set_index("substance")
        G = list(arcs.geom_utm)
        def cellsets(r_m):
            ind, ptr = [], [0]
            for g in G:
                dens_ = shapely.segmentize(g, 25.0); pts = shapely.get_coordinates(dens_)
                qb = tree.query_ball_point(pts, r_m + 25.0) if len(pts) else []
                cand = np.unique(np.concatenate([np.asarray(z, dtype=np.int64) for z in qb])) if len(qb) else np.array([], np.int64)
                cand = cand.astype(int)
                ok = cand[shapely.dwithin(cpts[cand], g, r_m)] if len(cand) else cand
                ind.append(np.sort(ok)); ptr.append(ptr[-1] + len(ok))
            data = np.ones(ptr[-1], dtype=bool)
            return sparse.csr_matrix((data, np.concatenate(ind) if ind else [], ptr), shape=(len(G), len(cx)))
        for sb in radii.index:
            for tag, r_m in (("", radii.loc[sb, "primary_radius_km"] * 1000), ("_iso", float(radii.loc[sb, "isolation_m"]))):
                M = cellsets(r_m)
                arcs[f"pop_{sb}{tag}"] = (M @ pday).round(2); arcs[f"pop_{sb}{tag}_night"] = (M @ pnight).round(2)
                if tag == "": sparse.save_npz(OUT / f"arc_cells_{sb}.npz", M.astype(np.int8), compressed=True)
                s.note(f"radius {sb}{tag} {r_m:.0f} m: nnz {M.nnz}")
        np.savez_compressed(OUT / "cells.npz", cell_flat_index=cid.astype(np.int32), row=rr.astype(np.int32), col=cc.astype(np.int32), **{XC: cx.astype(np.float32), YC: cy.astype(np.float32)},
                            pop_day=pday.astype(np.float32), pop_night=pnight.astype(np.float32), raster_shape=np.array(WP.shape))
        for sb in radii.index:# agreement with the snapshot's per-arc exposure, if it has one (same method, residential only = night)
            if f"pop_{sb}" in s.arcs0: s.note(f"pop_{sb}_night vs v0 pop_{sb}: median ratio {np.median((arcs[f'pop_{sb}_night']+1)/(s.arcs0[f'pop_{sb}'].values+1)):.3f}")
        s.polys, s.pois, s.radii = polys, pois, radii

# ---------------- 3. graph, gen/attr/gateways ----------------
    def facilities(s):
        R, P, T, XC, YC, nodes, polys, pois = s.R, s.P, s.T, s.XC, s.YC, s.nodes, s.polys, s.pois
        Gx = nx.DiGraph()
        for r in s.arcs.itertuples(): Gx.add_edge(r.u, r.v, t=r.time_min + getattr(r, "toll_min", 0.0), L=r.length_km)
        prohibited = set(zip(s.arcs.u[s.arcs.hazmat_status == "prohibited"], s.arcs.v[s.arcs.hazmat_status == "prohibited"]))
        allowed = Gx.copy(); allowed.remove_edges_from(prohibited)
# optional per-substance ADR tunnel restrictions (params tunnel_forbidden: {substance: [categories]}); a hazmat class uses the union
# of the categories forbidden for its substances. Without the key the single allowed graph is used (single allowed graph).
        s.hc_key, s.allowed_by = {}, {}
        tf = P.get("tunnel_forbidden")
        if tf and "tunnel_cat" in s.arcs:
            for hc, subs in P["substance_split"].items():
                cats = tuple(sorted(set().union(*[set(tf.get(x, tf.get("default", []))) for x in subs]))); s.hc_key[hc] = cats
                if cats not in s.allowed_by:
                    g_ = allowed.copy(); bad = s.arcs[s.arcs.tunnel_cat.isin(cats)]; g_.remove_edges_from(zip(bad.u, bad.v)); s.allowed_by[cats] = g_
                    s.note(f"tunnel restriction {list(cats) or 'none'}: {len(bad)} arcs removed for classes {[h for h, k in s.hc_key.items() if k == cats]}")
        nxy = nodes.set_index("node")[[XC, YC]]; ntree = cKDTree(nxy.values); nid = nxy.index.values
        def snap(lon, lat):
            x, y = T.transform(lon, lat); d, k = ntree.query([x, y]); return int(nid[k]), float(d)
        gens = []
        def add_gen(gid, node, typ, area, src, dist=0.0, cap=None, cap_m3=None):
            gens.append(dict(id=gid, name=f"Facility {gid} ({typ})", node=node, type=typ, area_ha=round(area, 2), snap_dist_m=round(dist, 1), weight_src=src))
            if cap is not None: gens[-1]["capacity_kbd"] = cap# optional (RotterdamHaz: refinery crude capacity, kb/d)
            if cap_m3 is not None: gens[-1]["capacity_m3"] = cap_m3# optional (RotterdamHaz: terminal tank storage capacity, m3)
        pz = P["petro_zone_bbox"]
        fixed = P.get("fixed_origins") or {}
        used = set(); RM = P.get("fixed_origin_match_m", 150)
        for gid, spec in fixed.items():
            nd = int(spec["node"]); x = nodes.set_index("node").loc[nd]; pt = Point(x[XC], x[YC])
            near = [q for q in polys if q["osm"] not in used and shapely.ops.transform(T.transform, q["geom"]).distance(pt) <= RM]
            q = max(near, key=lambda q: q["area_m2"])
            assert gid == f"G{len(gens) + 1:02d}"
            add_gen(gid, nd, spec["type"], q["area_m2"] / 1e4, "existing v0 exit node; area"); used.add(q["osm"])
# facility point ingestion (e.g. Seveso / BRZO / E-PRTR sites): area from the enclosing OSM industrial/port polygon, else default
        fp = R.get("facilities") or {}
        if fp.get("points"):
            pts = pd.read_csv(R.resolve(fp["points"]))
            if "lon" not in pts:# x, y in fp["points_crs"]
                Tq = Transformer.from_crs(fp["points_crs"], R["crs"]["geographic"], always_xy=True); pts["lon"], pts["lat"] = Tq.transform(pts.x.values, pts.y.values)
            ptree = shapely.STRtree([q["geom"] for q in polys]) if polys else None
            for p in pts.itertuples():
                typ = getattr(p, "type"); area, src = None, None
                if ptree is not None:
                    hit = [polys[k] for k in ptree.query(Point(p.lon, p.lat), predicate="within") if polys[k]["osm"] not in used]
                    if hit: q = max(hit, key=lambda q: q["area_m2"]); area = q["area_m2"] / 1e4; used.add(q["osm"]); src = f"facility register point; area of enclosing OSM polygon ({q['kind']})"
                if fp.get("prefer_point_area") and hasattr(p, "area_ha") and pd.notna(p.area_ha):# RotterdamHaz: terminal site polygon area from the point file
                    area = float(p.area_ha); src = f"facility list point; area of {p.area_src}" if isinstance(getattr(p, "area_src", ""), str) and p.area_src else "facility register point; area from register"
                if area is None: area = float(getattr(p, "area_ha", float("nan")) if hasattr(p, "area_ha") and pd.notna(getattr(p, "area_ha")) else fp.get("default_area_ha", 10.0)); src = "facility register point; area from register or default (assumed)"
                nd, d = snap(p.lon, p.lat)
                cap = getattr(p, "capacity_kbd", None); cap = float(cap) if cap is not None and pd.notna(cap) else None
                c3 = getattr(p, "capacity_m3", None); c3 = float(c3) if c3 is not None and pd.notna(c3) else None
                add_gen(f"G{len(gens) + 1:02d}", nd, typ, area, src, d, cap, c3)
        if fp.get("osm_polygons", True):
            for q in polys:
                if q["osm"] in used: continue
                lon, lat = q["geom"].centroid.x, q["geom"].centroid.y
                if not (pz[0] <= lon <= pz[2] and pz[1] <= lat <= pz[3]): continue
                if q["kind"] == "other_industrial" or q["area_m2"] < P["min_gen_area_ha"] * 1e4: continue
                if fp.get("osm_polygon_kinds") and q["kind"] not in fp["osm_polygon_kinds"]: continue# RotterdamHaz: e.g. only chemical_storage
                if q["n_tanks"] < fp.get("osm_polygon_min_tanks", 0): continue# RotterdamHaz: polygons classed chemical_storage by name only ('terminal' = container terminals) dropped
                if fp.get("osm_polygon_exclude_name") and re.search(fp["osm_polygon_exclude_name"], q["name"] or ""):# RotterdamHaz: terminals excluded from the
                    s.note(f"OSM polygon {q['osm']} ({q['name']}, {q['area_m2'] / 1e4:.1f} ha) excluded by name"); continue# port list do not re-enter as chemical
                typ = "port" if fp.get("osm_polygon_port", True) and (q["industrial"] == "port" or re.search(P["port_name_regex"], q["name"] or "")) else "chemical"
                nd, d = snap(lon, lat)
                add_gen(f"G{len(gens) + 1:02d}", nd, typ, q["area_m2"] / 1e4, f"OSM polygon ({q['kind']}, tanks={q['n_tanks']}); area", d)
        gen = pd.DataFrame(gens)
        gen["needs_manual_check"] = gen.snap_dist_m > P["snap_check_m"]
        att = []
        ab = fp.get("attraction_bbox")
        for p in pois:
            if p["amenity"] == "fuel" and (not ab or (ab[0] <= p["lon"] <= ab[2] and ab[1] <= p["lat"] <= ab[3])):
                nd, d = snap(p["lon"], p["lat"]); aid = f"A{len(att) + 1:02d}"
                att.append(dict(id=aid, name=f"Attractor {aid} (fuel station)", node=nd, type="fuel_station", snap_dist_m=round(d, 1), weight=1.0, weight_src="count (assumed)"))
        for g in gen.itertuples():
            if g.type == "chemical":
                aid = f"A{len(att) + 1:02d}"
                att.append(dict(id=aid, name=f"Attractor {aid} (chemical firm, site of {g.id})", node=g.node, type="chemical_firm", snap_dist_m=g.snap_dist_m, weight=g.area_ha, weight_src="area (assumed)"))
        attr = pd.DataFrame(att); attr["needs_manual_check"] = attr.snap_dist_m > P["snap_check_m"]
        gate = s._gateways(snap)
        s.note(f"gen points {len(gen)} {gen.type.value_counts().to_dict()}; attractions {len(attr)} {attr.type.value_counts().to_dict()}; gateways {len(gate)}")
        s.allowed, s.gen, s.attr, s.gate = allowed, gen, attr, gate

    def _gateways(s, snap):
        R, nodes = s.R, s.nodes; g = R["gateways"]; src = g["source"]; gws = []
        if src == "snapshot_od":# destinations of a hand-built OD
            od0 = pd.read_csv(R.resolve(g["od"]))
            for r in od0.drop_duplicates("destination")[["destination", "destination_name"]].itertuples():
                x = nodes.set_index("node").loc[r.destination]; gws.append(dict(id=f"W_{r.destination}", name=r.destination_name, node=int(r.destination), type="gateway", lon=x.lon, lat=x.lat, weight=1.0, weight_src="equal (assumed)"))
        elif src == "points":# list of {name, lon, lat[, weight]}; optional snap_classes restricts snapping to nodes of those road classes
            if g.get("snap_classes"):
                a = s.arcs[s.arcs.road_class.isin(g["snap_classes"])]; sub = nodes[nodes.node.isin(set(a.u) | set(a.v))]
                st = cKDTree(sub[[s.XC, s.YC]].values); sid = sub.node.values
                def snap(lon, lat):
                    x, y = s.T.transform(lon, lat); d, k = st.query([x, y]); return int(sid[k]), float(d)
            for p in g["points"]:
                nd, d = snap(p["lon"], p["lat"]); x = nodes.set_index("node").loc[nd]
                if d > g.get("max_snap_m", 3000): s.note(f"WARNING gateway {p['name']} snapped {d:.0f} m away")
                gws.append(dict(id=f"W_{nd}", name=p["name"], node=nd, type="gateway", lon=x.lon, lat=x.lat, weight=float(p.get("weight", 1.0)), weight_src=p.get("weight_src", "equal (assumed)")))
        elif src == "auto_boundary":# nodes on the given road classes within tol_m of the network bbox edge, one per cluster
            W, S, E, N = g["bbox"]; tol = g.get("tol_m", 300); cl = set(g.get("classes", ["motorway", "trunk", "primary"]))
            a = s.arcs[s.arcs.road_class.str.replace("_link", "", regex=False).isin(cl)]
            cand = nodes[nodes.node.isin(set(a.u) | set(a.v))].copy()
            Tb = s.T; bx = Tb.transform([W, E, E, W], [S, S, N, N])
            xmin, xmax, ymin, ymax = min(bx[0]), max(bx[0]), min(bx[1]), max(bx[1])
            cand["dist"] = np.minimum.reduce([cand[s.XC] - xmin, xmax - cand[s.XC], cand[s.YC] - ymin, ymax - cand[s.YC]])
            cand = cand[cand.dist <= tol].sort_values(["dist", "node"])
            taken = []
            for r in cand.itertuples():
                xy = np.array([getattr(r, s.XC), getattr(r, s.YC)])
                if all(np.hypot(*(xy - t)) > g.get("cluster_m", 1000) for t in taken):
                    taken.append(xy); gws.append(dict(id=f"W_{r.node}", name=f"boundary gateway {len(gws) + 1} ({r.lon:.3f},{r.lat:.3f})", node=int(r.node), type="gateway", lon=r.lon, lat=r.lat, weight=1.0, weight_src="equal (assumed)"))
        else: raise ValueError(src)
        if not gws and s.P.get("gateway_share", 0) > 0: raise SystemExit("no gateways found but gateway_share > 0: check region.gateways")
        return pd.DataFrame(gws)

# ---------------- 4. OD ----------------
    def od(s):
        R, P, OUT, gen, attr, gate, allowed = s.R, s.P, s.OUT, s.gen, s.attr, s.gate, s.allowed
        O = P["od_totals_10kt"]
        tt = {}
        srcs = sorted(set(gen.node))
        for s_ in srcs: tt[s_] = nx.single_source_dijkstra_path_length(allowed, s_, weight="t")
        ttk = {k: {s_: nx.single_source_dijkstra_path_length(g_, s_, weight="t") for s_ in srcs} for k, g_ in s.allowed_by.items()}
        ttc = lambda hc: ttk[s.hc_key[hc]] if s.hc_key else tt
        dests = pd.concat([attr[["id", "node", "type", "weight"]], gate[["id", "node", "type", "weight"]]], ignore_index=True)
        def furness(Oi, Dj, C, beta, it=2000):
            F = np.where(np.isfinite(C), np.maximum(C, 1.0) ** (-beta), 0.0)
            A, B = np.ones(len(Oi)), np.ones(len(Dj))
            for k in range(it):
                A = 1 / np.maximum(F @ (B * Dj), 1e-300); B = 1 / np.maximum(F.T @ (A * Oi), 1e-300)
                Tm = (A * Oi)[:, None] * F * (B * Dj)[None, :]
                er = max(np.max(np.abs(Tm.sum(1) - Oi) / np.maximum(Oi, 1e-12)), np.max(np.abs(Tm.sum(0) - Dj) / np.maximum(Dj, 1e-12)))
                if er < 1e-6: return Tm, k + 1, er
            return Tm, it, er
        prov = R["od"]["provenance"]
        def build_od(sc, beta):
            tot, ref, port = O["total"][sc], O["refinery"][sc], O["port"][sc]
            rest = tot - ref - port
            out, conv = [], []
            g = gen.copy()
            wr = g.capacity_kbd if P.get("refinery_weighting") == "capacity" else g.area_ha# RotterdamHaz: refinery tonnage by crude capacity
            wp = g.capacity_m3 if P.get("port_weighting") == "capacity" else g.area_ha# RotterdamHaz: port tonnage by tank storage capacity
            with np.errstate(divide="ignore", invalid="ignore"):
                w = np.where(g.type == "refinery", ref * wr / wr[g.type == "refinery"].sum(), np.where(g.type == "port", port * wp / wp[g.type == "port"].sum(), rest * g.area_ha / g.area_ha[g.type == "chemical"].sum()))
            g["Q"] = w
            cs = P["class_split"]
            for hc in ("class3", "class2", "other"):
                Oi = np.array([q.Q * cs[q.type][hc] for q in g.itertuples()])
                elig = dests[(dests.type != "fuel_station") | (hc == "class3")].reset_index(drop=True)
                gshare = P["gateway_share"]
                wi = elig.weight.where(elig.type != "gateway", 0.0)
# gateways: equal split, or with gateway_weighting weight, in proportion to gateways.weight (VGS counts)
                wg = elig.weight.where(elig.type == "gateway", 0.0) if P.get("gateway_weighting") == "weight" else (elig.type == "gateway").astype(float)
                tth = ttc(hc); C = np.array([[tth[o].get(d, np.inf) if o != d else np.inf for d in elig.node] for o in g.node])
# RotterdamHaz: a destination no origin can reach on this class's graph (e.g. the A29 gateway behind the category-C
# Heinenoordtunnel for class2/LPG) gets zero attraction; its share goes pro rata to the reachable destinations of its kind.
# Without unreachable destinations nothing changes.
                dead = ~np.isfinite(C).any(axis=0)
                if dead.any():
                    if sc == "base" and beta == P["beta"]: s.note(f"{hc}: destinations unreachable on the class graph, attraction set to 0: {list(elig.id[dead])}")
                    wi = wi.where(~dead, 0.0); wg = wg.where(~dead, 0.0)
                Dj = Oi.sum() * ((1 - gshare) * wi / wi.sum() + gshare * wg / wg.sum())
                Tm, k, er = furness(Oi, Dj.values, C, beta); conv.append(dict(scenario=sc, beta=beta, hc=hc, iters=k, rel_err=er))
                for i in range(len(g)):
                    for j in range(len(elig)):
                        if Tm[i, j] <= 0: continue
                        subs = P["substance_split"][hc]
                        for s_, f_ in subs.items():
                            q = Tm[i, j] * f_
                            if q < P["min_od_10kt"]: continue
                            out.append(dict(origin=int(g.node[i]), origin_id=g.id[i], origin_type=g.type[i], destination=int(elig.node[j]), dest_id=elig.id[j], dest_type=elig.type[j],
                                            hazmat_class=hc, substance=s_, tons_per_year=q * 1e4))
            od = pd.DataFrame(out)
            od["trips_loaded_per_year"] = od.tons_per_year / P["load_t"]["base"]
            od["shortest_time_min"] = [ttc(h)[o][d] for o, d, h in zip(od.origin, od.destination, od.hazmat_class)] if s.hc_key else [tt[o][d] for o, d in zip(od.origin, od.destination)]
            od.insert(0, "od_id", [f"{sc}_b{beta}_{k:05d}" for k in range(len(od))])
            od["provenance"] = prov % beta
            return od, conv, g
        convs = []; ods = {}
        b0 = P["beta"]
        for sc in ("low", "base", "high"):
            od, cv, gq = build_od(sc, b0); od.to_csv(OUT / f"od_{sc}.csv", index=False); convs += cv; ods[sc] = od
            if sc == "base": gen["Q_base_10kt"] = gq.Q.round(3)
        for b in P["beta_sens"]:
            if b == b0: continue
            od, cv, _ = build_od("base", b); od.to_csv(OUT / f"od_base_beta{b}.csv", index=False); convs += cv
        pd.DataFrame(convs).to_csv(OUT / "gravity_convergence.csv", index=False)
        for sc, od in ods.items(): s.note(f"OD {sc}: rows {len(od)}, Σtons {od.tons_per_year.sum()/1e4:.1f} x10^4 t, loaded trips/day {od.trips_loaded_per_year.sum()/365:.0f}, risk-modelled share {(od.substance!='other').mean():.2f} rows")
        od = ods["base"]; flow = {}; s.paths = {}; s.paths_by = {k: {} for k in s.allowed_by}
        if s.hc_key:# restricted graphs: AON per hazmat class on its own graph
            for (o, hc), grp in od.groupby(["origin", "hazmat_class"]):
                k = s.hc_key[hc]
                if o not in s.paths_by[k]: s.paths_by[k][o] = nx.single_source_dijkstra(s.allowed_by[k], o, weight="t")[1]
                for d, tr_ in grp.groupby("destination").trips_loaded_per_year.sum().items():
                    p = s.paths_by[k][o][d]
                    for e in zip(p[:-1], p[1:]): flow[e] = flow.get(e, 0) + tr_
        else:
          for o, grp in od.groupby("origin"):
            _, paths = nx.single_source_dijkstra(allowed, o, weight="t"); s.paths[o] = paths
            for d, tr_ in grp.groupby("destination").trips_loaded_per_year.sum().items():
                p = paths[d]
                for e in zip(p[:-1], p[1:]): flow[e] = flow.get(e, 0) + tr_
        arcs = s.arcs
        arcs["flow_loaded_base"] = [round(flow.get((u, v), 0.0), 2) for u, v in zip(arcs.u, arcs.v)]
        gw_trips = od[od.dest_type == "gateway"].trips_loaded_per_year.sum() / od.trips_loaded_per_year.sum()
        fk = (arcs.flow_loaded_base * arcs.length_km)
        s.note(f"AON base: arcs with flow {(arcs.flow_loaded_base>0).sum()}; gateway trip share {gw_trips:.3f}; corridor arcs flow-km share {fk[arcs.hazmat_status=='allowed_corridor'].sum()/fk.sum():.3f}")
        s.ods = ods
# optional: calibrate the base OD to observed link flows (written as extra files; the gravity scenarios stay unchanged)
        if (R.get("od") or {}).get("calibration"):
            s.od_cal = calibrate.run(s, R["od"]["calibration"])
            if (R.get("instances") or {}).get("use_calibrated"):# RotterdamHaz: instances and an extra flow column from the calibrated base OD
                fc = {}
                for o, d, hc, tr_ in zip(s.od_cal.origin, s.od_cal.destination, s.od_cal.hazmat_class, s.od_cal.trips_loaded_per_year):
                    p = s.path(o, d, hc)
                    for e in zip(p[:-1], p[1:]): fc[e] = fc.get(e, 0) + tr_
                arcs["flow_loaded_calibrated"] = [round(fc.get((u, v), 0.0), 2) for u, v in zip(arcs.u, arcs.v)]
                s.note(f"instances from od_base_calibrated (Σtons {s.od_cal.tons_per_year.sum()/1e4:.1f} x10^4 t, loaded trips/day {s.od_cal.trips_loaded_per_year.sum()/365:.0f})")

    def path(s, o, d, hc=None):
        return s.paths_by[s.hc_key[hc]][o][d] if s.hc_key else s.paths[o][d]

# ---------------- 5. instances + write ----------------
    def instances(s):
        R, P, OUT = s.R, s.P, s.OUT
        nt = s.nodes.set_index("node")
        for df_, t_ in ((s.gen, "gen"), (s.attr, "attr"), (s.gate, "gateway")):
            for n_ in df_.node: nt.loc[n_, "node_type"] = t_
        s.nodes = nt.reset_index()
        inst = OUT / "instances"; shutil.rmtree(inst, ignore_errors=True); inst.mkdir()
        od = s.od_cal if (R["instances"].get("use_calibrated") and getattr(s, "od_cal", None) is not None) else s.ods["base"]
        odr = od[od.substance != "other"].reset_index(drop=True)
        pre = R["instances"]["prefix"]; nrep = R["instances"].get("n_rep", 10)
        for K in P["instance_K"]:
            for r in range(nrep):
                seed = 1000 * K + r; g_ = np.random.default_rng(seed)
                dsts = odr.groupby("destination").tons_per_year.sum(); need = min(K, len(dsts))
                pick_d = g_.choice(dsts.index.values, size=need, replace=False, p=(dsts / dsts.sum()).values)
                chosen = []
                for d in pick_d:
                    sub = odr[odr.destination == d]; chosen.append(int(g_.choice(sub.index.values, p=(sub.tons_per_year / sub.tons_per_year.sum()).values)))
                rest = odr.drop(index=chosen)
                if K > need: chosen += list(g_.choice(rest.index.values, size=K - need, replace=False, p=(rest.tons_per_year / rest.tons_per_year.sum()).values))
                d_ = inst / f"{pre}_K{K}_r{r}"; d_.mkdir()
                x = odr.loc[chosen].copy(); x["seed"] = seed; x.to_csv(d_ / "od.csv", index=False)
        st = R["instances"].get("stratified")# optional (RotterdamHaz ): one instance with >= n rows per substance (tons-weighted, without replacement)
        if st:
            g_ = np.random.default_rng(st.get("seed", 7)); ch = []
            for sb_, sub in odr.groupby("substance", sort=True):
                k_ = min(st.get("per_substance", 10), len(sub)); ch += list(g_.choice(sub.index.values, size=k_, replace=False, p=(sub.tons_per_year / sub.tons_per_year.sum()).values))
                s.note(f"stratified instance {st['name']}: {sb_} {k_} rows (of {len(sub)})")
            d_ = inst / st["name"]; d_.mkdir(); x = odr.loc[ch].copy(); x["seed"] = st.get("seed", 7); x.to_csv(d_ / "od.csv", index=False)
        for ex in R.get("extra_instances") or []:# third-party test networks copied verbatim
            d_ = inst / ex["name"]; d_.mkdir()
            for f in ("nodes", "arcs", "od"): shutil.copy(R.resolve(ex["src"]).parent / f"{Path(ex['src']).name}_{f}.csv", d_ / f"{f}.csv")
            (d_ / "PROVENANCE.txt").write_text(ex["provenance"])

    def write(s):
        R, OUT = s.R, s.OUT
        arcs = s.arcs; arcs.pop("geom_utm")
        arcs = arcs.drop(columns=["length_km_utm"])
        arcs.to_csv(OUT / "arcs.csv", index=False)
        fc = {"type": "FeatureCollection", "features": [{"type": "Feature", "properties": {"u": int(u), "v": int(v)}, "geometry": {"type": "LineString", "coordinates": g}} for u, v, g in zip(arcs.u, arcs.v, s.geoms)]}
        json.dump(fc, open(OUT / "arcs.geojson", "w"))
        s.nodes[["node", "lon", "lat", s.XC, s.YC, "node_type"]].to_csv(OUT / "nodes.csv", index=False)
        s.gen.to_csv(OUT / "gen_points.csv", index=False); s.attr.to_csv(OUT / "attr_points.csv", index=False); s.gate.to_csv(OUT / "gateways.csv", index=False)
        for f in R.get("copy_files") or []: shutil.copy(R.resolve(f), OUT / Path(R.resolve(f)).name)
        if R.get("data_sources"): shutil.copy(R.resolve(R["data_sources"]), OUT / "DATA_SOURCES.csv")# provenance table (QA check 8)
        shutil.copy(R["_params_file"], OUT / "params.yaml")
        (OUT / "build_log.txt").write_text("\n".join(s.log) + "\n")

    def run(s):
        s.network(); s.population(); s.facilities(); s.od(); s.instances(); s.write()

def main(region_yaml, out, overrides=()):
    R = load(region_yaml, overrides); out = Path(out)
    pp = R.get("postprocess")
    raw = out.parent / (out.name + "_internal") if pp else out
    for d in {out, raw}:# refuse to wipe a non-empty directory that hazbench did not create
        if d.exists() and any(d.iterdir()):
            if not (d / ".hazbench_out").exists(): raise SystemExit(f"{d} is not empty and was not created by hazbench; choose another out_dir")
            shutil.rmtree(d)
        d.mkdir(parents=True, exist_ok=True); (d / ".hazbench_out").write_text(str(R["_file"]) + "\n")
    Build(R, raw).run()
    if pp:
        mod = importlib.import_module(pp if "." in pp else f"hazbench.plugins.{pp}")
        rep = mod.build(raw, out)
        for p in sorted(raw.rglob("*")):# non-data files (build_log, params, PROVENANCE) copied as they are
            q = out / p.relative_to(raw)
            if p.is_file() and p.suffix not in (".csv", ".tif", ".npz", ".geojson"): q.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, q)
        print("postprocess", pp, sum(v[1] for v in rep.values()), "cells rewritten")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3:])
