"""Region configuration: regions/<region>.yaml (where the data are, CRS, bbox, source-specific rules) +
regions/<region>.params.yaml (model parameters, copied verbatim into the release as params.yaml).

Path strings support ${VAR} / ${VAR:-default} environment expansion and {key} references to entries of `paths`."""
import os, re
from pathlib import Path
import yaml

_ENV = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")

def _env(s):
    return _ENV.sub(lambda m: os.environ.get(m.group(1), m.group(2) if m.group(2) is not None else ""), s)

class Region(dict):
    """dict with attribute access for the top level, plus helpers."""
    __getattr__ = dict.get
    def path(self, key, *sub):
        """Resolve a path-valued entry, e.g. region.path('network', 'arcs'). Returns None if missing."""
        v = self
        for k in (key,) + sub:
            if not isinstance(v, dict) or k not in v or v[k] is None: return None
            v = v[k]
        return self.resolve(v)
    def resolve(self, s):
        s = _env(str(s))
        for _ in range(5):# nested {paths} references
            n = re.sub(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", lambda m: _env(str(self["paths"][m.group(1)])) if m.group(1) in self.get("paths", {}) else m.group(0), s)
            if n == s: break
            s = n
        p = Path(s)
        return p if p.is_absolute() else (self["_dir"] / p).resolve()

def load(path, overrides=()):
    path = Path(path).resolve()
    R = Region(yaml.safe_load(open(path, encoding="utf-8")))
    R["_dir"] = path.parent; R["_file"] = path
    for o in overrides:# key.sub=value (value parsed as YAML)
        k, v = o.split("=", 1); d = R; ks = k.split(".")
        for kk in ks[:-1]: d = d.setdefault(kk, {})
        d[ks[-1]] = yaml.safe_load(v)
    pf = R.resolve(R["params_file"])
    R["_params_file"] = pf
    R["P"] = yaml.safe_load(open(pf, encoding="utf-8"))
    return R
