"""Optional calibration of the gravity-model base OD to observed hazmat link flows (e.g. Rijkswaterstaat counts of dangerous-goods
tank trucks per road section). The gravity scenarios are left untouched; results go to extra files:
  od_base_calibrated.csv   base OD with tons/trips rescaled
  calibration_sites.csv    per count site: matched arcs, observed, modelled before/after, GEH
Method: count sites are matched to arcs (directly by u,v or by nearest arc + opposite carriageway within max_dist_m); paths are the
base all-or-nothing paths (time-shortest on the allowed network, fixed); multiplicative updating: each OD row is scaled by the damped
geometric mean of obs/model over the count sites on its path, iterated (a simple iterative proportional matrix-estimation heuristic,
cf. Spiess 1990 / Van Zuylen & Willumsen 1980). Rows that cross no count site keep their gravity value.

Region YAML (od.calibration):
  observed: path to CSV with either (u, v) or (lon, lat) per site, plus flow columns
  site_id: column with site ids (optional)
  class_columns: {class3: [col, ...], class2: [col, ...]}# observed loaded trucks/year per hazmat class; or {all: [col]}
  match_classes: [motorway, trunk, primary]   max_dist_m: 150   both_directions: true
  cross_section: false# true: count all carriageways (incl. parallel carriageways) crossing a line normal to the road through the site
  iterations: 30   damping: 0.5   factor_bounds: [0.1, 10]
  site_arc_filter: {site_id: {tunnel_cat: [C]}}# optional manual fix where a tunnel and its detour route share one cross-section
  site_location: {site_id: [lon, lat]}# optional manual site position (e.g. a section not drawn in the count-site KMZ)"""
import numpy as np, pandas as pd
from pyproj import Transformer
import shapely
from shapely.geometry import LineString

def _bearing(g):
    c = shapely.get_coordinates(g); d = c[-1] - c[0]; return np.degrees(np.arctan2(d[1], d[0]))

def match_sites(b, cfg, obs):
    arcs = b.arcs; idx = {(u, v): k for k, (u, v) in enumerate(zip(arcs.u, arcs.v))}
    sites = []
    if "u" in obs and "v" in obs:
        for r in obs.itertuples(): sites.append([idx[(r.u, r.v)]] if (r.u, r.v) in idx else [])
        return sites
    cl = set(cfg.get("match_classes", ["motorway", "trunk", "primary", "secondary"])); md = cfg.get("max_dist_m", 150)
    cand = np.where(arcs.road_class.str.replace("_link", "", regex=False).isin(cl).values)[0]
    G = list(arcs.geom_utm.values[cand]); tree = shapely.STRtree(G)
    x, y = b.T.transform(obs.lon.values, obs.lat.values)
    for px, py in zip(x, y):
        p = shapely.Point(px, py); near = tree.query(p, predicate="dwithin", distance=md)
        if not len(near): sites.append([]); continue
        d = np.array([G[k].distance(p) for k in near]); order = near[np.argsort(d, kind="stable")]
        k0 = order[0]; s = [int(cand[k0])]
        if cfg.get("cross_section"):# all carriageways (main + parallel, both directions) crossing a line through the site normal to the road
            g0 = G[k0]; t0 = g0.project(p); a_, b_ = g0.interpolate(max(t0 - 20, 0)), g0.interpolate(min(t0 + 20, g0.length))
            d0 = np.array([b_.x - a_.x, b_.y - a_.y]); d0 = d0 / (np.linalg.norm(d0) or 1); nrm = np.array([-d0[1], d0[0]])
            xs = LineString([(px - nrm[0] * md, py - nrm[1] * md), (px + nrm[0] * md, py + nrm[1] * md)])
            s = []
            for k in tree.query(xs, predicate="intersects"):
                ip = G[k].intersection(xs)
                if ip.is_empty: continue
                q = shapely.get_coordinates(ip)[0]; tk = G[k].project(shapely.Point(q)); a2, b2 = G[k].interpolate(max(tk - 20, 0)), G[k].interpolate(min(tk + 20, G[k].length))
                dk = np.array([b2.x - a2.x, b2.y - a2.y]); dk = dk / (np.linalg.norm(dk) or 1)
                if abs(float(dk @ d0)) >= np.cos(np.radians(30)): s.append(int(cand[k]))
            sites.append(sorted(s)); continue
        if cfg.get("both_directions", True):
            b0 = _bearing(G[k0])
            for k in order[1:]:
                db = abs((_bearing(G[k]) - b0 + 180) % 360 - 180)
                if db > 150: s.append(int(cand[k])); break
        sites.append(s)
    return sites

def geh(m, c): return np.sqrt(2 * (m - c) ** 2 / np.maximum(m + c, 1e-9))

def run(b, cfg):
    R = b.R; obs = pd.read_csv(R.resolve(cfg["observed"]))
    for s_, ll in (cfg.get("site_location") or {}).items():# RotterdamHaz: manual site positions
        m = obs[cfg["site_id"]] == s_
        if m.sum() != 1: raise SystemExit(f"site_location: {s_} matches {int(m.sum())} rows")
        b.note(f"calibration site {s_}: manual location {ll} (was {obs.loc[m, 'lon'].iloc[0]:.5f}, {obs.loc[m, 'lat'].iloc[0]:.5f})")
        obs.loc[m, "lon"], obs.loc[m, "lat"] = float(ll[0]), float(ll[1])
    sites = match_sites(b, cfg, obs)
    flt = cfg.get("site_arc_filter") or {}# manual fixes (RotterdamHaz ): {site: {tunnel_cat: [cats; "" = not a tunnel]}} keeps only those arcs of the cross-section
    if flt:
        sid = list(obs[cfg["site_id"]]) if cfg.get("site_id") in obs else list(range(len(obs)))
        tc = b.arcs.tunnel_cat.fillna("").astype(str).values if "tunnel_cat" in b.arcs else np.array([""] * len(b.arcs))
        for j, s_ in enumerate(sid):
            if s_ in flt:
                keep = [k for k in sites[j] if tc[k] in flt[s_].get("tunnel_cat", [tc[k]])]
                b.note(f"calibration site {s_}: manual arc filter {flt[s_]}: {len(sites[j])} -> {len(keep)} arcs")
                sites[j] = keep
    od = b.ods["base"].copy(); arcs = b.arcs; idx = {(u, v): k for k, (u, v) in enumerate(zip(arcs.u, arcs.v))}
    arc2site = {}
    for j, s in enumerate(sites):
        for k in s: arc2site.setdefault(k, set()).add(j)
# sites crossed by each OD row's path
    row_sites = []
    for o, d, hc in zip(od.origin, od.destination, od.hazmat_class):
        p = b.path(o, d, hc); ss = set()
        for e in zip(p[:-1], p[1:]): ss |= arc2site.get(idx[e], set())
        row_sites.append(sorted(ss))
    it, damp = cfg.get("iterations", 30), cfg.get("damping", 0.5); lo, hi = cfg.get("factor_bounds", [0.1, 10])
    rep = pd.DataFrame({"site": obs[cfg["site_id"]] if cfg.get("site_id") in obs else np.arange(len(obs)), "arcs": [";".join(f"{arcs.u[k]}-{arcs.v[k]}" for k in s) for s in sites]})
    trips = od.trips_loaded_per_year.values.copy()
    for grp, cols in cfg["class_columns"].items():
        rows = np.arange(len(od)) if grp == "all" else np.where(od.hazmat_class.values == grp)[0]
        ob = obs[cols].sum(axis=1).values.astype(float)
        def model():
            m = np.zeros(len(sites))
            for i in rows:
                for j in row_sites[i]: m[j] += trips[i]
            return m
        m0 = model(); rep[f"obs_{grp}"] = ob; rep[f"model_before_{grp}"] = m0.round(2)
        ok = np.array([len(s) > 0 and np.isfinite(v) for s, v in zip(sites, ob)])
        ex = set(cfg.get("exclude_sites") or [])# optional (RotterdamHaz cross-validation): sections kept out of the calibration targets
        if ex: ok &= ~rep["site"].isin(ex).values
        f_site = np.ones(len(sites))
        for _ in range(it):
            m = model(); f_site = np.where(ok, (ob + 1) / (m + 1), 1.0)
            for i in rows:
                if row_sites[i]:
                    f = np.exp(damp * np.mean(np.log(f_site[row_sites[i]]))); trips[i] *= np.clip(f, lo, hi)
        m1 = model(); rep[f"model_after_{grp}"] = m1.round(2)
        rep[f"GEH_before_{grp}"] = np.where(ok, geh(m0, ob), np.nan).round(2); rep[f"GEH_after_{grp}"] = np.where(ok, geh(m1, ob), np.nan).round(2)
        b.note(f"calibration {grp}: {ok.sum()} matched sites of {len(sites)}; median GEH {np.nanmedian(rep[f'GEH_before_{grp}']):.2f} -> {np.nanmedian(rep[f'GEH_after_{grp}']):.2f}; "
               f"rows scaled {sum(1 for i in rows if row_sites[i])}/{len(rows)}; class trips {od.trips_loaded_per_year.values[rows].sum():.0f} -> {trips[rows].sum():.0f}")
    scale = trips / od.trips_loaded_per_year.values
    od["tons_per_year"] = od.tons_per_year * scale; od["trips_loaded_per_year"] = trips; od["calib_factor"] = scale.round(4)
    od["od_id"] = od.od_id.str.replace("base_", "basecal_", n=1)
    od.to_csv(b.OUT / "od_base_calibrated.csv", index=False); rep.to_csv(b.OUT / "calibration_sites.csv", index=False)
    return od
