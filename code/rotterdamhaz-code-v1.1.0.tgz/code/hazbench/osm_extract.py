"""Step 01 (generic): extract highway ways (tags + node refs) and POIs inside region.osm.extract_bbox from an OSM PBF.

Outputs in <osm_dir>:
  osm_ways.pkl   {"ways": {way_id: tags}, "seg": {(a, b): way_id}, "coord": {node_id: (lon, lat)}}   (way tags, segment index, coordinates)
  osm_pois.json  storage tanks, fuel stations, motorway junctions, industrial/port polygons (with polygon rings)
  osm_highways.pkl  {way_id: {"refs": [...], "tags": {...}}} ordered node refs for the graph builder (osm_graph.py)
Usage: python -m hazbench.osm_extract regions/<region>.yaml"""
import json, math, pickle, sys
from pathlib import Path
import osmium
from .config import load

TAGS = ("highway", "name", "lanes", "maxspeed", "oneway", "bridge", "tunnel", "layer", "hazmat", "hgv", "ref", "incline")
POI_KEYS = ("name", "highway", "man_made", "amenity", "industrial", "landuse", "operator", "ref", "content")
GRAPH_TAGS = TAGS + ("junction", "access", "motor_vehicle", "motorcar", "area", "service", "hazmat:water", "maxweight", "hgv:conditional", "hazmat:conditional")

def extract(pbf, out, bbox, keep_refs=True):
    W, S, E, N = bbox
    inb = lambda lon, lat: W <= lon <= E and S <= lat <= N
    class H(osmium.SimpleHandler):
        def __init__(s): super().__init__(); s.ways = {}; s.seg = {}; s.coord = {}; s.pois = []; s.hw = {}
        def node(s, n):
            if not n.location.valid() or not inb(n.location.lon, n.location.lat): return
            s.coord[n.id] = (round(n.location.lon, 7), round(n.location.lat, 7))
            t = dict(n.tags)
            if t.get("highway") == "motorway_junction" or t.get("man_made") == "storage_tank" or t.get("amenity") == "fuel" or "industrial" in t:
                s.pois.append({"osm": f"n{n.id}", "lon": n.location.lon, "lat": n.location.lat, "area_m2": 0, **{k: t.get(k, "") for k in POI_KEYS}})
        def way(s, w):
            t = dict(w.tags)
            try: locs = [(nd.ref, nd.lon, nd.lat) for nd in w.nodes]
            except Exception: return
            if not any(inb(lo, la) for _, lo, la in locs): return
            if "highway" in t:
                s.ways[w.id] = {k: t.get(k, "") for k in TAGS}
                refs = [l[0] for l in locs]
                for a, b in zip(refs[:-1], refs[1:]): s.seg[(a, b)] = w.id; s.seg[(b, a)] = w.id
                if keep_refs: s.hw[w.id] = {"refs": refs, "lonlat": [(round(lo, 7), round(la, 7)) for _, lo, la in locs], "tags": {k: t.get(k, "") for k in GRAPH_TAGS}}
            if t.get("landuse") in ("industrial", "port") or t.get("man_made") == "storage_tank" or "industrial" in t or t.get("amenity") == "fuel" or t.get("harbour"):
                if w.is_closed() and len(locs) > 3:
                    lon0 = sum(l[1] for l in locs) / len(locs); lat0 = sum(l[2] for l in locs) / len(locs)
                    kx, ky = 111320 * math.cos(math.radians(lat0)), 110540
                    xy = [((lo - lon0) * kx, (la - lat0) * ky) for _, lo, la in locs]
                    A = abs(sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(xy[:-1], xy[1:]))) / 2
                    s.pois.append({"osm": f"w{w.id}", "lon": lon0, "lat": lat0, "area_m2": A, "poly": [(lo, la) for _, lo, la in locs], **{k: t.get(k, "") for k in POI_KEYS}})
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    h = H(); h.apply_file(str(pbf), locations=True)
    pickle.dump({"ways": h.ways, "seg": h.seg, "coord": h.coord}, open(out / "osm_ways.pkl", "wb"))
    json.dump(h.pois, open(out / "osm_pois.json", "w"), ensure_ascii=False)
    if keep_refs: pickle.dump(h.hw, open(out / "osm_highways.pkl", "wb"))
    print(len(h.ways), "ways", len(h.seg), "segs", len(h.coord), "nodes", len(h.pois), "pois")

if __name__ == "__main__":
    R = load(sys.argv[1], sys.argv[2:])
    extract(R.path("paths", "osm_pbf"), R.path("paths", "osm_dir"), R["osm"]["extract_bbox"])
