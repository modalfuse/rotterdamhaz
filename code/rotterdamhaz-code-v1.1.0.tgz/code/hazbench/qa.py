"""QA (checks 1-10 + magnitude M). Writes <dataset>/qa_results.json.
  python -m hazbench.qa regions/<region>.yaml <dataset_dir> <baseline_results.csv> [rerun_dir]
Region-specific expectations come from region.qa (expect_nodes/expect_arcs optional; x_range of projected x)."""
import sys, json, hashlib, math
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx, rasterio, yaml
from pyproj import Transformer
from .config import load

def _m_basisnet(R, a, fcol, MQ, legacy):
    """Per Basisnet section: model releases per km and year, F = sum(flow x p_release_trip) / (sum(length) / 2) over the matched arcs (both
    carriageways), against the PR 10^-6 contour distance of Regeling basisnet Bijlage I (0 = the contour stays on the road). The Dutch
    contour grows with the flow of (mainly GF / GT) tank trucks times their release frequency, so the two should be positively rank-correlated.
    Pass: Spearman rho >= min_spearman. This tests the ordering of risk along the corridor, not its absolute level."""
    from scipy.stats import spearmanr, mannwhitneyu
    import re as _re
    hs = pd.read_csv(R.path("network", "hazmat_status_csv"), dtype={"basisnet_section": str}); hs = hs[hs.basisnet_section.notna()]
    bn = pd.read_csv(R.resolve(R["hazmat_status"]["basisnet_csv"]), header=None, dtype=str).iloc[:, :4]; bn.columns = ["sec", "name", "pr6", "pr7"]
    bn = bn[bn.sec.fillna("").str.match(r"^[A-Z][a-z]?\d+$")]; bn["pr6_m"] = pd.to_numeric(bn.pr6.str.extract(r"(\d+)")[0], errors="coerce").fillna(0)
    x = hs.merge(a[["u", "v", fcol, "p_release_trip", "length_km"]], on=["u", "v"])
    g = x.groupby("basisnet_section").apply(lambda d: pd.Series({"F": (d[fcol] * d.p_release_trip).sum() / (d.length_km.sum() / 2), "km": d.length_km.sum() / 2}), include_groups=False)
    g = g.join(bn.set_index("sec").pr6_m, how="inner"); g = g[g.km >= MQ.get("min_km", 0.5)]
    rho, p = spearmanr(g.F, g.pr6_m); pos, zero = g.F[g.pr6_m > 0], g.F[g.pr6_m == 0]
    auc = mannwhitneyu(pos, zero).statistic / (len(pos) * len(zero)) if len(pos) and len(zero) else float("nan")
    if a.attrs.get("_dir"): g.to_csv(Path(a.attrs["_dir"]) / "plausibility_magnitude_basisnet.csv")# plausibility_* = QA output, excluded from check 9
    ok = bool(rho >= MQ.get("min_spearman", 0.3))
    return ok, (f"{len(g)} Basisnet sections (>= {MQ.get('min_km', 0.5)} km matched): Spearman rho(F, PR10-6 distance) = {rho:.2f} (p = {p:.3f}, threshold {MQ.get('min_spearman', 0.3)}); "
                f"sections with PR10-6 contour > 0 m: {len(pos)}, median F {np.median(pos) if len(pos) else float('nan'):.2e} /km/yr vs {len(zero)} sections at 0 m: {np.median(zero) if len(zero) else float('nan'):.2e}; "
                f"AUC {auc:.2f}. Relative check only. {legacy}")

def run(R, D, BL, RR=None):
    D, BL = Path(D), Path(BL); RR = Path(RR) if RR else None
    Q = R.get("qa") or {}; XC, YC = R["crs"]["xy_cols"]
    P = yaml.safe_load(open(D / "params.yaml")); n = pd.read_csv(D / "nodes.csv"); a = pd.read_csv(D / "arcs.csv", dtype={"tunnel_cat": str}); a.attrs["_dir"] = str(D); res = []
    def chk(i, name, ok, detail): res.append(dict(id=i, check=name, passed=bool(ok), detail=detail)); print(("PASS" if ok else "FAIL"), i, name, detail)
    v0 = pd.read_csv(R.path("network", "arcs"))
    cnt_ok = (Q.get("expect_nodes") in (None, len(n))) and (Q.get("expect_arcs") in (None, len(a)))
    nl = int((v0.u == v0.v).sum())
    chk(1, "Node/arc counts and integrity", cnt_ok and not (a.u == a.v).any() and not a.duplicated(["u", "v"]).any() and set(a.u) | set(a.v) <= set(n.node),
        f"nodes {len(n)}, arcs {len(a)} (network snapshot had {len(v0)} rows; {nl} self-loop(s) removed), self-loops {(a.u==a.v).sum()}, duplicates {a.duplicated(['u','v']).sum()}")
    T = Transformer.from_crs(R["crs"]["projected"], R["crs"]["geographic"], always_xy=True); lo, la = T.transform(n[XC].values, n[YC].values)
    err = max(np.abs(lo - n.lon).max(), np.abs(la - n.lat).max()); xr = Q.get("x_range", [-1e7, 1e7])
    chk(2, "Projection", n[XC].between(*xr).all() and (n[XC] != n.lon).all() and err < 1e-6, f"EPSG:{R['crs']['projected']} x in [{n[XC].min():.0f}, {n[XC].max():.0f}] m, y in [{n[YC].min():.0f}, {n[YC].max():.0f}] m, back-projection error {err:.2e} deg")
    xy = n.set_index("node")[[XC, YC]]; st = np.hypot(xy.loc[a.u].values[:, 0] - xy.loc[a.v].values[:, 0], xy.loc[a.u].values[:, 1] - xy.loc[a.v].values[:, 1]) / 1000
    ratio = a.length_km / np.maximum(st, 1e-9)
    chk(3, "Arc length >= straight-line distance; time > 0", (ratio >= 0.99).all() and (a.time_min > 0).all(), f"minimum ratio {ratio.min():.4f}; median ratio to snapshot length_km {np.median(a.length_km / v0[v0.u != v0.v].length_km.values):.4f}")
    G = nx.DiGraph(); G.add_edges_from(zip(a.u, a.v)); G.remove_edges_from(zip(a.u[a.hazmat_status == "prohibited"], a.v[a.hazmat_status == "prohibited"]))
    odb = pd.read_csv(D / "od_base.csv")
    if P.get("tunnel_forbidden") and "tunnel_cat" in a:# per hazmat class: graph without the tunnel categories forbidden for its substances
        tf = P["tunnel_forbidden"]; unreach = 0
        for hc, grp in odb.groupby("hazmat_class"):
            cats = set().union(*[set(tf.get(x, tf.get("default", []))) for x in P["substance_split"][hc]])
            Gc = G.copy(); Gc.remove_edges_from(zip(a.u[a.tunnel_cat.isin(cats)], a.v[a.tunnel_cat.isin(cats)]))
            unreach += sum(1 for o, d in set(zip(grp.origin, grp.destination)) if not nx.has_path(Gc, o, d))
    else: unreach = sum(1 for o, d in set(zip(odb.origin, odb.destination)) if not nx.has_path(G, o, d))
    corr = a.groupby("corridor").length_km.sum().drop("", errors="ignore").to_dict() if a.corridor.notna().any() else {}
    chk(4, "All OD pairs reachable on the allowed network", unreach == 0, f"unreachable OD {unreach}; corridor length inside the network {corr}" + (f" ({Q['corridor_note']})" if Q.get("corridor_note") else ""))
    wp = rasterio.open(R.path("population", "raster")).read(1).astype(float); wp[~np.isfinite(wp)] = 0; wp[wp < 0] = 0
    pn = rasterio.open(D / "pop_night.tif").read(1).astype(float); pdy = rasterio.open(D / "pop_day.tif").read(1).astype(float)
    bl = pd.read_csv(BL)
    chk(5, "Population totals consistent; PE_union <= PE_sum", abs(pn.sum() / wp.sum() - 1) < 1e-3 and (bl.PE_union <= bl.PE_sum * (1 + 1e-4) + 1e-6).all(),
        f"(per-arc population rounded to 0.01, tolerance 1e-4) source {wp.sum():.0f}, pop_night {pn.sum():.0f}, pop_day {pdy.sum():.0f} (+ park employment {pdy.sum()-pn.sum():.0f}); baseline paths {len(bl)}, PE_sum/PE_union median {bl.DCR_PE.median():.2f}, range [{bl.DCR_PE.min():.2f}, {bl.DCR_PE.max():.2f}]")
    lw = (a.lambda_arc * a.length_km).sum() / a.length_km.sum()
    chk(6, "Length-weighted lambda_arc = lambda_base", abs(lw / P["lambda_base"]["base"] - 1) < 1e-6, f"weighted mean {lw:.6e}, lambda_base {P['lambda_base']['base']:.2e}")
    cv = pd.read_csv(D / "gravity_convergence.csv"); tots = {sc: pd.read_csv(D / f"od_{sc}.csv").tons_per_year.sum() / 1e4 for sc in ("low", "base", "high")}
    dd = []; pre = R["instances"]["prefix"]
    for K in P["instance_K"]:
        for r in range(R["instances"].get("n_rep", 10)):
            x = pd.read_csv(D / f"instances/{pre}_K{K}_r{r}/od.csv"); dd.append((K, len(x), x.destination.nunique()))
    nJ = odb[odb.substance != "other"].destination.nunique()
    ok7 = all(abs(tots[s] - P["od_totals_10kt"]["total"][s]) / P["od_totals_10kt"]["total"][s] < 0.01 for s in tots) and (cv.rel_err < 1e-6).all() and all(L == K and u >= min(K, nJ) for K, L, u in dd)
    chk(7, "OD totals, gravity-model convergence, instance destination counts", ok7, f"total 10^4 t {({k: round(float(v),1) for k,v in tots.items()})} (targets {'/'.join(str(P['od_totals_10kt']['total'][s]) for s in ('low','base','high'))}); Furness max relative error {cv.rel_err.max():.1e}; distinct destinations {nJ}, minimum destinations per instance {min(u for _,_,u in dd)} (K={min(P['instance_K'])})")
    if (D / "DATA_SOURCES.csv").exists():
        pv = pd.read_csv(D / "DATA_SOURCES.csv")
        chk(8, "Provenance table has no empty entries", not pv[["item", "label", "source_ref"]].isna().any().any() and pv.label.isin(["official", "real", "estimated", "assumed"]).all(), f"{len(pv)} rows; labels {pv.label.value_counts().to_dict()}")
    else: chk(8, "Provenance table has no empty entries", False, "DATA_SOURCES.csv missing (written by hand per region)")
    if RR:
        RR = Path(RR)
        files = [p.relative_to(D) for p in D.rglob("*") if p.is_file() and p.suffix in (".csv", ".npz", ".geojson", ".tif") and "DATA_SOURCES" not in p.name and "inputs_v0" not in p.parts and "_baselines" not in p.parts and not p.name.startswith("plausibility_")]# downstream outputs (baselines/stats, QA plausibility) are not build products
        h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
        diff = [str(f) for f in files if not (RR / f).exists() or h(D / f) != h(RR / f)]
        nc = sum(f.suffix == ".csv" for f in files)
        chk(9, "Fixed-seed rebuild gives identical SHA256", not diff, f"{len(files)} generated data files ({nc} CSV + {len(files) - nc} non-CSV: NPZ, GeoTIFF, GeoJSON) compared, {len(diff)} mismatches {diff[:5]}")
    if "accident_prob" in v0 and a.accident_prob_harwood.notna().all():
        v0n = v0[v0.u != v0.v]; hw = v0n.accident_rate_per_vehkm * v0n.p_release_given_accident * v0n.length_km
        chk(10, "Harwood comparison basis reproduced", np.allclose(a.accident_prob_harwood.values, hw.values, rtol=1e-4), f"max relative difference {np.max(np.abs(a.accident_prob_harwood.values / hw.values - 1)):.2e}")
# magnitude: IR at 30 m from the road edge on the busiest arc, two bounding substance assumptions (largest toxic radius, Pi=1; smallest flammable radius, Pi flammable base)
    rad = pd.read_csv(R.path("radii")).set_index("substance"); st_ = P["substance_type"]
    tox = max((s for s in rad.index if st_.get(s) == "toxic"), key=lambda s: rad.loc[s, "primary_radius_km"])
    fla = min((s for s in rad.index if st_.get(s) == "flammable"), key=lambda s: rad.loc[s, "primary_radius_km"])
    rt, rf, pf = rad.loc[tox, "primary_radius_km"], rad.loc[fla, "primary_radius_km"], (P.get("Pi_substance") or {}).get(fla, P["Pi"]["flammable"]["base"])
    fcol = "flow_loaded_calibrated" if "flow_loaded_calibrated" in a else "flow_loaded_base"# calibrated flows where the region uses them
    r = a.loc[a[fcol].idxmax()]; y = 0.03; lo_ref, hi_ref = Q.get("ir_reference", [4e-6, 1e-5])
    ir = lambda rs, Pi: r[fcol] * (r.p_release_trip / r.length_km) * Pi * 2 * math.sqrt(rs ** 2 - y ** 2)
    MQ = Q.get("magnitude") or {}
    if MQ.get("method") == "basisnet_rank":# RotterdamHaz (item 7): relative check against the official Basisnet PR 10^-6 contour distances
        legacy = f"legacy ERG-based IR(30 m) on the busiest arc {ir(rf, pf):.2e} (smallest flammable) to {ir(rt, 1.0):.2e} (largest toxic) per year, not tested (ERG radii are protective-action distances)"
        chk("M", "Magnitude check, revised: model release frequency per section vs Basisnet PR 10^-6 contour distance", *_m_basisnet(R, a, fcol, MQ, legacy))
    else:
      chk("M", f"Magnitude check (individual-risk reference {lo_ref:g} to {hi_ref:g} per year)", ir(rf, pf) <= hi_ref <= ir(rt, 1.0), f"busiest arc {r['name']} ({r.road_class}), {r[fcol]:.0f} loaded truck trips/year ({fcol}): all {tox} (radius {rt} km, Pi=1, lethality=1) IR(30 m)={ir(rt,1.0):.2e}/year; all {fla} ({rf} km, Pi={pf}) {ir(rf,pf):.2e}/year. Plausible if the reference lies between the two. ERG radii are protective-action distances, not lethal radii, so IR computed with them is systematically high")
    if Q.get("plausibility"):# external plausibility checks (region.qa.plausibility), see hazbench/plausibility.py
        from . import plausibility
        for i, name, ok, detail in plausibility.run(R, D, Q["plausibility"]): chk(i, name, ok, detail)
    json.dump(res, open(D / "qa_results.json", "w"), ensure_ascii=True, indent=1)
    return res

if __name__ == "__main__":
    a = sys.argv[1:]; R = load(a[0]); run(R, a[1], a[2], a[3] if len(a) > 3 else None)
