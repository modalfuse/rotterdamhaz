"""Baselines B1-B4: single-OD routing per instance OD row and substance.
  python -m hazbench.baselines regions/<region>.yaml <dataset_dir> <out_dir> [K=10]
Writes baseline_results.csv and baseline_summary.csv (medians, PLL sum); run hazbench.stats on the results for IQR and tests."""
import sys, time
from pathlib import Path
import pandas as pd
from .metrics import Bench, ARR, AS
from .config import load

METHODS = {"B1_min_time": ("t", False), "B2_min_length": ("L", False), "B3_min_TR_sum": ("TR", True), "B4_min_PE_sum": ("PE", True)}

def run(R, D, OUT, K=10, insts=None):
    D, OUT = Path(D), Path(OUT); OUT.mkdir(parents=True, exist_ok=True)
    b = Bench(D); rows = []; pre = R["instances"]["prefix"]
    METH = dict(METHODS)
    if "toll_min" in b.arcs: METH["B1p_min_pure_time"] = ("t0", False)# RotterdamHaz: pure travel time, tolls ignored
    for inst in (insts or [f"{pre}_K{K}_r{r}" for r in range(R["instances"].get("n_rep", 10))]):
        od = pd.read_csv(D / f"instances/{inst}/od.csv")
        for q in od.itertuples():
            s = q.substance; t0 = time.time()
            paths = {k: (b.shortest(q.origin, q.destination, w, s) if (sub or b.tf) else b.shortest(q.origin, q.destination, w)) for k, (w, sub) in METH.items()}
            M = {k: b.path_metrics(p, s) for k, p in paths.items()}
            Rmin_TR = M["B3_min_TR_sum"]["TR_sum"]
            for k, m in M.items():
                rows.append(dict(instance=inst, od_id=q.od_id, substance=s, method=k, T_min=m["T"], L_km=m["L"], TR_sum=m["TR_sum"], R_union=m["R_union"],
                                 PE_sum=m["PE_sum"], PE_union=m["PE_union"], DCR_PE=m["DCR_PE"], DCR_TR=m["DCR_TR"], dT=m["T"] / M["B1_min_time"]["T"] - 1,
                                 ARR_TR=ARR(M["B1_min_time"]["TR_sum"], m["TR_sum"], Rmin_TR), AS_TR=AS(M["B1_min_time"]["TR_sum"], Rmin_TR),
                                 trips_per_year=q.trips_loaded_per_year, PLL_contrib=q.trips_loaded_per_year * m["TR_sum"],
                                 same_path_as_B1=paths[k] == paths["B1_min_time"], same_path_as_B3=paths[k] == paths["B3_min_TR_sum"], sec=time.time() - t0))
    df = pd.DataFrame(rows); df.to_csv(OUT / "baseline_results.csv", index=False)
    g = df.groupby("method").agg(T_min=("T_min", "median"), TR_sum=("TR_sum", "median"), PE_sum=("PE_sum", "median"), PE_union=("PE_union", "median"),
                                 DCR_PE=("DCR_PE", "median"), dT=("dT", "median"), ARR_TR=("ARR_TR", "median"), PLL=("PLL_contrib", "sum"), n=("od_id", "count"))
    g.to_csv(OUT / "baseline_summary.csv"); print(g.to_string())
    return df

if __name__ == "__main__":
    a = sys.argv[1:]; run(load(a[0]), a[1], a[2], int(a[3]) if len(a) > 3 else 10, a[4].split(",") if len(a) > 4 else None)# optional 5th arg: instance names
