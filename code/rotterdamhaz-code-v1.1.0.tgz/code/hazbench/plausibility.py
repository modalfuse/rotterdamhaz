"""External plausibility checks (RotterdamHaz; called from hazbench.qa when region.qa.plausibility is set). Writes
<dataset>/plausibility_lengths.csv and <dataset>/plausibility_flows.csv and returns QA rows (id, name, passed, detail).

P1  Road length inside the network bbox: OSM network (directed arcs collapsed to undirected edges, i.e. two-way roads counted once,
    dual carriageways twice) vs the national road database NWB (Rijkswaterstaat; wegvakken clipped to the same bbox, one line per
    carriageway where carriageways are separate), by road authority (wegbehsrt R = Rijk, P = province, G = municipality, W = water
    board, T = other). Pass: OSM motorway+trunk (incl. links) / NWB R within `p1_motorway_band` (default [0.85, 1.15]).
    Totals are reported, not tested: the OSM network excludes service roads, living streets, tracks and parts outside the largest SCC.
P2  Modelled vs observed dangerous-goods tank-truck flows at the Rijkswaterstaat VGS count sections (calibration_sites.csv):
    ratio model/observed per matched site and hazmat class, before (gravity model, base scenario) and after calibration.
    Pass: median ratio before calibration within `p2_ratio_band` (default [0.67, 1.5]) for every class."""
from pathlib import Path
import numpy as np, pandas as pd, pyogrio, shapely
from pyproj import Transformer

def run(R, D, cfg):
    D = Path(D); out = []
    a = pd.read_csv(D / "arcs.csv"); W, S, E, N = R["network"]["osm_graph"]["bbox"]
    T = Transformer.from_crs(R["crs"]["geographic"], R["crs"]["projected"], always_xy=True)
    bx, by = T.transform([W, E, E, W, W], [S, S, N, N, S]); box = shapely.Polygon(zip(bx, by))
# P1 lengths
    und = a.assign(k=[tuple(sorted(x)) for x in zip(a.u, a.v)]).drop_duplicates("k")
    cls = und.road_class.str.replace("_link", "", regex=False)
    grp = {"motorway+trunk (incl. links)": cls.isin(["motorway", "trunk"]), "primary+secondary": cls.isin(["primary", "secondary"]),
           "tertiary+unclassified+residential": cls.isin(["tertiary", "unclassified", "residential"])}
    osm = {k: float(und.length_km[m].sum()) for k, m in grp.items()}; osm["total"] = float(und.length_km.sum())
    nwb = pyogrio.read_dataframe(R.resolve(cfg["nwb_gpkg"]), layer=cfg.get("nwb_layer", "wegvakken"), columns=["wegbehsrt", "bst_code"], bbox=tuple(box.bounds))
    g = shapely.intersection(nwb.geometry.values, box); L = shapely.length(g) / 1000
    nl = pd.Series(L).groupby(nwb.wegbehsrt.fillna("?").values).sum().to_dict(); nl_tot = float(L.sum())
    rows = [dict(group=k, osm_km=round(v, 1)) for k, v in osm.items()]
    rows += [dict(group=f"NWB wegbehsrt {k}", nwb_km=round(v, 1)) for k, v in sorted(nl.items())] + [dict(group="NWB total", nwb_km=round(nl_tot, 1))]
    pd.DataFrame(rows).to_csv(D / "plausibility_lengths.csv", index=False)
    r_mw = osm["motorway+trunk (incl. links)"] / nl.get("R", np.nan); band = cfg.get("p1_motorway_band", [0.85, 1.15])
    out.append(("P1", "Road length vs NWB (Rijkswaterstaat) inside the network bbox", band[0] <= r_mw <= band[1],
                f"OSM motorway+trunk incl. links {osm['motorway+trunk (incl. links)']:.0f} km vs NWB Rijk (R) {nl.get('R', float('nan')):.0f} km, ratio {r_mw:.2f} (band {band}); "
                f"OSM primary+secondary {osm['primary+secondary']:.0f} km vs NWB province (P) {nl.get('P', 0):.0f} km; OSM tertiary/unclassified/residential {osm['tertiary+unclassified+residential']:.0f} km vs NWB municipality (G) {nl.get('G', 0):.0f} km; "
                f"totals OSM {osm['total']:.0f} km vs NWB {nl_tot:.0f} km (ratio {osm['total']/nl_tot:.2f}; OSM network excludes service/living_street/track and non-SCC parts; road-authority classes and OSM classes do not map one to one)"))
# P2 flows
    cs = D / "calibration_sites.csv"
    if cs.exists():
        c = pd.read_csv(cs); rows = []; det = []; ok = True; band = cfg.get("p2_ratio_band", [0.67, 1.5])
        for hc in [x[4:] for x in c.columns if x.startswith("obs_")]:
            m = c[c.arcs.notna() & (c[f"obs_{hc}"] > 0)]
            rb = (m[f"model_before_{hc}"] / m[f"obs_{hc}"]); ra = (m[f"model_after_{hc}"] / m[f"obs_{hc}"])
            q = lambda x: np.percentile(x, [25, 50, 75]) if len(x) else [np.nan] * 3
            b1, b2, b3 = q(rb); a1, a2, a3 = q(ra)
            rows.append(dict(hazmat_class=hc, n_sites=len(m), ratio_before_q1=b1, ratio_before_median=b2, ratio_before_q3=b3, ratio_after_q1=a1, ratio_after_median=a2, ratio_after_q3=a3,
                             GEH_before_median=float(m[f"GEH_before_{hc}"].median()), GEH_after_median=float(m[f"GEH_after_{hc}"].median()),
                             share_GEH_after_lt5=float((m[f"GEH_after_{hc}"] < 5).mean())))
            ok &= bool(band[0] <= b2 <= band[1])
            det.append(f"{hc}: {len(m)} sites, model/obs median {b2:.2f} [IQR {b1:.2f}-{b3:.2f}] before calibration, {a2:.2f} [{a1:.2f}-{a3:.2f}] after; median GEH {rows[-1]['GEH_before_median']:.1f} -> {rows[-1]['GEH_after_median']:.1f}")
        pd.DataFrame(rows).to_csv(D / "plausibility_flows.csv", index=False)
        out.append(("P2", f"Modelled vs observed DG tank-truck flows (RWS VGS sections), median ratio band {band}", ok, "; ".join(det) + ". Through traffic not generated inside the study area is not modelled"))
    return out
