"""hazbench: region-config-driven builder for hazmat road-transport risk benchmarks."""
__version__ = "0.1.0"
