"""Assemble a public release directory from a build, with company / operator names removed (decision Q. Liu
2026-10-21 21:31).

  python -m hazbench.release regions/<region>.yaml <build_dir> <release_dir> [extra results: <src>=<dest relative to release> ...]

Facilities are already written by hazbench.build under pseudonymous ids (G01.., A01..) with a non-identifying type; names occur only in
provenance text (DATA_SOURCES.csv), the region config and the code snapshot. This step
  1. copies the build (data files, instances, _baselines -> results/baselines) and the extra results into <release_dir>,
  2. writes the config copies and a code snapshot (code/<name>-code-v<version>.tgz, no .venv / caches / backups),
  3. replaces every name / regex listed in the region config (facilities.port_terminals.*, osm_polygon_exclude_name, release.redact_terms)
     by "[operator]" and every URL on release.redact_url_domains by "[operator page]" in all text files (csv, yaml, md, txt, json, py, sh),
     and the per-facility capacity lists in DATA_SOURCES.csv by "<facility id> <capacity>" from gen_points.csv,
  4. writes <release.private_dir>/company_map.csv (facility id -> name, source id, capacity; NEVER inside the release),
  5. fails if any redact term is still found in any text file of the release (incl. the code snapshot).
The unredacted region config stays in the private working copy; a byte-identical rebuild of the facility layer needs it (or the
facility list in company_map.csv)."""
import sys, re, io, csv, shutil, tarfile, fnmatch
from pathlib import Path
import numpy as np, pandas as pd
from .config import load as load_region

_DOM = [None]
TEXT = (".csv", ".yaml", ".yml", ".md", ".txt", ".json", ".py", ".sh", ".geojson")
SKIP_CODE = (".venv", "__pycache__", "*.bak*", "*.pyc", ".pytest_cache")


def _terms(R):
    pt = (R.get("facilities") or {}).get("port_terminals") or {}
    raw = []
    for t in pt.get("terminals") or []:
        raw += [t.get(k) for k in ("name", "rev", "osm", "drop_register", "capacity_group")]
    raw += [r.get("name") for r in pt.get("refinery_capacity") or []]
    ex = (R.get("facilities") or {}).get("osm_polygon_exclude_name")
    if ex: raw += re.sub(r"^\^\(|\)\$$", "", ex).split("|")
    raw += (R.get("release") or {}).get("redact_terms") or []
    out = set()
    for s in raw:
        if not s: continue
        s = re.sub(r"\\(.)", r"\1", s).strip("^$ ").strip()
        s = re.sub(r"\s*\($", "", s)
        if len(s) >= 3: out.add(s)
        for suf in (" B.V.", " BV", " B.V", " (Rotterdam)"):
            if s.endswith(suf) and len(s) > len(suf) + 2: out.add(s[: -len(suf)].strip())
    return sorted(out, key=len, reverse=True)


def _rx(terms):
    parts = []
    for t in terms:
        e = re.escape(t)
        parts.append(rf"(?<![A-Za-z0-9]){e}(?![A-Za-z0-9])" if len(t) <= 5 or t.isupper() else rf"(?i:(?<![A-Za-z0-9]){e}(?![A-Za-z0-9]))")
    return re.compile("|".join(parts))


def _redact_text(s, rx, url_rx):
    s = url_rx.sub("[operator page]", s) if url_rx else s
    s = rx.sub("[operator]", s)
    if url_rx is not None and _DOM[0] is not None: s = _DOM[0].sub("[operator page]", s)
    s = re.sub(r"(\[operator\][ /,]*){2,}", "[operator] ", s)
    return s


def _capacity_rows(ds, gen):
    """Replace the name lists of the capacity rows by facility ids."""
    for col_item, col in (("refinery weights (crude capacity)", "capacity_kbd"), ("port weights (tank storage capacity)", "capacity_m3")):
        m = ds["item"] == col_item
        if not m.any() or col not in gen: continue
        g = gen[gen[col].notna()].sort_values(col, ascending=False)
        val = "; ".join(f"{r.id} {r[col]:,.0f}" for _, r in g.iterrows()) + f" (total {g[col].sum():,.0f}; facility ids as in gen_points.csv)"
        ds.loc[m, "value"] = val
    return ds


def _company_map(R, B):
    """facility id -> nearest listed facility point (name, source id, capacity); private."""
    pt = ((R.get("facilities") or {}).get("port_terminals") or {}).get("out") or (R.get("facilities") or {}).get("points")
    gen = pd.read_csv(B / "gen_points.csv"); nodes = pd.read_csv(B / "nodes.csv").set_index("node")
    rows = []
    fp = pd.read_csv(R.resolve(pt)) if pt and Path(R.resolve(pt)).exists() else None
    for _, g in gen.iterrows():
        lon, lat = nodes.loc[g.node, ["lon", "lat"]]
        r = dict(id=g.id, type=g.type, node=g.node, capacity_m3=g.get("capacity_m3"), capacity_kbd=g.get("capacity_kbd"))
        if fp is not None and len(fp):
            d = np.hypot((fp.lon - lon) * np.cos(np.radians(lat)), fp.lat - lat) * 111_320
            k = int(np.argmin(d.values)); how = "nearest listed facility point to the generator node"
            for col in ("capacity_m3", "capacity_kbd"):# capacity values are unique per listed facility: exact match first
                if col in fp and pd.notna(g.get(col)):
                    hit = np.where(np.isclose(fp[col].astype(float), float(g[col])))[0]
                    if len(hit): k = int(hit[np.argmin(d.values[hit])]); how = f"{col} match"; break
            f = fp.iloc[k]
            r.update(name=f.get("name"), list_name=f.get("list_name"), source_id=f.get("source_id"), match_dist_m=round(float(d.iloc[k]), 1),
                     match_note=how)
        rows.append(r)
    return pd.DataFrame(rows)


def main(cfg, B, REL, extra):
    R = load_region(cfg); B, REL = Path(B), Path(REL)
    if REL.exists() and any(REL.iterdir()): sys.exit(f"{REL} exists and is not empty; choose a new directory (nothing is overwritten)")
    terms = _terms(R); rx = _rx(terms)
    doms = (R.get("release") or {}).get("redact_url_domains") or []
    url_rx = re.compile(r"https?://[^\s;,\"']*(?:" + "|".join(re.escape(d) for d in doms) + r")[^\s;,\"']*") if doms else None
    if doms: _DOM[0] = re.compile(r"(?<![\w.])(?:www\.)?(?:" + "|".join(re.escape(d) for d in doms) + r")[^\s;,\"')]*")
    PRIV = Path(R.resolve((R.get("release") or {}).get("private_dir") or str(B.parent / "private")))
    if PRIV.resolve().is_relative_to(REL.resolve()): sys.exit("private_dir must be outside the release directory")
    REL.mkdir(parents=True, exist_ok=True); (REL / "config").mkdir(); (REL / "results").mkdir(); (REL / "code").mkdir()
    for f in sorted(B.iterdir()):
        if f.is_file() and not f.name.endswith(".log") and not f.name.startswith("."): shutil.copy2(f, REL / f.name)
    shutil.copytree(B / "instances", REL / "instances")
    if (B / "_baselines").exists(): shutil.copytree(B / "_baselines", REL / "results" / "baselines")
    for e in extra:
        src, dst = e.split("=", 1); src, dst = Path(src), REL / dst
        (shutil.copytree(src, dst) if src.is_dir() else (dst.parent.mkdir(parents=True, exist_ok=True), shutil.copy2(src, dst)))
    cfgp = Path(cfg).resolve()
    for p in (cfgp, Path(R["_params_file"]), R.resolve(R["data_sources"]) if R.get("data_sources") else None):
        if p and p.exists(): shutil.copy2(p, REL / "config" / p.name)
    docs = cfgp.parent / "release_docs" / cfgp.stem# README, LICENSES, THIRD_PARTY_DATA, environment.yml (static, versioned with the code)
    if docs.exists():
        for p in sorted(docs.iterdir()):
            if p.is_file(): shutil.copy2(p, REL / p.name)
    if (cfgp.parents[1] / "requirements.lock.txt").exists(): shutil.copy2(cfgp.parents[1] / "requirements.lock.txt", REL / "requirements.txt")
    root = cfgp.parents[1]
    import yaml; ver = str(yaml.safe_load(open(B / "params.yaml")).get("version", "x"))
    name = (R.get("release") or {}).get("name", "rotterdamhaz")
    tgz = REL / "code" / f"{name}-code-v{ver}.tgz"
    with tarfile.open(tgz, "w:gz") as tf:
        for p in sorted(root.rglob("*")):
            rel = p.relative_to(root.parent)
            if any(fnmatch.fnmatch(part, pat) for part in rel.parts for pat in SKIP_CODE) or not p.is_file(): continue
            data = p.read_bytes()
            if p.suffix in TEXT: data = _redact_text(data.decode("utf-8"), rx, url_rx).encode("utf-8")
            ti = tarfile.TarInfo(str(rel)); ti.size = len(data); ti.mtime = int(p.stat().st_mtime); ti.mode = p.stat().st_mode & 0o777
            tf.addfile(ti, io.BytesIO(data))
    gen = pd.read_csv(REL / "gen_points.csv")
    ds = pd.read_csv(REL / "DATA_SOURCES.csv", dtype=str, keep_default_na=False)
    _capacity_rows(ds, gen).to_csv(REL / "DATA_SOURCES.csv", index=False, quoting=csv.QUOTE_MINIMAL)
    if (REL / "config" / f"{cfgp.stem}.sources.csv").exists(): shutil.copy2(REL / "DATA_SOURCES.csv", REL / "config" / f"{cfgp.stem}.sources.csv")
    n_red = 0
    for p in sorted(REL.rglob("*")):
        if p.is_file() and p.suffix in TEXT and p.stat().st_size < 200e6:
            s = p.read_text("utf-8"); t = _redact_text(s, rx, url_rx)
            if t != s: p.write_text(t, "utf-8"); n_red += 1
    PRIV.mkdir(parents=True, exist_ok=True)
    _company_map(R, B).to_csv(PRIV / "company_map.csv", index=False)
    (PRIV / "README.txt").write_text("PRIVATE - do not release or zip. facility id -> company mapping and the term list used by hazbench.release.\n")
    pd.Series(terms, name="term").to_csv(PRIV / "redact_terms.csv", index=False)
    leaks = []
    for p in sorted(REL.rglob("*")):
        if p.is_file() and p.suffix in TEXT:
            for m in rx.finditer(p.read_text("utf-8")): leaks.append((str(p.relative_to(REL)), m.group(0)))
    with tarfile.open(tgz) as tf:
        for m in tf.getmembers():
            if Path(m.name).suffix in TEXT:
                for x in rx.finditer(tf.extractfile(m).read().decode("utf-8")): leaks.append((f"{tgz.name}:{m.name}", x.group(0)))
    import hashlib
    files = sorted(p for p in REL.rglob("*") if p.is_file() and p.name != "SHA256SUMS")
    with open(REL / "SHA256SUMS", "w") as fh:
        for p in files: fh.write(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  ./{p.relative_to(REL)}\n")
    print(f"release {REL}: {n_red} text files redacted, {len(terms)} terms; private map {PRIV / 'company_map.csv'}")
    if leaks: print("LEAKS:", leaks[:20]); sys.exit(1)
    print("leak check: 0 names found")


if __name__ == "__main__":
    if len(sys.argv) < 4: sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:])
