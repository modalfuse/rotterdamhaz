"""Generic OSM -> directed road graph ("network snapshot")
(which was built with OSMnx 2.1.1), so the main builder treats both identically.

Outputs (region.network.{nodes,arcs,geojson}):
  nodes.csv    node, lon, lat
  arcs.csv     u, v, length_km, speed_kmh_assumed, road_class, name, urban, pop_density_1km, time_min,
               harwood_class, accident_rate_per_vehkm, p_release_given_accident, accident_prob
  arcs.geojson LineString per arc (WGS 84), properties u, v (same order as arcs.csv)
Rules (all in region.network.osm_graph):
  * ways with highway in `classes`; dropped if area=yes, access in `drop_access`, motor_vehicle/motorcar=no
  * direction: oneway=yes/true/1 forward, -1 reverse, junction=roundabout/circular and highway=motorway implied oneway, else both ways
  * segment graph truncated to `bbox` (nodes outside dropped), largest weakly connected component, then OSMnx-style topological
    simplification (end point = self-loop, in- or out-degree 0, != 2 distinct neighbours, or degree not in {2, 4});
    arc attributes from the way with the largest length share; parallel arcs -> shortest kept; self-loops kept (the builder drops
    them, as for the v0 snapshot); largest strongly connected component
  * speed by class (`speed_kmh`, *_link x `link_factor`); length on the projected CRS
  * pop_density_1km = population (persons) within 1 km of the arc midpoint / (pi km^2); urban = density > `urban_density_threshold`
  * Harwood (1990) class: freeway for motorway/trunk(+links); multilane_divided for primary/secondary with lanes >= 4 and for
    primary/secondary links; two_lane otherwise; prefixed urban_/rural_. Comparison basis only.
Usage: python -m hazbench.osm_graph regions/<region>.yaml"""
import json, pickle, re, sys
from collections import Counter
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx, rasterio
from pyproj import Transformer
from scipy.spatial import cKDTree
from .config import load

def _oneway(t):
    o = (t.get("oneway") or "").lower()
    if o in ("yes", "true", "1"): return 1
    if o == "-1": return -1
    if o in ("no", "false", "0"): return 0
    if (t.get("junction") or "") in ("roundabout", "circular") or t.get("highway") == "motorway": return 1
    return 0

def _harwood_class(cls, urban, lanes):
    base = cls.replace("_link", "")
    if base in ("motorway", "trunk"): k = "freeway"
    elif base in ("primary", "secondary") and (cls.endswith("_link") or lanes >= 4): k = "multilane_divided"
    else: k = "two_lane"
    return ("urban_" if urban else "rural_") + k

def build(R):
    G_ = R["network"]["osm_graph"]; classes = set(G_["classes"]); W, S, E, N = G_["bbox"]
    drop_access = set(G_.get("drop_access", ["no", "private"]))
    T = Transformer.from_crs(R["crs"]["geographic"], R["crs"]["projected"], always_xy=True)
    hw = pickle.load(open(R.path("paths", "osm_dir") / "osm_highways.pkl", "rb"))
    ways = {}
    for wid, w in hw.items():
        t = w["tags"]
        if t["highway"] not in classes or t.get("area") == "yes" or t.get("access") in drop_access: continue
        if t.get("motor_vehicle") == "no" or t.get("motorcar") == "no": continue
        ways[wid] = w
    coord = {}
    for w in ways.values():
        for r, ll in zip(w["refs"], w["lonlat"]): coord[r] = ll
    inb = lambda n: W <= coord[n][0] <= E and S <= coord[n][1] <= N
# 1) segment-level directed graph, truncated to the bbox (nodes outside dropped), OSMnx-style
    Sg = nx.DiGraph()
    for wid in sorted(ways):
        w = ways[wid]; t = w["tags"]; refs = w["refs"]; ow = _oneway(t)
        for a, b in zip(refs[:-1], refs[1:]):
            if a == b or not (inb(a) and inb(b)): continue
            x, y = T.transform([coord[a][0], coord[b][0]], [coord[a][1], coord[b][1]]); L = float(np.hypot(x[1] - x[0], y[1] - y[0])) / 1000
            for (p, q) in (((a, b), (b, a)) if ow == 0 else (((a, b),) if ow == 1 else ((b, a),))):
                Sg.add_edge(p, q, L=L, way=wid)
    Sg = Sg.subgraph(max(nx.weakly_connected_components(Sg), key=len)).copy()
# 2) topological simplification (OSMnx rule): a node is an end point if it has a self-loop, no in- or out-edges,
# or not exactly 2 distinct neighbours, or degree not in {2, 4}; paths between end points become one arc
    def is_end(n):
        nb = set(Sg.predecessors(n)) | set(Sg.successors(n))
        return n in nb or Sg.in_degree(n) == 0 or Sg.out_degree(n) == 0 or len(nb) != 2 or Sg.degree(n) not in (2, 4)
    ends = {n for n in Sg.nodes if is_end(n)}
    edges = {}
    for u in sorted(ends):
        for v in sorted(Sg.successors(u)):
            path = [u, v]
            while v not in ends:
                nxt = [w_ for w_ in Sg.successors(v) if w_ not in path]
                if len(nxt) == 1: v = nxt[0]; path.append(v)
                else:
                    if u in Sg.successors(v): path.append(u)
                    break
            segs = list(zip(path[:-1], path[1:])); L = sum(Sg.edges[e]["L"] for e in segs)
            wl = Counter()
            for e in segs: wl[Sg.edges[e]["way"]] += Sg.edges[e]["L"]
            wid = max(wl, key=lambda k: (wl[k], -k))# attributes of the way with the largest share of the arc length
            key = (path[0], path[-1])
            if key in edges and edges[key]["L"] <= L: continue
            edges[key] = dict(L=L, refs=path, way=wid, t=ways[wid]["tags"])
    D = nx.DiGraph(); D.add_edges_from(edges)
    scc = max(nx.strongly_connected_components(D), key=len)
    E_ = [(k, e) for k, e in sorted(edges.items()) if k[0] in scc and k[1] in scc]
# population density within 1 km of the arc midpoint (population raster in any CRS)
    pr = R.path("population", "raster"); dens = None
    if pr and Path(pr).exists():
        src = rasterio.open(pr); A = src.read(1).astype(float); A[~np.isfinite(A) | (A < 0)] = 0
        rr, cc = np.nonzero(A > 0); tr = src.transform
        Tp = Transformer.from_crs(src.crs, R["crs"]["projected"], always_xy=True)
        px, py = Tp.transform(tr.c + tr.a * (cc + 0.5), tr.f + tr.e * (rr + 0.5)); tree = cKDTree(np.c_[px, py]); pv = A[rr, cc]
        def dens(lon, lat):
            x, y = T.transform(lon, lat); return float(pv[tree.query_ball_point([x, y], 1000.0)].sum() / np.pi)
    sp = G_["speed_kmh"]; lf = G_.get("link_factor", 0.6); thr = G_.get("urban_density_threshold", 1500)
    hz = pd.read_csv(R.path("harwood_table")).set_index("harwood_class") if R.get("harwood_table") else None
    rows, feats = [], []
    for (u, v), e in E_:
        t = e["t"]; cls = t["highway"]; base = cls.replace("_link", "")
        spd = sp.get(base, sp.get("other", 30)) * (lf if cls.endswith("_link") else 1.0)
        refs = e["refs"]; mid = coord[refs[len(refs) // 2]]
        pd1 = round(dens(*mid)) if dens else 0; urb = int(pd1 > thr)
        lanes = int(float(t["lanes"].split(";")[0])) if re.match(r"^\d", t.get("lanes") or "") else 0
        hc = _harwood_class(cls, urb, lanes)
        r = dict(u=u, v=v, length_km=round(e["L"], 5), speed_kmh_assumed=round(spd, 3), road_class=cls, name=t.get("name") or "", urban=urb,
                 pop_density_1km=pd1, time_min=round(60 * e["L"] / spd, 5), harwood_class=hc)
        if hz is not None and hc in hz.index:
            r.update(accident_rate_per_vehkm=hz.loc[hc, "accident_rate_per_vehkm"], p_release_given_accident=hz.loc[hc, "p_release_given_accident"])
            r["accident_prob"] = float("%.5g" % (r["accident_rate_per_vehkm"] * r["p_release_given_accident"] * r["length_km"]))
        rows.append(r)
        feats.append({"type": "Feature", "properties": {"u": int(u), "v": int(v)}, "geometry": {"type": "LineString", "coordinates": [list(coord[n]) for n in refs]}})
    arcs = pd.DataFrame(rows)
    ns = sorted(set(arcs.u) | set(arcs.v))
    nodes = pd.DataFrame({"node": ns, "lon": [coord[n][0] for n in ns], "lat": [coord[n][1] for n in ns]})
    out = R.path("network", "arcs").parent; out.mkdir(parents=True, exist_ok=True)
    nodes.to_csv(R.path("network", "nodes"), index=False); arcs.to_csv(R.path("network", "arcs"), index=False)
    json.dump({"type": "FeatureCollection", "features": feats}, open(R.path("network", "geojson"), "w"))
    msg = (f"osm_graph: {len(ways)} ways kept of {len(hw)}; {len(edges)} directed edges before SCC; largest SCC {len(nodes)} nodes / {len(arcs)} arcs; "
           f"total length {arcs.length_km.sum():.1f} km; classes {arcs.road_class.value_counts().to_dict()}")
    print(msg); (out / "osm_graph_log.txt").write_text(msg + "\n")
    return nodes, arcs

if __name__ == "__main__":
    build(load(sys.argv[1], sys.argv[2:]))
